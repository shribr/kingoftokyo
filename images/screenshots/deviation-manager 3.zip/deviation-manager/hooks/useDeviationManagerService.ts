import { useEffect, useState } from 'react';
import { useGetStartupConfig } from '~/data-provider';
import deviationManagerService, { DeviationManagerService, initializeDeviationManagerService } from '../services/DeviationManagerService';

export function useDeviationManagerService() {
  const { data: startupConfig, isLoading, error } = useGetStartupConfig();
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Wait for config to load
    if (isLoading) {
      return;
    }

    // Handle error or missing config
    if (error || !startupConfig?.cataliaConfig?.deviationManagerBaseUrl) {
      console.error('Deviation Manager API base URL is missing in the startup config.', {
        error,
        config: startupConfig?.cataliaConfig
      });
      setIsInitialized(true); // Mark as initialized to prevent infinite loading
      return;
    }

    // Initialize service if not already done or URL changed
    const configUrl = startupConfig.cataliaConfig.deviationManagerBaseUrl;
    if (!deviationManagerService.azureApiBaseUrl || deviationManagerService.azureApiBaseUrl !== configUrl) {
      initializeDeviationManagerService(configUrl);
      console.log('DeviationManagerService initialized with URL:', configUrl);
    }

    setIsInitialized(true);
  }, [startupConfig, isLoading, error]);

  return {
    service: deviationManagerService,
    isInitialized,
    isLoading,
    error,
    azureApiBaseUrl: deviationManagerService?.azureApiBaseUrl,
    hasValidConfig: !!startupConfig?.cataliaConfig?.deviationManagerBaseUrl
  };
}