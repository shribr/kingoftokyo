import React, { useState, useEffect, createContext, useContext } from 'react'
import type { KpiData, TrendType, Deviation } from './types'
import { 
  generateKpiData, 
  generateDeviationData, 
  filterDeviationData, 
  paginateData, 
  getTotalPages
} from './dataHelper'
import { getDeviationRecords } from '../../services/DeviationManagerService';

import type { DeviationData, DeviationRecord } from './data';

// Re-export flexible hooks for easy access
export { 
  useFlexibleKpis, 
  useFlexibleDeviationTable, 
  useFlexibleChartData, 
  useDataSourceConfig 
} from './flexibleHooks';

// KPI Context and Provider
interface KpiContextType {
  kpis: {
    items: KpiData[]
  }
}

const KpiContext = createContext<KpiContextType | undefined>(undefined)

// Shared KPI data - generate once and reuse
let sharedKpiData: { items: KpiData[] } | null = null

const getSharedKpiData = () => {
  if (!sharedKpiData) {
    const kpiData = generateKpiData()
    sharedKpiData = {
      items: [
        { title: 'Total deviations', display: kpiData.total.value.toString(), value: kpiData.total.value, deltaPct: kpiData.total.delta.percent, trend: kpiData.total.delta.dir as TrendType },
        { title: 'Under investigation', display: kpiData.under.value.toString(), value: kpiData.under.value, deltaPct: kpiData.under.delta.percent, trend: kpiData.under.delta.dir as TrendType },
        { title: 'CAPA required', display: kpiData.capas.value.toString(), value: kpiData.capas.value, deltaPct: kpiData.capas.delta.percent, trend: kpiData.capas.delta.dir as TrendType },
        { title: 'Pending resolution', display: `${kpiData.avg.value} days`, value: kpiData.avg.value, deltaPct: kpiData.avg.delta.percent, trend: kpiData.avg.delta.dir as TrendType }
      ]
    }
  }
  return sharedKpiData
}

// Simple provider component - can be enhanced later with actual context state
export const KpiProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return <>{children}</>
}

export const useKpis = () => {
  return { kpis: getSharedKpiData() }
}

export const useTrendString = (delta: number, trend: TrendType): string => {
  if (trend === 'neutral') return 'No change'
  const prefix = trend === 'up' ? '+' : trend === 'down' ? '-' : ''
  const absoluteDelta = Math.abs(delta)
  return `${prefix}${absoluteDelta}% from last week`
}

// Helper function to map severity levels to classification
const mapSeverityToClassification = (severityLevel: string): 'Major' | 'Minor' | 'Moderate' => {
  switch (severityLevel?.toLowerCase()) {
    case 'high':
      return 'Major';
    case 'medium':
      return 'Moderate';
    case 'low':
      return 'Minor';
    case 'major':
      return 'Major';
    case 'moderate':
      return 'Moderate';
    case 'minor':
      return 'Minor';
    default:
      return 'Minor'; // Default fallback
  }
};

// Deviation Table Hooks
interface TableState {
  deviations: Deviation[]
  pagination: {
    page: number
    totalPages: number
  }
  filters: {
    search: string
    site: string
    department: string
    classification: string
    stage: string
  }
  loading: boolean
  error: string | null
}

// Convert DeviationRecord to Deviation type for dashboard table compatibility
const convertDeviationRecordToDeviation = (record: DeviationRecord): Deviation => ({
  id: record.id,
  name: record.formData.deviationName,
  department: record.formData.department,
  classification: mapSeverityToClassification(record.formData.step2.severityLevel),
  stage: record.formData.stage,
  date: record.formData.createdOn,
  assignee: {
    name: record.formData.assignee,
    status: 'online' as 'online' | 'away' | 'busy' | 'offline' // Default status since DeviationRecord doesn't have this
  },
  site: record.formData.site,
  trackwiseRecord: record.trackwiseId || record.id
})

// Convert DeviationRecord to DeviationData for filtering compatibility
const convertDeviationRecordToDeviationData = (record: DeviationRecord): DeviationData => ({
  id: record.id,
  trackwiseRecord: record.trackwiseId || record.id,
  title: record.formData.deviationName,
  site: record.formData.site,
  dept: record.formData.department,
  classification: mapSeverityToClassification(record.formData.step2.severityLevel),
  stage: record.formData.stage,
  assignee: record.formData.assignee,
  assigneeStatus: 'online' as 'online' | 'away' | 'busy' | 'offline',
  createdDate: record.formData.createdOn
})

export const useDeviationTable = () => {
  const [allData, setAllData] = useState<DeviationData[]>([])
  const [initialLoadComplete, setInitialLoadComplete] = useState(false)
  const [state, setState] = useState<TableState>({
    deviations: [],
    pagination: {
      page: 1,
      totalPages: 1
    },
    filters: {
      search: '',
      site: '',
      department: '',
      classification: '',
      stage: ''
    },
    loading: true,
    error: null
  })

  // Load data from getDeviationRecords on component mount
  useEffect(() => {
    const loadDeviationRecords = async () => {
      try {
        setState(prev => ({ ...prev, loading: true, error: null }))

        // Get the live/sample deviation records using the standalone function
        const deviationRecords = await getDeviationRecords()
        
        // Convert DeviationRecord[] to DeviationData[] for compatibility with existing filtering logic
        const convertedData = deviationRecords.map(convertDeviationRecordToDeviationData)
        
        setAllData(convertedData)
        setInitialLoadComplete(true)
        
        console.log(`Loaded ${convertedData.length} deviation records for dashboard table`)
        console.log('Sample classifications:', convertedData.slice(0, 3).map(d => ({ 
          id: d.id, 
          severityLevel: deviationRecords.find(r => r.id === d.id)?.formData.step2.severityLevel,
          mappedClassification: d.classification 
        })))
      } catch (error) {
        console.error('Error loading deviation records:', error)
        setState(prev => ({ 
          ...prev, 
          error: error instanceof Error ? error.message : 'Failed to load deviation records',
          loading: false 
        }))
        
        // Fallback to sample data if live data fails
        const fallbackData = generateDeviationData(10)
        setAllData(fallbackData)
        setInitialLoadComplete(true)
      }
    }

    loadDeviationRecords()
  }, [])

  // Process data when allData or filters change
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Only show loading on subsequent filter changes, not during initial load
        if (initialLoadComplete) {
          setState(prev => ({ ...prev, loading: true, error: null }))
        }
        
        // Wait for initial load to complete before processing
        if (!initialLoadComplete) {
          return
        }

        if (allData.length === 0) {
          setState(prev => ({ ...prev, loading: false }))
          return
        }

        // Filter data based on current filters
        const filteredData = filterDeviationData(allData, {
          search: state.filters.search,
          site: state.filters.site,
          department: state.filters.department,
          classification: state.filters.classification,
          stage: state.filters.stage
        })

        // Paginate the filtered data (5 items per page)
        const paginatedData = paginateData(filteredData, state.pagination.page, 5)
        
        // Convert to Deviation type for dashboard table
        const convertedData = paginatedData.map(data => ({
          id: data.id,
          name: data.title,
          department: data.dept,
          classification: mapSeverityToClassification(data.classification),
          stage: data.stage,
          date: data.createdDate,
          assignee: {
            name: data.assignee,
            status: data.assigneeStatus
          },
          site: data.site,
          trackwiseRecord: data.trackwiseRecord
        }))

        const totalPages = Math.max(getTotalPages(filteredData.length, 5), 1)

        setState(prev => ({
          ...prev,
          deviations: convertedData,
          loading: false,
          pagination: {
            ...prev.pagination,
            totalPages: totalPages
          }
        }))
      } catch (err) {
        console.error('Error processing deviation data:', err)
        setState(prev => ({
          ...prev,
          loading: false,
          error: err instanceof Error ? err.message : 'Error processing data'
        }))
      }
    }

    fetchData()
  }, [state.pagination.page, state.filters.search, state.filters.site, state.filters.department, state.filters.classification, state.filters.stage, allData, initialLoadComplete])

  // Filter and pagination handlers
  const handlePageChange = (page: number) => {
    setState(prev => ({
      ...prev,
      pagination: {
        ...prev.pagination,
        page: page
      }
    }))
  }

  const handleSearch = (search: string) => {
    setState(prev => ({
      ...prev,
      filters: {
        ...prev.filters,
        search: search
      },
      pagination: {
        ...prev.pagination,
        page: 1 // Reset to first page when searching
      }
    }))
  }

  const handleFilter = (key: string, value: string) => {
    setState(prev => ({
      ...prev,
      filters: {
        ...prev.filters,
        [key]: value
      },
      pagination: {
        ...prev.pagination,
        page: 1 // Reset to first page when filtering
      }
    }))
  }

  return {
    deviations: state.deviations,
    pagination: state.pagination,
    filters: state.filters,
    loading: state.loading,
    error: state.error,
    handlePageChange,
    handleSearch,
    handleFilter
  }
}

// Chart data hooks
interface ChartData {
  labels: string[]
  datasets: Array<{
    label: string
    data: number[]
    backgroundColor?: string[]
    borderColor?: string
    borderWidth?: number
  }>
}

export const useChartData = (): ChartData => {
  // Mock chart data - replace with actual data fetching logic
  return {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [{
      label: 'Deviations',
      data: [12, 19, 3, 5, 2, 3],
      backgroundColor: [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 205, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)'
      ],
      borderColor: 'rgba(54, 162, 235, 1)',
      borderWidth: 1
    }]
  }
}

// Task data hook
interface Task {
  id: string
  title: string
  status: 'pending' | 'in-progress' | 'completed'
  dueDate: string
  priority: 'high' | 'medium' | 'low'
}

export const useTaskData = (): Task[] => {
  // Mock task data - replace with actual data fetching logic
  return [
    {
      id: '1',
      title: 'Review deviation DEV-2023-001',
      status: 'pending',
      dueDate: '2023-12-15',
      priority: 'high'
    },
    {
      id: '2',
      title: 'Complete CAPA investigation',
      status: 'in-progress',
      dueDate: '2023-12-20',
      priority: 'medium'
    },
    {
      id: '3',
      title: 'Update procedures document',
      status: 'completed',
      dueDate: '2023-12-10',
      priority: 'low'
    }
  ]
}

// Generic data fetching hook
export const useDataFetching = <T,>(
  fetchFunction: () => Promise<T>,
  dependencies: React.DependencyList = []
) => {
  const [data, setData] = useState<T | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        setError(null)
        const result = await fetchFunction()
        setData(result)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, dependencies)

  return { data, loading, error }
}