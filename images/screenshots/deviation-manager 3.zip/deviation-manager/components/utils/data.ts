export interface DeviationData {
  id: string;
  trackwiseRecord: string;
  title: string;
  site: string;
  dept: string;
  classification: string;
  stage: string;
  assignee: string;
  assigneeStatus: 'online' | 'away' | 'busy' | 'offline';
  createdDate: string;
}

export interface DeviationFormData {
  // Header fields
  deviationName: string;
  site: string;
  department: string;
  assignee: string;
  createdOn: string;
  stage: string;
  
  // Selected Trackwise record
  selectedTrackwiseRecord: TrackwiseRecord | null;
  
  // Step 1: Intake fields
  step1: {
    trackwiseSearchQuery: string;
    whatDefectObserved: string;
    objectDefectObserved: string;
    wantSpecifications: string;
    issueOccurred: string;
    dateOccurrence: string;
    timeOccurrence: string;
    dateDetection: string;
    impactOfIssue: string;
    processStepDefect: string;
    whoInvolvedProcess: string;
    whoObservedIssue: string;
    processDescription: string;
    immediateActions: string;
    materialsToolsEquipment: string;
    supportingDocuments: string[];
  };
  
  // Step 2: Initial Review & Impact fields
  step2: {
    riskQuestion1: 'yes' | 'no' | '';
    riskQuestion2: 'yes' | 'no' | '';
    riskQuestion3: 'yes' | 'no' | '';
    riskQuestion4: 'yes' | 'no' | '';
    severityLevel: 'high' | 'medium' | 'low' | '';
    severityDetails: string;
    detectionLevel: 'high' | 'medium' | 'low' | '';
    detectionDetails: string;
    occurrenceLevel: 'high' | 'medium' | 'low' | '';
    occurrenceDetails: string;
    rpnScore: string;
    localClassification: 'yes' | 'no' | '';
    teamCommitteeAgreement: 'yes' | 'no' | '';
  };
  
  // Step 3: Investigation & RCA fields
  step3: {
    investigationPlan: string;
    rootCauseAnalysis: string;
    contributingFactors: string[];
  };
  
  // Step 4: CAPA & conclusion fields
  step4: {
    correctiveActions: string;
    preventiveActions: string;
    effectiveness: string;
    conclusion: string;
  };
}

export interface DeviationRecord {
  id: string;
  trackwiseId?: string;
  formData: DeviationFormData;
}

export interface TrackwiseRecord {
  id: string;
  name: string;
  description: string;
  classification: string;
  createdOn: string;
  createdBy: string;
  department: string;
  
  // Form field data
  deviationName: string;
  potentialImpact: string;
  whatDefectObserved: string;
  objectDefectObserved: string;
  specifications: string;
  issueOccurred: string;
  timeOfOccurrence: string;
  actualDefectOccurrence: string;
  dateDefectDiscovered: string;
  dateReported: string;
  detectionMethods: string;
  personWhoObserved: string;
  personWhoReported: string;
  immediateAction: string;
  backgroundInformation: string;
  attachmentsDescription: string;
  additionalComments: string;
  finalAnalysis: string;
}

export interface KpiData {
  total: { value: number; delta: { dir: 'up' | 'down'; percent: number } };
  under: { value: number; delta: { dir: 'up' | 'down'; percent: number } };
  capas: { value: number; delta: { dir: 'up' | 'down'; percent: number } };
  avg: { value: number; delta: { dir: 'up' | 'down'; percent: number } };
}

// API interfaces for live data
export interface DeviationApiResponse {
  id: string;
  title: string;
  description: string;
  deviation_type?: string;
  created_date: string;
  site?: string;
  department?: string;
  classification?: string;
  stage?: string;
  assignee?: string;
}

// API interfaces for Trackwise record search
export interface TrackwiseSearchRequest {
  text: string;
  start_date: string;
  limit: number;
}

export interface TrackwiseSearchResponse {
  id: string;
  title: string;
  description: string;
  similarity_score: number;
  deviation_type: string;
  created_date: string;
}

// API interfaces for relevant deviations search
export interface RelevantDeviationsSearchRequest {
  text: string;
  start_date: string;
  limit: number;
}

export interface RelevantDeviationsSearchResponse {
  id: string;
  title: string;
  description: string;
  similarity_score: number;
  deviation_type: string;
  created_date: string;
  site?: string;
  department?: string;
  assignee?: string;
}

// ====================================================================
// STATIC DATA ARRAYS
// ====================================================================

export const SITE_OPTIONS = ['Kansas City', 'San Diego', 'Basel'];

export const DEPT_OPTIONS = ['All', 'Manufacturing', 'Warehouse', 'Production', 'Quality Control', 'Packaging', 'Logistics'];

export const FIRST_NAMES = [
  'Emma', 'James', 'Sophia', 'Benjamin', 'Emily', 'Michael', 'Isabella', 'William',
  'Ava', 'Ethan', 'Mia', 'Alexander', 'Charlotte', 'Olivia', 'Noah', 'Amelia',
  'Daniel', 'Grace', 'Lucas', 'Harper', 'Liam', 'Chloe', 'Wyatt', 'Aiden',
  'Nora', 'Jackson', 'Madison', 'Logan', 'Scarlett', 'Caleb', 'Henry', 'Ella',
  'Samuel', 'Abigail', 'Elijah', 'Avery'
];

export const LAST_NAMES = [
  'Miller', 'Johnson', 'Davis', 'Wilson', 'Anderson', 'Thomas', 'Moore', 'Taylor',
  'Jackson', 'White', 'Harris', 'Martin', 'Thompson', 'Clark', 'Lewis', 'Walker',
  'Young', 'Allen', 'King', 'Wright', 'Scott', 'Hill', 'Green', 'Adams',
  'Nelson', 'Baker', 'Hall', 'Campbell', 'Mitchell', 'Carter', 'Roberts', 'Parker',
  'Cooper', 'Price', 'Reed', 'Sullivan', 'Turner', 'Bennett', 'Perry', 'Bryant'
];

export const CLASSIFICATIONS = ['Minor', 'Moderate', 'Major'];

export const STAGES = [
  'Initial review & impact',
  'Investigation in progress',
  'Root cause analysis',
  'CAPA development',
  'CAPA & conclusion'
];

export const STATUS_OPTIONS = ['online', 'away', 'busy', 'offline'];

export const DEVIATION_NAMES = [
  'Temperature excursion',
  'Documentation error',
  'Material mix-up',
  'Equipment failure',
  'Process deviation',
  'Out-of-specification result',
  'Contamination event',
  'Label discrepancy',
  'Weight variance',
  'pH out of range',
  'Cleaning validation failure',
  'Calibration overdue',
  'Training record missing',
  'Environmental monitoring alert',
  'Batch record incomplete',
  'Raw material issue',
  'Packaging defect',
  'Computer system error',
  'Security breach',
  'Audit finding',
  'Customer complaint',
  'Supplier deviation',
  'Transportation issue',
  'Storage condition failure',
  'Test method deviation',
  'Sample handling error',
  'Data integrity issue',
  'Change control violation',
  'Validation protocol deviation',
  'Regulatory compliance issue'
];

// Dummy Trackwise Records
export const TRACKWISE_RECORDS: TrackwiseRecord[] = [
  {
    id: 'TW-2025-0001',
    name: 'Temperature Excursion in Storage Room B',
    description: 'Temperature monitoring system detected readings above acceptable range',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-01-15',
    createdBy: 'Johnson, Sarah',
    department: 'Quality Assurance',
    deviationName: 'Temperature Excursion in Storage Room B',
    potentialImpact: 'Product quality may be compromised due to temperature exposure',
    whatDefectObserved: 'Temperature readings exceeded 25°C for 4 hours',
    objectDefectObserved: 'Storage Room B climate control system',
    specifications: 'Storage temperature: 20-25°C, Humidity: 45-65% RH',
    issueOccurred: 'Storage Room B, Building 1, East Wing',
    timeOfOccurrence: '14:30',
    actualDefectOccurrence: '2025-01-15',
    dateDefectDiscovered: '2025-01-15',
    dateReported: '2025-01-15',
    detectionMethods: 'Automated temperature monitoring system alarm',
    personWhoObserved: 'Johnson, Sarah',
    personWhoReported: 'Johnson, Sarah',
    immediateAction: 'Moved affected products to backup storage facility',
    backgroundInformation: 'HVAC system malfunction caused temperature spike',
    attachmentsDescription: 'Temperature logs, photos of affected storage area',
    additionalComments: 'Maintenance team contacted for urgent repair',
    finalAnalysis: 'HVAC repair completed, temperature monitoring restored to normal'
  },
  {
    id: 'TW-2025-0002',
    name: 'Documentation Discrepancy - Batch Record',
    description: 'Missing pages found in completed batch production record',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-01-18',
    createdBy: 'Davis, Michael',
    department: 'Production',
    deviationName: 'Batch Record BR-240115 Documentation Discrepancy',
    potentialImpact: 'Batch release may be delayed pending investigation',
    whatDefectObserved: 'Pages 15-17 missing from batch record BR-240115',
    objectDefectObserved: 'Batch Record BR-240115',
    specifications: 'Complete batch record with all required signatures',
    issueOccurred: 'Production Line 3, Manufacturing Floor',
    timeOfOccurrence: '09:15',
    actualDefectOccurrence: '2025-01-15',
    dateDefectDiscovered: '2025-01-18',
    dateReported: '2025-01-18',
    detectionMethods: 'Routine batch record review',
    personWhoObserved: 'Smith, Jennifer',
    personWhoReported: 'Davis, Michael',
    immediateAction: 'Quarantined batch pending investigation',
    backgroundInformation: 'Pages may have been misplaced during production',
    attachmentsDescription: 'Copy of incomplete batch record, investigation notes',
    additionalComments: 'Production supervisor contacted for original pages',
    finalAnalysis: 'Missing pages located and properly integrated into batch record'
  },
  {
    id: 'TW-2025-0003',
    name: 'Equipment Calibration Overdue',
    description: 'Balance #B-004 found to be 30 days past calibration due date',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-01-25',
    createdBy: 'Anderson, James',
    department: 'Production',
    deviationName: 'Critical Balance B-004 Calibration Overdue',
    potentialImpact: 'Accuracy of weighing operations may be compromised',
    whatDefectObserved: 'Balance calibration certificate expired 30 days ago',
    objectDefectObserved: 'Analytical Balance B-004',
    specifications: 'Calibration required every 365 days per SOP-QC-001',
    issueOccurred: 'Quality Control Lab, Room 201',
    timeOfOccurrence: '08:45',
    actualDefectOccurrence: '2025-01-25',
    dateDefectDiscovered: '2025-01-25',
    dateReported: '2025-01-25',
    detectionMethods: 'Routine calibration status audit',
    personWhoObserved: 'Anderson, James',
    personWhoReported: 'Anderson, James',
    immediateAction: 'Removed balance from service, initiated emergency calibration',
    backgroundInformation: 'Calibration reminder system failed to alert technicians',
    attachmentsDescription: 'Expired calibration certificate, audit checklist',
    additionalComments: 'All weighing data from past 30 days requires review',
    finalAnalysis: 'Balance recalibrated and returned to service with updated schedule'
  },
  {
    id: 'TW-2025-0004',
    name: 'Raw Material Contamination',
    description: 'Foreign particles detected in incoming raw material shipment',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-02-02',
    createdBy: 'Thompson, Lisa',
    department: 'Warehouse',
    deviationName: 'Raw Material Lot RM-240201 Contamination Event',
    potentialImpact: 'Product quality compromised if contaminated material used',
    whatDefectObserved: 'Black metallic particles found in white powder material',
    objectDefectObserved: 'Raw Material Lot RM-240201',
    specifications: 'Material must be free from foreign matter per specification RM-001',
    issueOccurred: 'Warehouse Receiving Bay 2',
    timeOfOccurrence: '11:20',
    actualDefectOccurrence: '2025-02-02',
    dateDefectDiscovered: '2025-02-02',
    dateReported: '2025-02-02',
    detectionMethods: 'Visual inspection during incoming material check',
    personWhoObserved: 'Wilson, Emma',
    personWhoReported: 'Thompson, Lisa',
    immediateAction: 'Quarantined entire lot, notified supplier and QA department',
    backgroundInformation: 'Material came from new supplier with first-time shipment',
    attachmentsDescription: 'Photos of contaminated material, COA from supplier',
    additionalComments: 'Supplier investigation initiated, backup supplier contacted',
    finalAnalysis: 'Material rejected and returned to supplier, root cause identified'
  },
  {
    id: 'TW-2025-0005',
    name: 'Environmental Monitoring Alert',
    description: 'Viable count exceeded action limit in controlled environment',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-02-10',
    createdBy: 'Brown, David',
    department: 'Quality Control',
    deviationName: 'Cleanroom Suite A Environmental Excursion',
    potentialImpact: 'Sterility assurance of manufactured products at risk',
    whatDefectObserved: 'Viable count of 12 CFU/m³ detected (limit: 10 CFU/m³)',
    objectDefectObserved: 'Cleanroom Suite A Environmental Monitoring',
    specifications: 'ISO 14644-1 Class 7 cleanroom standards',
    issueOccurred: 'Cleanroom Suite A, Manufacturing Building',
    timeOfOccurrence: '15:30',
    actualDefectOccurrence: '2025-02-10',
    dateDefectDiscovered: '2025-02-10',
    dateReported: '2025-02-10',
    detectionMethods: 'Automated environmental monitoring system alert',
    personWhoObserved: 'Martinez, Carlos',
    personWhoReported: 'Brown, David',
    immediateAction: 'Suspended operations, initiated emergency cleaning protocol',
    backgroundInformation: 'Recent HVAC maintenance may have affected air quality',
    attachmentsDescription: 'Environmental monitoring data, HVAC maintenance records',
    additionalComments: 'Additional personnel training on gowning procedures scheduled',
    finalAnalysis: 'Environment restored to specification, operations resumed'
  },
  {
    id: 'TW-2025-0006',
    name: 'Packaging Label Mismatch',
    description: 'Wrong product labels applied to finished goods containers',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-02-15',
    createdBy: 'Garcia, Maria',
    department: 'Packaging',
    deviationName: 'Product Labeling Error - Batch PG-240215',
    potentialImpact: 'Patient safety risk due to incorrect product identification',
    whatDefectObserved: 'Product A labels applied to Product B containers',
    objectDefectObserved: 'Finished Product Batch PG-240215',
    specifications: 'Each container must have correct product-specific label per SOP-PKG-003',
    issueOccurred: 'Packaging Line 2, Production Floor',
    timeOfOccurrence: '13:15',
    actualDefectOccurrence: '2025-02-15',
    dateDefectDiscovered: '2025-02-15',
    dateReported: '2025-02-15',
    detectionMethods: 'End-of-line inspection by packaging operator',
    personWhoObserved: 'Rodriguez, Ana',
    personWhoReported: 'Garcia, Maria',
    immediateAction: 'Stopped production line, quarantined affected units',
    backgroundInformation: 'Label changeover procedure may not have been followed completely',
    attachmentsDescription: 'Photos of mislabeled products, packaging line setup sheets',
    additionalComments: 'Operator retraining on label changeover procedures required',
    finalAnalysis: 'All affected units relabeled correctly, procedure updated'
  },
  {
    id: 'TW-2025-0007',
    name: 'Computer System Access Violation',
    description: 'Unauthorized access attempt detected in manufacturing execution system',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-02-20',
    createdBy: 'Taylor, Jennifer',
    department: 'Manufacturing',
    deviationName: 'MES System Security Breach Attempt',
    potentialImpact: 'Data integrity and system security potentially compromised',
    whatDefectObserved: 'Failed login attempts with invalid credentials detected',
    objectDefectObserved: 'Manufacturing Execution System (MES)',
    specifications: 'System access limited to authorized personnel per IT-SEC-001',
    issueOccurred: 'Manufacturing Control Room, Production Building',
    timeOfOccurrence: '22:45',
    actualDefectOccurrence: '2025-02-20',
    dateDefectDiscovered: '2025-02-21',
    dateReported: '2025-02-21',
    detectionMethods: 'Automated security monitoring system alert',
    personWhoObserved: 'System Monitoring (Automated)',
    personWhoReported: 'Taylor, Jennifer',
    immediateAction: 'Changed all system passwords, reviewed access logs',
    backgroundInformation: 'Recent staff changes may have created confusion about access rights',
    attachmentsDescription: 'System security logs, access attempt records',
    additionalComments: 'IT security team conducting full system audit',
    finalAnalysis: 'No data compromise found, security protocols enhanced'
  },
  {
    id: 'TW-2025-0008',
    name: 'Cleaning Validation Failure',
    description: 'Residue detected on equipment surface after cleaning procedure',
    classification: 'Complete initial review & impact step',
    createdOn: '2025-02-25',
    createdBy: 'Walker, Amanda',
    department: 'Manufacturing',
    deviationName: 'Mixer M-301 Cleaning Validation Failure',
    potentialImpact: 'Cross-contamination risk for next product batch',
    whatDefectObserved: 'Protein residue detected at 15 ppm (limit: 10 ppm)',
    objectDefectObserved: 'Production Mixer M-301',
    specifications: 'Equipment surfaces must have <10 ppm residue per CV-SOP-001',
    issueOccurred: 'Production Suite 3, Manufacturing Floor',
    timeOfOccurrence: '07:30',
    actualDefectOccurrence: '2025-02-25',
    dateDefectDiscovered: '2025-02-25',
    dateReported: '2025-02-25',
    detectionMethods: 'Post-cleaning swab testing validation',
    personWhoObserved: 'Chen, Michael',
    personWhoReported: 'Walker, Amanda',
    immediateAction: 'Re-cleaned equipment using extended cleaning cycle',
    backgroundInformation: 'New cleaning agent may require procedure adjustment',
    attachmentsDescription: 'Swab test results, cleaning validation data',
    additionalComments: 'Cleaning procedure under review for effectiveness',
    finalAnalysis: 'Equipment re-validated and approved for production use'
  }
];

// Export filter options for components
export const FILTER_OPTIONS = {
  sites: ['All', ...SITE_OPTIONS],
  departments: DEPT_OPTIONS,
  classifications: ['All', ...CLASSIFICATIONS],
  stages: ['All', ...STAGES]
};

// Export filter options in FilterOption format for form components
export const SITE_FILTER_OPTIONS = [
  { value: '', label: 'All Sites' },
  ...SITE_OPTIONS.map(site => ({ value: site, label: site }))
];

export const DEPARTMENT_FILTER_OPTIONS = [
  { value: '', label: 'All Departments' },
  ...DEPT_OPTIONS.filter(dept => dept !== 'All').map(dept => ({ value: dept, label: dept }))
];
