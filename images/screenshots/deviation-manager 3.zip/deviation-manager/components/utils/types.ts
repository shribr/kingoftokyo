import { IconProps } from './icons'

export type { IconProps }

export type TrendType = 'up' | 'down' | 'neutral'

export interface KpiData {
  title: string
  display: string
  value: number
  deltaPct: number
  trend: TrendType
}

// Deviation/Table types
export interface Deviation {
  id: string | number
  name: string
  department: string
  site?: string
  trackwiseRecord?: string
  classification: 'Major' | 'Minor' | 'Moderate'
  stage: string
  date: string
  status?: 'open' | 'investigating' | 'inProgress' | 'resolved' | 'closed'
  title?: string
  assignee: {
    name: string
    avatar?: string
    status?: 'online' | 'away' | 'busy' | 'offline'
  }
  priority?: string
  createdAt?: string
}

export interface TableColumn<T> {
  header: string
  key: string
  render?: (row: T) => React.ReactNode
}

// User/Assignee types
export interface User {
  name: string
  avatar?: string
}
