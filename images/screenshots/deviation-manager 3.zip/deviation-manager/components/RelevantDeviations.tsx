import React from 'react';
import type { TDialogProps } from '~/common';
import { Dialog, DialogPanel, DialogTitle, Transition, TransitionChild } from '@headlessui/react';
import { useLocalize } from '~/hooks';
import { cn } from '~/utils';
import { useRelevantDeviation } from '../queries/useDeviationQueries';
import DataGrid, { DataGridColumn } from '~/features/shared/components/DataGrid';

export default function RelevantDeviations({
  open,
  onOpenChange,
  text,
  start_date,
}: TDialogProps & { text: string; start_date: string }) {
  const localize = useLocalize();
  const {
    data: relevantDeviations,
    refetch,
    isRefetching,
  } = useRelevantDeviation(text, start_date);

  const [isLoading, setIsLoading] = React.useState(false);
  React.useEffect(() => {
    if (open) {
      const fetchData = async () => {
        setIsLoading(true);
        try {
          await refetch();
        } catch (error) {
          console.error('Failed to refetch:', error);
        } finally {
          setIsLoading(false);
        }
      };

      fetchData();
    }
  }, [open, refetch]);

  const columns: DataGridColumn[] = [
    {
      header: localize('rd_short_description_column'),
      accessor: 'short_desc',
      textAlign: 'left',
      width: '4fr',
    },
    {
      header: localize('rd_trackwise_id_column'),
      accessor: 'pr_id',
      textAlign: 'left',
    },
    {
      header: localize('rd_created_on_column'),
      accessor: 'date_created',
      textAlign: 'left',
      format: (value) => {
        if (!value) return '';
        const date = new Date(value);
        return date.toLocaleDateString();
      },
    },
    {
      header: localize('rd_severity_column'),
      accessor: 'classification',
      textAlign: 'left',
    },
    {
      header: localize('rd_score_column'),
      accessor: 'score',
      textAlign: 'left',
      format: (value) => {
        if (!value) return '';
        return Math.round(value * 100) + '%';
      },
    },
  ];

  return (
    <Transition appear show={open}>
      <Dialog as="div" className="relative z-50" onClose={onOpenChange}>
        <TransitionChild
          enter="ease-out duration-200"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black opacity-50 dark:opacity-80" aria-hidden="true" />
        </TransitionChild>

        <TransitionChild
          enter="ease-out duration-200"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="ease-in duration-100"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <div className={cn('fixed inset-0 flex w-screen items-center justify-center p-4')}>
            <DialogPanel
              className={cn(
                'w-full overflow-hidden rounded-xl rounded-b-lg bg-background pb-6 shadow-2xl backdrop-blur-2xl animate-in sm:rounded-2xl',
              )}
            >
              <DialogTitle
                className="mb-1 flex items-center justify-between p-6 pb-5 text-left"
                as="div"
              >
                <h2 className="text-lg font-medium leading-6 text-text-primary">
                  {localize('rd_header_title')}
                </h2>
                <button
                  type="button"
                  title={localize('rd_close_button_title')}
                  className="rounded-sm opacity-70 transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-border-xheavy focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-surface-primary dark:focus:ring-offset-surface-primary"
                  onClick={() => onOpenChange(false)}
                >
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-5 w-5 text-text-primary"
                  >
                    <line x1="18" x2="6" y1="6" y2="18"></line>
                    <line x1="6" x2="18" y1="6" y2="18"></line>
                  </svg>
                </button>
              </DialogTitle>
              <div className="px-6">
                <DataGrid
                  data={relevantDeviations ?? []}
                  columns={columns}
                  isLoading={isLoading}
                  pagination={{ rowsPerPage: 10, resultText: localize('rd_pagination_text') }}
                />
              </div>
            </DialogPanel>
          </div>
        </TransitionChild>
      </Dialog>
    </Transition>
  );
}
