import React from 'react'

interface Task {
  id: string
  title: string
  priority: 'High' | 'Medium' | 'Low'
  dueDate: string
  status: 'pending' | 'in-progress' | 'completed'
}

export const MyTasks: React.FC = () => {
  const tasks: Task[] = [
    {
      id: 'T001',
      title: 'Review deviation TW-315',
      priority: 'High',
      dueDate: '2024-01-20',
      status: 'pending'
    },
    {
      id: 'T002', 
      title: 'Complete CAPA for batch XYZ',
      priority: 'Medium',
      dueDate: '2024-01-25',
      status: 'in-progress'
    },
    {
      id: 'T003',
      title: 'Update training documentation',
      priority: 'Low', 
      dueDate: '2024-01-30',
      status: 'pending'
    },
    {
      id: 'T004',
      title: 'Verify corrective actions',
      priority: 'High',
      dueDate: '2024-01-22',
      status: 'pending'
    },
    {
      id: 'T005',
      title: 'Schedule equipment calibration',
      priority: 'Medium',
      dueDate: '2024-01-28',
      status: 'in-progress'
    }
  ]

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High': return 'bg-red-50 text-red-600 border-red-200 dark:bg-red-900/10 dark:text-red-400 dark:border-red-800/30'
      case 'Medium': return 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-900/10 dark:text-amber-400 dark:border-amber-800/30'
      case 'Low': return 'bg-green-50 text-green-600 border-green-200 dark:bg-green-900/10 dark:text-green-400 dark:border-green-800/30'
      default: return 'bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800/20 dark:text-gray-400 dark:border-gray-700/30'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-50 text-green-600 border-green-200 dark:bg-green-900/10 dark:text-green-400 dark:border-green-800/30'
      case 'in-progress': return 'bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-900/10 dark:text-blue-400 dark:border-blue-800/30'
      case 'pending': return 'bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800/20 dark:text-gray-400 dark:border-gray-700/30'
      default: return 'bg-gray-50 text-gray-600 border-gray-200 dark:bg-gray-800/20 dark:text-gray-400 dark:border-gray-700/30'
    }
  }

  return (
    <div className="bg-white rounded-lg shadow p-4 dark:bg-gray-800 dark:shadow-gray-700">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">My Tasks</h3>
        <a href="#" className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300">View all</a>
      </div>
      
      <div className="space-y-3">
        {tasks.map((task) => (
          <div key={task.id} className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 dark:border-gray-600 dark:hover:bg-gray-700">
            <div className="flex justify-between items-start mb-2">
              <h4 className="text-sm font-medium text-gray-900 flex-1 dark:text-gray-100">{task.title}</h4>
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                {task.priority}
              </span>
            </div>
            
            <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
              <span>Due: {new Date(task.dueDate).toLocaleDateString()}</span>
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(task.status)}`}>
                {task.status.replace('-', ' ')}
              </span>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-3 border-t border-gray-200 dark:border-gray-600">
        <button className="w-full text-sm text-blue-600 hover:text-blue-800 font-medium dark:text-blue-400 dark:hover:text-blue-300">
          + Add new task
        </button>
      </div>
    </div>
  )
}

export default MyTasks
