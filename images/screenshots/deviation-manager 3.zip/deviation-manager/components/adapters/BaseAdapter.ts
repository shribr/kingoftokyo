// Base abstract class for data source adapters
import type { 
  DataSourceConfig, 
  DataSourceResponse, 
  DeviationResponse, 
  KpiResponse, 
  ChartResponse 
} from '../config/types';

export abstract class BaseDataSourceAdapter {
  protected config: DataSourceConfig;
  protected cache: Map<string, { data: any; timestamp: Date; ttl: number }> = new Map();

  constructor(config: DataSourceConfig) {
    this.config = config;
  }

  abstract connect(): Promise<boolean>;
  abstract disconnect(): Promise<void>;
  abstract fetchDeviations(filters?: any, pagination?: any): Promise<DataSourceResponse<DeviationResponse>>;
  abstract fetchKpis(): Promise<DataSourceResponse<KpiResponse>>;
  abstract fetchChartData(chartType: string): Promise<DataSourceResponse<ChartResponse>>;

  // Cache management
  protected setCacheItem(key: string, data: any, ttl: number = 300): void {
    if (this.config.cache?.enabled) {
      this.cache.set(key, {
        data,
        timestamp: new Date(),
        ttl: ttl * 1000 // convert to milliseconds
      });
    }
  }

  protected getCacheItem(key: string): any | null {
    if (!this.config.cache?.enabled) return null;
    
    const item = this.cache.get(key);
    if (!item) return null;

    const now = new Date().getTime();
    const itemTime = item.timestamp.getTime();
    
    if (now - itemTime > item.ttl) {
      this.cache.delete(key);
      return null;
    }

    return item.data;
  }

  protected clearCache(): void {
    this.cache.clear();
  }

  // Health check
  abstract healthCheck(): Promise<boolean>;

  // Utility method to create consistent responses
  protected createResponse<T>(success: boolean, data: T, error?: string): DataSourceResponse<T> {
    return {
      success,
      data,
      error,
      timestamp: new Date(),
      source: this.config.name || this.config.type
    };
  }
}
