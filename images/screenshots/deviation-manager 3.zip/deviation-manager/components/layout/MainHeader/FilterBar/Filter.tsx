import React, { useState } from 'react'

export interface FilterOption {
  value: string
  label: string
}

interface FilterProps {
  id: string
  label: string
  options: FilterOption[]
  value?: string
  placeholder?: string
  onChange?: (value: string) => void
  className?: string
}

// Clear icon SVG component
const ClearIcon: React.FC<{ onClick: () => void }> = ({ onClick }) => (
  <button
    type="button"
    className="flex items-center justify-center p-1 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
    onClick={onClick}
    aria-label="Clear selection"
  >
    <svg className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  </button>
)

export const Filter: React.FC<FilterProps> = ({
  id,
  label,
  options,
  value = '',
  placeholder = `Select ${label.toLowerCase()}...`,
  onChange,
  className = ''
}) => {
  const [selectedValue, setSelectedValue] = useState(value)

  const handleValueChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const newValue = event.target.value
    setSelectedValue(newValue)
    onChange?.(newValue)
  }

  const handleClear = () => {
    setSelectedValue('')
    onChange?.('')
  }

  return (
    <div className={`input-root relative ${className}`}>
      <label className="input-label" htmlFor={id}>
        {label}
      </label>
      <div className="relative">
        <select
          id={id}
          value={selectedValue}
          onChange={handleValueChange}
          className={`w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500 ${selectedValue ? 'pr-8 appearance-none [-webkit-appearance:none] [-moz-appearance:none] [background-image:none]' : 'pr-2.5'}`}
        >
          <option value="" disabled>
            {placeholder}
          </option>
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        {selectedValue && (
          <div className="absolute right-2 top-1/2 -translate-y-1/2 z-10">
            <ClearIcon onClick={handleClear} />
          </div>
        )}
      </div>
    </div>
  )
}

export default Filter
