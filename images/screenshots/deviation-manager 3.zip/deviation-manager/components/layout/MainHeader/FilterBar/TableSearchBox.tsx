import React, { useState } from 'react'

interface TableSearchBoxProps {
  onSearch?: (value: string) => void
  placeholder?: string
}

export const TableSearchBox: React.FC<TableSearchBoxProps> = ({ 
  onSearch,
  placeholder = "Search"
}) => {
  const [searchValue, setSearchValue] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchValue(value)
    onSearch?.(value)
  }

  const handleClear = () => {
    setSearchValue('')
    onSearch?.('')
  }

  return (
    <div className="input-root relative">
      <label className="input-label" htmlFor="search">
        Search
      </label>
      <input
        type="text"
        id="search"
        className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500 pr-8"
        placeholder={placeholder}
        value={searchValue}
        onChange={handleChange}
      />
      {searchValue && (
        <button
          type="button"
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
          onClick={handleClear}
          aria-label="Clear search"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}
    </div>
  )
}

export default TableSearchBox
