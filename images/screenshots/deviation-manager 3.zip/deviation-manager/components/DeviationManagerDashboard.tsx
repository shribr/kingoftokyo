import React, { useState, useEffect } from 'react'
import './dashboard.css'
import Header from './layout/Header'
import Footer from './layout/Footer'
import MainContent from './layout/MainContent'
import MainHeader from './layout/MainHeader'
import KPIs from './KPIs'
import Table from './Table'
import DataVisualization from './DataVisualization'
import MyTasks from './MyTasks'
import { TableProvider } from './context/TableContext'
import AddDeviationRecord from './DeviationForm'
import { ToastProvider } from './common/Toast'
import { useAuthContext } from '~/hooks/AuthContext'
import { DeviationManagerService } from '../services/DeviationManagerService'
import { useDeviationManagerService} from '../hooks/useDeviationManagerService';
import { useGetStartupConfig } from '~/data-provider'

type ViewMode = 'dashboard' | 'add-deviation' | 'api-test'

interface DashboardContentProps {
  userName?: string
  viewMode: ViewMode
  onViewChange: (mode: ViewMode) => void
  onCreateRecord?: () => void
  deviationService: DeviationManagerService
}

const DashboardContent: React.FC<DashboardContentProps> = ({ 
  userName, 
  viewMode, 
  onViewChange,
  onCreateRecord,
  deviationService 
}) => {
  const { user } = useAuthContext();

  // Remove the duplicate service initialization from DashboardContent
  // The service is already being initialized in the parent Dashboard component
  
  // Extract first name from user's full name, with fallbacks
  const getFirstName = () => {
    if (userName) return userName; // Use prop if provided
    
    const fullName = user?.name || user?.username;
    if (!fullName) return 'User';
    
    // Extract first name from full name (split by space and take first part)
    const firstName = fullName.split(' ')[0];
    return firstName || 'User';
  };

  const displayName = getFirstName();
  
  // If we're in add-deviation mode, show the AddDeviationRecord component
  if (viewMode === 'add-deviation') {
    return <AddDeviationRecord onBack={() => onViewChange('dashboard')} />
  }

  // If we're in api-test mode, show the ApiAuthenticationComponent
  if (viewMode === 'api-test') {
    return (
      <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
        <Header activePage="dashboard" />
        <div className="flex-1 overflow-auto p-6">
          <div className="max-w-6xl mx-auto">
            <div className="mb-4">
              <button
                onClick={() => onViewChange('dashboard')}
                className="mb-4 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
              >
                ← Back to Dashboard
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  // Otherwise show the dashboard
  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      <Header activePage="dashboard" />
      
      {/* Scrollable content area with bottom padding for sticky footer */}
      <div className="flex-1 overflow-auto pb-32">
        <MainContent>
          <MainHeader 
            welcomeMessage="Welcome"
            userName={displayName}
            description="Create deviation records, track your tasks and collaborate with investigation teams."
          />

          {/* KPIs Section */}
          <div className="mb-6">
            <KPIs />
          </div>

          {/* Main Content Layout */}
          <div className="space-y-6">
            {/* Table - Full Width */}
            <div>
              <Table />
            </div>

            {/* Bottom Panels - Horizontal Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DataVisualization />
              <MyTasks />
            </div>
          </div>
        </MainContent>
      </div>

      <Footer />
    </div>
  )
}

interface DashboardProps {
  userName?: string
  // Legacy props for backward compatibility
  deviationId?: string
  isEditMode?: boolean
  onGenerate?: (response: any) => void
  onNavigateDetails?: () => void
}

export const Dashboard: React.FC<DashboardProps> = ({ 
  userName, 
  deviationId, 
  isEditMode, 
  onGenerate, 
  onNavigateDetails 
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('dashboard')
  const [deviationService, setDeviationService] = useState<DeviationManagerService | null>(null)
  const [configTimeout, setConfigTimeout] = useState(false)
  
  // Use the startup config hook to get the Azure API base URL
  const startupConfigQuery = useGetStartupConfig()
  const startupConfig = startupConfigQuery.data
  const configLoading = startupConfigQuery.isLoading
  const configError = startupConfigQuery.error

  
  // console.log('Dashboard render - configLoading:', configLoading, 'startupConfig:', startupConfig, 'configError:', configError)
  // console.log('Full startupConfigQuery:', startupConfigQuery)

  // Add a timeout to handle cases where the config never loads
  useEffect(() => {
    const timeout = setTimeout(() => {
      console.warn('Config loading timeout after 15 seconds - this might indicate an issue with the startup config API')
      setConfigTimeout(true)
    }, 15000) // 15 second timeout

    // Clear timeout if config loading completes
    if (configLoading === false || startupConfig) {
      clearTimeout(timeout)
    }

    return () => clearTimeout(timeout)
  }, [configLoading, startupConfig])

  // Initialize the DeviationManagerService when we have config or timeout
  useEffect(() => {
    // console.log('Dashboard useEffect - configLoading:', configLoading, 'startupConfig:', startupConfig, 'configTimeout:', configTimeout)
    
    const initializeService = () => {
      try {
        // Get the Azure API base URL from startup config
        const azureBaseUrl = startupConfig?.cataliaConfig?.deviationManagerBaseUrl
        
        // console.log('Initializing service with azureBaseUrl:', azureBaseUrl)
        
        if (!azureBaseUrl && !configTimeout) {
          // console.log('No azureBaseUrl found and no timeout - waiting for config...')
          return // Don't initialize yet, wait for config
        }
        
        if (!azureBaseUrl && configTimeout) {
          console.warn('No azureBaseUrl found even after timeout - check your startup config for cataliaConfig.deviationComposerBaseUrl')
        }
        
        // Create a new instance of the service with the Azure base URL from config
        const service = new DeviationManagerService(azureBaseUrl)
        
        setDeviationService(service)
        console.log('DeviationManagerService initialized successfully with URL:', service.azureApiBaseUrl || 'undefined (will use sample data)')
        
        // console.log('DeviationManagerService initialized with azureBaseUrl:', azureBaseUrl || 'undefined (will use sample data)')
      } catch (error) {
        console.error('Failed to initialize DeviationManagerService:', error)
        // Fallback to default service without Azure URL
        const fallbackService = new DeviationManagerService()
        setDeviationService(fallbackService)
      }
    }

    // Initialize service when:
    // 1. Config loading is complete (configLoading === false), OR
    // 2. We have config data, OR  
    // 3. We've timed out waiting for config
    if (configLoading === false || startupConfig || configTimeout) {
      initializeService()
    }
  }, [configLoading, startupConfig, configTimeout, configError])

  const handleViewChange = (mode: ViewMode) => {
    setViewMode(mode)
  }

  const handleCreateRecord = () => {
    setViewMode('add-deviation')
  }

  // Show loading while we're waiting for config (unless we've timed out)
  const isWaitingForConfig = (configLoading === true || configLoading === undefined) && !configTimeout && !startupConfig
  
  // console.log('Dashboard render decision - isWaitingForConfig:', isWaitingForConfig, 'breakdown:', {
  //   configLoading,
  //   configTimeout,
  //   hasStartupConfig: !!startupConfig,
  //   hasDeviationService: !!deviationService
  // })

  if (isWaitingForConfig) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">
            Loading startup configuration...
          </p>
          {/* <p className="mt-2 text-sm text-gray-500">
            Waiting for Azure API base URL from config
          </p>
          <p className="mt-1 text-xs text-gray-400">
            Debug: configLoading={String(configLoading)}, hasConfig={String(!!startupConfig)}, timeout={String(configTimeout)}
          </p> */}
        </div>
      </div>
    )
  }

  // If we don't have a service yet, show initialization loading
  if (!deviationService) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">
            Initializing Deviation Manager...
          </p>
          <p className="mt-2 text-sm text-gray-500">
            {startupConfig?.cataliaConfig?.deviationComposerBaseUrl 
              ? `Using API: ${startupConfig.cataliaConfig.deviationComposerBaseUrl}` 
              : 'No API URL configured - will use sample data'}
          </p>
        </div>
      </div>
    )
  }

  return (
    <ToastProvider>
      <TableProvider onCreateRecord={handleCreateRecord}>
        <DashboardContent 
          userName={userName} 
          viewMode={viewMode}
          onViewChange={handleViewChange}
          onCreateRecord={handleCreateRecord}
          deviationService={deviationService}
        />
      </TableProvider>
    </ToastProvider>
  )
}

export default Dashboard
