import React, { useState, useEffect, useCallback } from 'react'
import { 
  Header, 
  Footer, 
  MainContent, 
  Stepper, 
  FormCard, 
  InvestigationAssistant, 
  FormField, 
  TextAreaField, 
  SelectField,
  VerticalProgressPane,
  type Step,
  type AssistantTip,
  type ProgressStep
} from '.'
import Filter, { type FilterOption } from './layout/MainHeader/FilterBar/Filter'
import TableSearchBox from './layout/MainHeader/FilterBar/TableSearchBox'
import RelevantDeviationSearchBox from './RelevantDeviationSearchBox'
import { TRACKWISE_RECORDS, DEVIATION_RECORDS, SITE_FILTER_OPTIONS, DEPARTMENT_FILTER_OPTIONS, type TrackwiseRecord, type DeviationRecord } from './utils/data'
import './dashboard.css'

// ADProfileCell component (extracted from Table)
interface ADProfileCellProps {
  user: {
    name: string
    avatar?: string
    status?: 'online' | 'away' | 'busy' | 'offline'
  }
}

const ADProfileCell: React.FC<ADProfileCellProps> = ({ user }) => {
  const getStatusColor = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'bg-green-500'
      case 'away': return 'bg-yellow-500'
      case 'busy': return 'bg-red-500'
      case 'offline': return 'bg-gray-400'
      default: return 'bg-gray-400'
    }
  }

  const getStatusTitle = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'Online'
      case 'away': return 'Away'
      case 'busy': return 'Busy'
      case 'offline': return 'Offline'
      default: return 'Unknown'
    }
  }

  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="relative flex-shrink-0">
        <div className="h-8 w-8 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center dark:bg-gray-600 dark:border-gray-500">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" className="text-gray-600 dark:text-gray-300">
            <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm0 2c-4.418 0-8 2.239-8 5v1h16v-1c0-2.761-3.582-5-8-5z"/>
          </svg>
        </div>
        <div 
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white dark:border-gray-800 ${getStatusColor(user.status)}`}
          title={getStatusTitle(user.status)}
        />
      </div>
      <span className="text-xs text-gray-900 truncate dark:text-gray-100">{user.name}</span>
    </div>
  )
}

interface FormData {
  // Header fields
  deviationName: string
  site: string
  department: string
  assignee: string
  createdOn: string
  stage: string
  
  // Selected Trackwise record
  selectedTrackwiseRecord: TrackwiseRecord | null
  
  // Intake step fields
  trackwiseSearchQuery: string
  whatDefectObserved: string
  objectDefectObserved: string
  wantSpecifications: string
  issueOccurred: string
  dateOccurrence: string
  timeOccurrence: string
  dateDetection: string
  impactOfIssue: string
  processStepDefect: string
  whoInvolvedProcess: string
  whoObservedIssue: string
  processDescription: string
  immediateActions: string
  materialsToolsEquipment: string
  supportingDocuments: string[]
  
  // Step 2: Initial Review & Impact fields
  riskQuestion1: 'yes' | 'no' | ''
  riskQuestion2: 'yes' | 'no' | ''
  riskQuestion3: 'yes' | 'no' | ''
  riskQuestion4: 'yes' | 'no' | ''
  severityLevel: 'high' | 'medium' | 'low' | ''
  severityAdditionalDetails: string
  detectionLevel: 'high' | 'medium' | 'low' | ''
  detectionAdditionalDetails: string
  occurrenceLevel: 'high' | 'medium' | 'low' | ''
  occurrenceAdditionalDetails: string
  rpnScore: string
  localClassification: 'yes' | 'no' | 'not-applicable' | ''
  deviationClassification: 'major' | 'moderate' | 'minor' | ''
  teamCommitteeAgreement: 'yes' | 'no' | ''
  
  // Other step fields (for future use)
  shortDescription: string
  description: string
  riskAnalysis: string
  impactAnalysis: string
  finalAnalysis: string
}

interface AddDeviationRecordProps {
  onBack?: () => void
}

const DeviationForm: React.FC<AddDeviationRecordProps> = ({ onBack }) => {

  const [formData, setFormData] = useState<FormData>({
    // Header fields
    deviationName: '',
    site: '',
    department: '',
    assignee: '',
    createdOn: new Date().toISOString().split('T')[0],
    stage: 'Intake',
    
    // Selected Trackwise record
    selectedTrackwiseRecord: null,
    
    // Intake step fields
    trackwiseSearchQuery: '',
    whatDefectObserved: '',
    objectDefectObserved: '',
    wantSpecifications: '',
    issueOccurred: '',
    dateOccurrence: '',
    timeOccurrence: '',
    dateDetection: '',
    impactOfIssue: '',
    processStepDefect: '',
    whoInvolvedProcess: '',
    whoObservedIssue: '',
    processDescription: '',
    immediateActions: '',
    materialsToolsEquipment: '',
    supportingDocuments: [],
    
    // Step 2: Initial Review & Impact fields
    riskQuestion1: '',
    riskQuestion2: '',
    riskQuestion3: '',
    riskQuestion4: '',
    severityLevel: '',
    severityAdditionalDetails: '',
    detectionLevel: '',
    detectionAdditionalDetails: '',
    occurrenceLevel: '',
    occurrenceAdditionalDetails: '',
    rpnScore: '',
    localClassification: '',
    deviationClassification: '',
    teamCommitteeAgreement: '',
    
    // Other step fields
    shortDescription: '',
    description: '',
    riskAnalysis: '',
    impactAnalysis: '',
    finalAnalysis: ''
  })

  const [currentStep, setCurrentStep] = useState(1) // Start at step 1 for normal operation
  const [visitedStep, setVisitedStep] = useState(1) // Tracks the highest step the user can legitimately access
  const [filteredTrackwiseRecords, setFilteredTrackwiseRecords] = useState<TrackwiseRecord[]>([])
  const [showTrackwiseDropdown, setShowTrackwiseDropdown] = useState(false)

  // Function to get stage based on current step
  const getStageForStep = (step: number): string => {
    switch (step) {
      case 1:
        return 'Intake';
      case 2:
        return 'Initial review & impact';
      case 3:
        return 'Investigation & RCA';
      case 4:
        return 'CAPA & conclusion';
      default:
        return 'Intake';
    }
  };

  // Step validation functions - each checks only its own requirements
  const isStep1RequirementsMet = (): boolean => {
    return !!(
      formData.deviationName.trim() &&
      formData.whatDefectObserved.trim() &&
      formData.objectDefectObserved.trim() &&
      formData.wantSpecifications.trim() &&
      formData.issueOccurred.trim() &&
      formData.dateOccurrence &&
      formData.timeOccurrence &&
      formData.dateDetection &&
      formData.impactOfIssue.trim() &&
      formData.processStepDefect.trim() &&
      formData.whoInvolvedProcess.trim() &&
      formData.whoObservedIssue.trim() &&
      formData.processDescription.trim() &&
      formData.immediateActions.trim() &&
      formData.materialsToolsEquipment.trim()
    );
  };

  const isStep2RequirementsMet = (): boolean => {
    return !!(
      formData.riskQuestion1 &&
      formData.riskQuestion2 &&
      formData.riskQuestion3 &&
      formData.riskQuestion4 &&
      formData.severityLevel &&
      formData.detectionLevel &&
      formData.occurrenceLevel &&
      formData.localClassification &&
      formData.teamCommitteeAgreement
    );
  };

  const isStep3RequirementsMet = (): boolean => {
    return !!(
      formData.riskAnalysis.trim() &&
      formData.impactAnalysis.trim()
    );
  };

  const isStep4RequirementsMet = (): boolean => {
    return !!(
      formData.finalAnalysis.trim()
    );
  };

  // Step completion functions - check if step is complete (own requirements + all previous steps)
  const isStep1Complete = (): boolean => {
    return isStep1RequirementsMet();
  };

  const isStep2Complete = (): boolean => {
    return isStep1RequirementsMet() && isStep2RequirementsMet();
  };

  const isStep3Complete = (): boolean => {
    return isStep1RequirementsMet() && isStep2RequirementsMet() && isStep3RequirementsMet();
  };

  const isStep4Complete = (): boolean => {
    return isStep1RequirementsMet() && isStep2RequirementsMet() && isStep3RequirementsMet() && isStep4RequirementsMet();
  };

  // Function to check if a step can be accessed
  const canAccessStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return true;
      case 2:
        return isStep1RequirementsMet();
      case 3:
        return isStep1RequirementsMet() && isStep2RequirementsMet();
      case 4:
        return isStep1RequirementsMet() && isStep2RequirementsMet() && isStep3RequirementsMet();
      default:
        return false;
    }
  };

  // Function to get the highest accessible step
  const getHighestAccessibleStep = (): number => {
    if (canAccessStep(4)) return 4;
    if (canAccessStep(3)) return 3;
    if (canAccessStep(2)) return 2;
    return 1;
  };

  // Function to get the legitimate current step (where user should be working)
  const getLegitimateCurrentStep = (): number => {
    return getHighestAccessibleStep();
  };

  // Function to handle step navigation
  const handleStepNavigation = (targetStep: number) => {
    // Always allow navigation to the target step (for preview purposes)
    setCurrentStep(targetStep);
    
    // Update visitedStep only if this step is legitimately accessible
    if (canAccessStep(targetStep)) {
      setVisitedStep(Math.max(visitedStep, targetStep));
    }
  };

  // Function to determine if current step is properly accessible (not just previewed)
  const isCurrentStepAccessible = (): boolean => {
    return canAccessStep(currentStep);
  };

  // Function to determine if form elements should be disabled
  const shouldDisableFormElements = (): boolean => {
    return !isCurrentStepAccessible();
  };

  // Update stage when currentStep changes
  useEffect(() => {
    setFormData(prev => ({
      ...prev,
      stage: getStageForStep(currentStep)
    }));
  }, [currentStep]);

  // Update visitedStep when accessibility changes
  useEffect(() => {
    const highestAccessible = getHighestAccessibleStep();
    setVisitedStep(Math.max(visitedStep, highestAccessible));
  }, [formData.deviationName, formData.whatDefectObserved, formData.objectDefectObserved, formData.wantSpecifications, formData.issueOccurred, formData.dateOccurrence, formData.timeOccurrence, formData.dateDetection, formData.impactOfIssue, formData.processStepDefect, formData.whoInvolvedProcess, formData.whoObservedIssue, formData.processDescription, formData.immediateActions, formData.materialsToolsEquipment, formData.riskQuestion1, formData.riskQuestion2, formData.riskQuestion3, formData.riskQuestion4, formData.severityLevel, formData.detectionLevel, formData.occurrenceLevel, formData.localClassification, formData.teamCommitteeAgreement, formData.riskAnalysis, formData.impactAnalysis]);

  // Define the deviation process steps
  const deviationSteps: Step[] = [
    { id: 1, label: 'Intake' },
    { id: 2, label: 'Initial review & impact' },
    { id: 3, label: 'Investigation & RCA' },
    { id: 4, label: 'CAPA & conclusion' }
  ]

  // Define the progress steps for the vertical pane
  const progressSteps: ProgressStep[] = [
    { 
      id: 1, 
      label: 'Intake', 
      description: 'Collect initial deviation information',
      completed: isStep1Complete()
    },
    { 
      id: 2, 
      label: 'Initial review & impact', 
      description: 'Assess risk and impact',
      completed: isStep2Complete()
    },
    { 
      id: 3, 
      label: 'Investigation & RCA', 
      description: 'Conduct root cause analysis',
      completed: isStep3Complete()
    },
    { 
      id: 4, 
      label: 'CAPA & conclusion', 
      description: 'Define corrective actions',
      completed: isStep4Complete()
    }
  ]

  // Function to get the next step's label
  const getNextStepLabel = (currentStep: number): string => {
    const nextStep = deviationSteps.find(step => step.id === currentStep + 1);
    return nextStep ? nextStep.label : 'Next Step';
  };

  // Function to get the previous step's label
  const getPreviousStepLabel = (currentStep: number): string => {
    const previousStep = deviationSteps.find(step => step.id === currentStep - 1);
    return previousStep ? `Step ${previousStep.id}` : 'Previous Step';
  };

  // Define the assistant tips
  const assistantTips: AssistantTip[] = [
    {
      id: 'getting-started',
      icon: '💡',
      title: 'Getting Started',
      description: 'Fill out the basic information to begin. The AI will help classify the deviation and suggest investigation steps.',
      color: 'blue'
    },
    {
      id: 'ai-analysis',
      icon: '🤖',
      title: 'AI Analysis',
      description: 'Once created, I\'ll analyze the deviation and provide risk classification recommendations.',
      color: 'green'
    },
    {
      id: 'next-steps',
      icon: '📋',
      title: 'Next Steps',
      description: 'After creation, you\'ll be able to start the guided investigation process.',
      color: 'purple'
    }
  ]

  // Define stage options
  const stageOptions = [
    { value: 'Intake', label: 'Intake' },
    { value: 'Initial review & impact', label: 'Initial review & impact' },
    { value: 'Investigation & RCA', label: 'Investigation & RCA' },
    { value: 'CAPA & conclusion', label: 'CAPA & conclusion' },
    { value: 'Verification', label: 'Verification' }
  ]

  // RPN Calculation
  const calculateRPN = (severity: string, detection: string, occurrence: string) => {
    // Updated scoring system based on screenshot requirements
    const severityScore = severity === 'high' ? 6 : severity === 'medium' ? 2 : severity === 'low' ? 1 : 0
    const detectionScore = detection === 'high' ? 1 : detection === 'medium' ? 3 : detection === 'low' ? 10 : 0
    const occurrenceScore = occurrence === 'high' ? 5 : occurrence === 'medium' ? 2 : occurrence === 'low' ? 1 : 0
    
    const rpn = severityScore * detectionScore * occurrenceScore
    
    // Determine classification based on new RPN score thresholds
    let classification: 'major' | 'moderate' | 'minor' | '' = ''
    if (rpn > 59) {
      classification = 'major'
    } else if (rpn >= 15) {
      classification = 'moderate'
    } else if (rpn > 0) {
      classification = 'minor'
    }
    
    setFormData(prev => ({ 
      ...prev, 
      rpnScore: rpn.toString(),
      deviationClassification: classification
    }))
  }

  // Update RPN when severity, detection, or occurrence changes
  useEffect(() => {
    if (formData.severityLevel && formData.detectionLevel && formData.occurrenceLevel) {
      calculateRPN(formData.severityLevel, formData.detectionLevel, formData.occurrenceLevel)
    }
  }, [formData.severityLevel, formData.detectionLevel, formData.occurrenceLevel])

  // Get RPN classification display info
  const getRPNClassificationInfo = () => {
    const score = parseInt(formData.rpnScore) || 0
    const severityScore = formData.severityLevel === 'high' ? 6 : formData.severityLevel === 'medium' ? 2 : formData.severityLevel === 'low' ? 1 : 0
    const detectionScore = formData.detectionLevel === 'high' ? 1 : formData.detectionLevel === 'medium' ? 3 : formData.detectionLevel === 'low' ? 10 : 0
    const occurrenceScore = formData.occurrenceLevel === 'high' ? 5 : formData.occurrenceLevel === 'medium' ? 2 : formData.occurrenceLevel === 'low' ? 1 : 0
    
    if (score > 59) {
      return {
        classification: 'major',
        color: 'text-red-600',
        bgColor: 'bg-red-100',
        borderColor: 'border-red-200'
      }
    } else if (score >= 15) {
      return {
        classification: 'moderate',
        color: 'text-yellow-600',
        bgColor: 'bg-yellow-100',
        borderColor: 'border-yellow-200'
      }
    } else {
      return {
        classification: 'minor',
        color: 'text-green-600',
        bgColor: 'bg-green-100',
        borderColor: 'border-green-200'
      }
    }
  }

  // Check if any of the first 4 risk questions is answered "yes"
  const hasYesAnswerInRiskQuestions = () => {
    return formData.riskQuestion1 === 'yes' || 
           formData.riskQuestion2 === 'yes' || 
           formData.riskQuestion3 === 'yes' || 
           formData.riskQuestion4 === 'yes'
  }

  const handleInputChange = (field: keyof FormData, value: string | string[] | TrackwiseRecord | null) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }))
  }

  // Handle Trackwise record search
  const handleTrackwiseSearch = (query: string) => {
    setFormData(prev => ({ ...prev, trackwiseSearchQuery: query }))
    
    if (query.trim() === '') {
      setFilteredTrackwiseRecords([])
      setShowTrackwiseDropdown(false)
      return
    }

    const filtered = TRACKWISE_RECORDS.filter(record => 
      record.id.toLowerCase().includes(query.toLowerCase()) ||
      record.name.toLowerCase().includes(query.toLowerCase()) ||
      record.description.toLowerCase().includes(query.toLowerCase())
    )
    
    setFilteredTrackwiseRecords(filtered)
    setShowTrackwiseDropdown(true)
  }

  // Handle Trackwise record selection
  const handleTrackwiseSelect = (record: TrackwiseRecord) => {
    setFormData(prev => ({ 
      ...prev, 
      selectedTrackwiseRecord: record,
      trackwiseSearchQuery: '',
      department: record.department,
      // Populate all form fields from the selected record
      deviationName: record.deviationName,
      whatDefectObserved: record.whatDefectObserved,
      objectDefectObserved: record.objectDefectObserved,
      wantSpecifications: record.specifications,
      issueOccurred: record.issueOccurred,
      timeOccurrence: record.timeOfOccurrence,
      dateOccurrence: record.actualDefectOccurrence,
      dateDetection: record.dateDefectDiscovered,
      impactOfIssue: record.potentialImpact,
      processStepDefect: record.detectionMethods,
      whoInvolvedProcess: record.personWhoReported,
      whoObservedIssue: record.personWhoObserved,
      processDescription: record.backgroundInformation,
      immediateActions: record.immediateAction,
      materialsToolsEquipment: record.attachmentsDescription,
      description: record.description,
      finalAnalysis: record.finalAnalysis,
      shortDescription: record.additionalComments
    }))
    setShowTrackwiseDropdown(false)
  }

  // Handle removing selected Trackwise record
  const handleTrackwiseRemove = () => {
    setFormData(prev => ({ 
      ...prev, 
      selectedTrackwiseRecord: null,
      // Clear all form fields that were populated from the record
      deviationName: '',
      whatDefectObserved: '',
      objectDefectObserved: '',
      wantSpecifications: '',
      issueOccurred: '',
      timeOccurrence: '',
      dateOccurrence: '',
      dateDetection: '',
      impactOfIssue: '',
      processStepDefect: '',
      whoInvolvedProcess: '',
      whoObservedIssue: '',
      processDescription: '',
      immediateActions: '',
      materialsToolsEquipment: '',
      description: '',
      finalAnalysis: '',
      shortDescription: ''
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission logic here
  }

  const handleCancel = () => {
    if (onBack) {
      onBack()
    } else {
      // Fallback to browser history
      window.history.back()
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
      <Header activePage="deviations" />
      
      {/* Main Layout with Progress Pane */}
      <div className="flex-1 flex overflow-hidden">
        {/* Vertical Progress Pane */}
        <VerticalProgressPane 
          steps={progressSteps} 
          currentStep={currentStep}
          visitedStep={visitedStep}
          canAccessStep={canAccessStep}
          getLegitimateCurrentStep={getLegitimateCurrentStep}
          onStepClick={handleStepNavigation}
          className="flex-shrink-0"
        />
        
        {/* Scrollable content area with bottom padding for sticky footer */}
        <div className="flex-1 overflow-auto pb-32">
          <MainContent>
            {/* Breadcrumb */}
            <div className="mb-6">
              <button 
                onClick={handleCancel}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                ← Back to dashboard
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
              {/* Main Content */}
              <div className="lg:col-span-4">
              {/* Header Section - Outside white container */}
              <div className="mb-6">
                <div className="flex items-start justify-between mb-2">
                  {currentStep === 1 ? (
                    <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 italic">
                      New Record
                    </h1>
                  ) : (
                    <div className="flex-1 mr-4">
                      <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                        Deviation Name
                      </label>
                      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
                        <div className="flex items-center">
                          <h1 className="text-lg font-bold text-gray-900 dark:text-gray-100 italic">
                            {formData.deviationName || 'Untitled Deviation'}
                          </h1>
                          <span className="ml-1 text-blue-600 dark:text-blue-400 font-bold">*</span>
                        </div>
                        <div className="text-xs italic text-gray-600 dark:text-gray-400 mt-1">
                          * new record
                        </div>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center space-x-4">
                    <div className="w-40">
                      <Filter
                        id="header-site"
                        label="Site"
                        options={SITE_FILTER_OPTIONS}
                        value={formData.site}
                        onChange={(value) => handleInputChange('site', value)}
                      />
                    </div>
                    <div className="w-44">
                      <Filter
                        id="header-department"
                        label="Department"
                        options={DEPARTMENT_FILTER_OPTIONS}
                        value={formData.department}
                        onChange={(value) => handleInputChange('department', value)}
                      />
                    </div>
                  </div>
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400 italic">
                  Complete all required information to complete a new record
                </div>
              </div>

              {/* Record Info Box */}
              <FormCard>
                <div className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                        {currentStep === 1 ? 'Trackwise Record' : 'Deviation Record'}
                      </label>
                      {currentStep === 1 ? (
                        // Step 1: Show selected Trackwise record or [none selected]
                        <div className="relative bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md p-3 inline-block min-w-80 max-w-md">
                          <div className="pr-8">
                            {formData.selectedTrackwiseRecord ? (
                              <>
                                <div className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">
                                  {formData.selectedTrackwiseRecord.id}
                                </div>
                                <div className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                                  {formData.selectedTrackwiseRecord.name}
                                </div>
                                <div className="space-y-1">
                                  <div className="text-xs text-gray-500 dark:text-gray-500">
                                    <span className="font-medium">Classification:</span> {formData.selectedTrackwiseRecord.classification}
                                  </div>
                                  <div className="text-xs text-gray-500 dark:text-gray-500">
                                    <span className="font-medium">Created:</span> {new Date(formData.selectedTrackwiseRecord.createdOn).toLocaleDateString('en-US', { 
                                      year: 'numeric', 
                                      month: 'short', 
                                      day: 'numeric' 
                                    })}
                                  </div>
                                </div>
                              </>
                            ) : (
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                [none selected]
                              </div>
                            )}
                          </div>
                        </div>
                      ) : (
                        // Step 2+: Show generated Deviation ID
                        <div className="relative bg-gray-50 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded-md p-3 inline-block min-w-80 max-w-md">
                          <div className="pr-8">
                            <div className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-2">
                              #DEV-2025-042
                            </div>
                            <div className="space-y-1">
                              <div className="text-xs text-gray-500 dark:text-gray-500">
                                <span className="font-medium">Status:</span> {formData.stage}
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-500">
                                <span className="font-medium">Created:</span> {new Date(formData.createdOn).toLocaleDateString('en-US', { 
                                  year: 'numeric', 
                                  month: 'short', 
                                  day: 'numeric' 
                                })}
                              </div>
                              {(formData.deviationClassification || (formData.severityLevel && formData.detectionLevel && formData.occurrenceLevel)) && (
                                <div className="text-xs text-gray-500 dark:text-gray-500 flex items-center">
                                  <span className="font-medium">Classification:</span> 
                                  <span className={`ml-2 px-2 py-1 rounded text-xs font-medium capitalize ${getRPNClassificationInfo().bgColor} ${getRPNClassificationInfo().color} ${getRPNClassificationInfo().borderColor} border`}>
                                    {formData.deviationClassification || getRPNClassificationInfo().classification}
                                  </span>
                                  {currentStep === 3 && (
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setCurrentStep(2)
                                        // Scroll to RPN calculation section after a short delay to allow step change
                                        setTimeout(() => {
                                          const rpnSection = document.querySelector('h4')?.closest('div')?.parentElement?.querySelector('div:has(h4:contains("RPN calculation"))')
                                          if (rpnSection) {
                                            rpnSection.scrollIntoView({ behavior: 'smooth', block: 'start' })
                                          } else {
                                            // Fallback: scroll to any element containing "RPN calculation" text
                                            const rpnElement = Array.from(document.querySelectorAll('h4')).find(el => 
                                              el.textContent?.includes('RPN calculation')
                                            )?.parentElement
                                            if (rpnElement) {
                                              rpnElement.scrollIntoView({ behavior: 'smooth', block: 'start' })
                                            }
                                          }
                                        }, 100)
                                      }}
                                      className="ml-2 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 flex items-center"
                                    >
                                      Recalculate classification
                                      <svg className="ml-1 h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm1 2a1 1 0 000 2h6a1 1 0 100-2H7zm6 7a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zM7 8a1 1 0 000 2h6a1 1 0 100-2H7zm0 4a1 1 0 100 2h3a1 1 0 100-2H7z" clipRule="evenodd" />
                                      </svg>
                                    </button>
                                  )}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-start space-x-6">
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Assignee
                        </label>
                        <ADProfileCell user={{ name: formData.assignee || 'Silva, Miguel', status: 'online' }} />
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Created On
                        </label>
                        <span className="text-xs text-gray-900 dark:text-gray-100">
                          {new Date(formData.createdOn).toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                          })}
                        </span>
                      </div>
                      
                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Stage
                        </label>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200">
                          {formData.stage}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </FormCard>

              {/* Stepper - On light gray background */}
              <div className="my-6">
                <Stepper 
                  steps={deviationSteps} 
                  currentStep={currentStep} 
                  visitedStep={visitedStep}
                  canAccessStep={canAccessStep}
                  getLegitimateCurrentStep={getLegitimateCurrentStep}
                  onStepClick={handleStepNavigation}
                />
              </div>

              {/* Step Information Header */}
              <div className="mb-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {currentStep === 1 ? 'Intake Information' : 
                     currentStep === 2 ? 'Impact Analysis & Risk Priority Number (RPN)' :
                     currentStep === 3 ? 'Investigation & RCA' : 
                     'CAPA & Conclusion'}
                  </h3>
                  {!isCurrentStepAccessible() && (
                    <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800 border border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-400 dark:border-yellow-700">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      Complete previous required steps before continuing
                    </div>
                  )}
                </div>
              </div>

              {/* Instruction Text */}
              <div className="mb-6">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {currentStep === 1 ? 'Select an existing opened deviation from Trackwise using the Trackwise record search field or continue manually by filling out the details below.' :
                   currentStep === 2 ? 'Complete all required information to complete a new record' :
                   currentStep === 3 ? 'Conduct investigation and root cause analysis.' :
                   'Define corrective and preventive actions and conclude the deviation.'}
                </p>
              </div>

              {/* Step Content */}
              {currentStep === 1 && (
                /* Step 1: Intake - Existing content */
                <FormCard>
                  <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
                    {shouldDisableFormElements() && (
                      <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
                    )}
                    <form onSubmit={handleSubmit}>
                    <div className="space-y-6">
                      {/* Select existing record section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Select existing record from Trackwise
                          </h4>
                        </div>
                        
                        {/* Content area with nested container */}
                        <div className="p-6">
                          <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
                            <div className="flex items-center space-x-2 mb-3">
                              <svg className="h-5 w-5 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                              </svg>
                              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Select existing record
                              </span>
                            </div>
                            
                            <div className="text-xs text-gray-500 mb-4">
                              Select an existing Trackwise record that was already opened in Trackwise to populate the intake form below.
                            </div>
                            
                            <div className="space-y-3 relative">
                              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">
                                Trackwise record
                              </label>
                              <div className="relative">
                                <input
                                  type="text"
                                  className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500 pr-8"
                                  placeholder="Search for existing Trackwise record..."
                                  onChange={(e) => handleTrackwiseSearch(e.target.value)}
                                />
                                <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                                  <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                  </svg>
                                </div>
                              </div>
                              
                              {/* Trackwise Search Results Dropdown */}
                              {showTrackwiseDropdown && filteredTrackwiseRecords.length > 0 && (
                                <div className="absolute top-full left-0 z-10 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-y-auto mt-1 min-w-80 w-auto max-w-md">
                                  {filteredTrackwiseRecords.map((record) => (
                                    <button
                                      key={record.id}
                                      type="button"
                                      onClick={() => handleTrackwiseSelect(record)}
                                      className="w-full text-left px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-b-0 whitespace-nowrap"
                                    >
                                      <div className="font-medium text-sm text-gray-900 dark:text-gray-100">
                                        {record.id}
                                      </div>
                                      <div className="text-sm text-gray-600 dark:text-gray-400 truncate">
                                        {record.name}
                                      </div>
                                      <div className="text-xs text-gray-500 dark:text-gray-500 truncate">
                                        {record.department} • Created by {record.createdBy}
                                      </div>
                                    </button>
                                  ))}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Manually Enter Section */}
                      <div>
                        {/* Manually Enter Header with light gray background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Manually enter
                          </h4>
                        </div>
                        
                        <div className="p-8 space-y-8">
                          {/* Row 1: Deviation Name and What defect was observed */}
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                            <FormField
                              id="deviationName"
                              label="Deviation Name"
                              value={formData.deviationName}
                              onChange={(value) => handleInputChange('deviationName', value)}
                              placeholder="Auto populated from Trackwise or manually enter a name of your choice"
                              required
                            />
                            
                            <FormField
                              id="whatDefectObserved"
                              label="What defect was observed?"
                              value={formData.whatDefectObserved}
                              onChange={(value) => handleInputChange('whatDefectObserved', value)}
                              placeholder="What was the deviation for? What is out of specification?"
                            />
                          </div>

                          {/* Row 2: Object and Specifications */}
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                            <FormField
                              id="objectDefectObserved"
                              label="In which object was the defect observed?"
                              value={formData.objectDefectObserved}
                              onChange={(value) => handleInputChange('objectDefectObserved', value)}
                              placeholder="For example, what product, material, equipment, etc. is impacted?"
                            />
                            
                            <FormField
                              id="wantSpecifications"
                              label="What were the specifications or requirements?"
                              value={formData.wantSpecifications}
                              onChange={(value) => handleInputChange('wantSpecifications', value)}
                              placeholder="What were the specifications or requirements?"
                            />
                          </div>

                          {/* Row 3: Location, Date, Time of Occurrence (3 columns) */}
                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <FormField
                              id="issueOccurred"
                              label="Where did the issue occur?"
                              value={formData.issueOccurred}
                              onChange={(value) => handleInputChange('issueOccurred', value)}
                              placeholder="Physical location or area where the issue occurred"
                            />
                            
                            <FormField
                              id="dateOccurrence"
                              label="Date of occurrence"
                              type="date"
                              value={formData.dateOccurrence}
                              onChange={(value) => handleInputChange('dateOccurrence', value)}
                            />
                            
                            <div>
                              <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                                Time of occurrence
                              </label>
                              <input
                                id="timeOccurrence"
                                type="time"
                                value={formData.timeOccurrence}
                                onChange={(e) => handleInputChange('timeOccurrence', e.target.value)}
                                className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                                aria-label="Time of occurrence"
                              />
                            </div>
                          </div>

                          {/* Row 4: Process Step, Date Detection, Impact (3 columns) */}
                          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                            <FormField
                              id="processStepDefect"
                              label="What process step did this occur at?"
                              value={formData.processStepDefect}
                              onChange={(value) => handleInputChange('processStepDefect', value)}
                              placeholder="What step in the batch record or SOP?"
                            />
                            
                            <FormField
                              id="dateDetection"
                              label="Date of detection"
                              type="date"
                              value={formData.dateDetection}
                              onChange={(value) => handleInputChange('dateDetection', value)}
                            />
                            
                            <FormField
                              id="impactOfIssue"
                              label="What is the impact of the issue?"
                              value={formData.impactOfIssue}
                              onChange={(value) => handleInputChange('impactOfIssue', value)}
                              placeholder="E.g. batch over limit"
                            />
                          </div>

                          {/* Row 5: Who was involved and Who observed (2 columns) */}
                          <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                            <FormField
                              id="whoInvolvedProcess"
                              label="Who was involved in the process?"
                              value={formData.whoInvolvedProcess}
                              onChange={(value) => handleInputChange('whoInvolvedProcess', value)}
                              placeholder="People who performed the process"
                            />
                            
                            <FormField
                              id="whoObservedIssue"
                              label="Who observed the issue?"
                              value={formData.whoObservedIssue}
                              onChange={(value) => handleInputChange('whoObservedIssue', value)}
                              placeholder="People who witnessed the process"
                            />
                          </div>

                          {/* Row 6: Process Description (1 column) */}
                          <div className="space-y-6">
                            <TextAreaField
                              id="processDescription"
                              label="Provide a brief description of the process involved"
                              value={formData.processDescription}
                              onChange={(value) => handleInputChange('processDescription', value)}
                              placeholder="What happened?"
                            />
                          </div>

                          {/* Row 7: Immediate Actions (1 column) */}
                          <div className="space-y-6">
                            <TextAreaField
                              id="immediateActions"
                              label="What immediate actions were taken?"
                              value={formData.immediateActions}
                              onChange={(value) => handleInputChange('immediateActions', value)}
                              placeholder="What has been done to adopt Has anything been put on hold?"
                            />
                          </div>

                          {/* Row 8: Materials and Equipment (1 column) */}
                          <div className="space-y-6">
                            <TextAreaField
                              id="materialsToolsEquipment"
                              label="List the materials, tools and equipment used in the process"
                              value={formData.materialsToolsEquipment}
                              onChange={(value) => handleInputChange('materialsToolsEquipment', value)}
                              placeholder="List the materials, tools and equipment used in the process"
                            />
                          </div>

                          {/* Upload supporting documents */}
                          <div className="space-y-4">
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                              Upload supporting documents
                            </label>
                            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                              <div className="space-y-2">
                                <div className="mx-auto h-12 w-12 text-gray-400">
                                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                  </svg>
                                </div>
                                <div className="text-sm text-gray-600 dark:text-gray-400">
                                  <span className="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">
                                    Drag & drop or browse files
                                  </span>
                                </div>
                                <div className="text-xs text-gray-500">
                                  Supported file types: pdf • docx • xlsx • csv • Max file size: 25 MB
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Similar occurrence deviations */}
                          <div className="space-y-4">
                            <div className="flex items-center space-x-2">
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Similar occurrence deviations
                              </label>
                              <div className="text-gray-400">
                                <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                                </svg>
                              </div>
                            </div>
                            <div className="border border-gray-300 dark:border-gray-600 rounded-lg p-4">
                              <div className="flex items-center space-x-2 mb-3">
                                <svg className="h-5 w-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Similar deviations assistant</span>
                              </div>
                              <div className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                                Search for similar deviations that may have occurred in the past to help identify patterns and reference existing investigations.
                              </div>
                              <div className="w-full">
                                <RelevantDeviationSearchBox 
                                  placeholder="Search similar deviations"
                                  startDate="2024-01-01"
                                  limit={10}
                                  onSelect={(deviation) => {
                                    // Handle selection - you can populate form fields or show details
                                    console.log('Selected similar deviation:', deviation)
                                    // Example: optionally populate deviation name if user confirms
                                    if (confirm(`Use "${deviation.title || deviation.description}" as reference for this deviation?`)) {
                                      setFormData(prev => ({
                                        ...prev,
                                        deviationName: deviation.title || deviation.description || prev.deviationName
                                      }))
                                    }
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons for Step 1 */}
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between">
                        <button
                          type="button"
                          onClick={handleCancel}
                          className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleStepNavigation(2)}
                          disabled={!canAccessStep(2)}
                          className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                            canAccessStep(2)
                              ? 'text-white bg-blue-600 hover:bg-blue-700'
                              : 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                          }`}
                        >
                          Continue to {getNextStepLabel(currentStep)}
                        </button>
                      </div>
                    </div>
                  </form>
                  </div>
                </FormCard>
              )}

              {currentStep === 2 && (
                /* Step 2: Initial Review & Impact */
                <FormCard>
                  <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
                    {shouldDisableFormElements() && (
                      <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
                    )}
                    <form onSubmit={handleSubmit}>
                    <div className="space-y-6">
                      {/* Impact analysis questions */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Risk assessment questions
                          </h4>
                        </div>
                        
                        <div className="p-8 space-y-6">
                          {/* Instructional text */}
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                            Fill out the impact analysis questions below to get the most accurate deviation classification calculation.
                          </div>


                          {/* Critical Warning Message */}
                          {hasYesAnswerInRiskQuestions() && (
                            <div className="mx-4">
                              <div className="border border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20 rounded-lg">
                                <div className="flex items-start p-4">
                                  <div className="flex-shrink-0">
                                    <div className="h-6 w-6 bg-red-500 rounded-full flex items-center justify-center">
                                      <svg className="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20"></svg>
                                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                    </div>
                                  </div>
                                  <div className="ml-3">
                                    <p className="text-sm font-medium text-red-800 dark:text-red-200">
                                      Because you answered yes to one of the below questions, this classification is considered critical, 
                                      therefore you will have to escalate this deviation after confirmation.
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {/* Question 1 */}
                          <div>
                            <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                              Does this deviation arise from a defined critical process or incident that could or does result in product that does not meet its regulatory filed specification and/or required quality standard in each case when that would impact patient treatment? <span className="text-red-500">*</span>
                            </div>
                            <div className="flex gap-6">
                              {['yes', 'no'].map((option) => (
                                <label key={option} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="riskQuestion1"
                                    value={option}
                                    checked={formData.riskQuestion1 === option}
                                    onChange={(e) => handleInputChange('riskQuestion1', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                    {option}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </div>

                          {/* Question 2 */}
                          <div>
                            <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                              Is this deviation a quality incident that could result in a failure to supply product which could impact patient treatment? <span className="text-red-500">*</span>
                            </div>
                            <div className="flex gap-6">
                              {['yes', 'no'].map((option) => (
                                <label key={option} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="riskQuestion2"
                                    value={option}
                                    checked={formData.riskQuestion2 === option}
                                    onChange={(e) => handleInputChange('riskQuestion2', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                    {option}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </div>

                          {/* Question 3 */}
                          <div>
                            <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                              Is this deviation a significant quality system failure that could go undetected and/or a significant potential withholding of information that may constitute fraud, misrepresentation or falsification or products or data give rise to the potential to harm the end user? <span className="text-red-500">*</span>
                            </div>
                            <div className="flex gap-6">
                              {['yes', 'no'].map((option) => (
                                <label key={option} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="riskQuestion3"
                                    value={option}
                                    checked={formData.riskQuestion3 === option}
                                    onChange={(e) => handleInputChange('riskQuestion3', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                    {option}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </div>

                          {/* Question 4 */}
                          <div>
                            <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                              Is this deviation comprised of several related deviations, none of which on their own would be classified "critical" but when considered in totality are a critical deficiency or system(s) failure that presents a risk of harm to patients? <span className="text-red-500">*</span>
                            </div>
                            <div className="flex gap-6">
                              {['yes', 'no'].map((option) => (
                                <label key={option} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="riskQuestion4"
                                    value={option}
                                    checked={formData.riskQuestion4 === option}
                                    onChange={(e) => handleInputChange('riskQuestion4', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                    {option}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Local auto classification */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Local auto classification
                          </h4>
                        </div>
                        
                        <div className="p-8">
                          <div>
                            <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                              Is this classified as "auto minor" based on the local SOP? <span className="text-red-500">*</span>
                            </label>
                            <div className="flex gap-6">
                              <label className="flex items-center">
                                <input
                                  type="radio"
                                  name="localClassification"
                                  value="yes"
                                  checked={formData.localClassification === 'yes'}
                                  onChange={(e) => handleInputChange('localClassification', e.target.value)}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                />
                                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  Yes
                                </span>
                              </label>
                              <label className="flex items-center">
                                <input
                                  type="radio"
                                  name="localClassification"
                                  value="no"
                                  checked={formData.localClassification === 'no'}
                                  onChange={(e) => handleInputChange('localClassification', e.target.value)}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                />
                                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  No
                                </span>
                              </label>
                              <label className="flex items-center">
                                <input
                                  type="radio"
                                  name="localClassification"
                                  value="not-applicable"
                                  checked={formData.localClassification === 'not-applicable'}
                                  onChange={(e) => handleInputChange('localClassification', e.target.value)}
                                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                />
                                <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  Not applicable
                                </span>
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* RPN calculation */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            RPN calculation
                          </h4>
                        </div>
                        
                        <div className="p-8 space-y-8">
                          <div className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                            Once this RPN form has been completed, support as a PDF and attach as a supporting document in response to a PDF or review as a PDF in the applicable deviation record in Trackwise when ready.
                          </div>

                          {/* Severity level */}
                          <div>
                            <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                              Severity level - what are the consequences of the deviation? <span className="text-red-500">*</span>
                            </label>
                            <div className="space-y-3">
                              {[
                                { value: 'high', label: 'High (6)' },
                                { value: 'medium', label: 'Medium (2)' },
                                { value: 'low', label: 'Low (1)' }
                              ].map((option) => (
                                <label key={option.value} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="severityLevel"
                                    value={option.value}
                                    checked={formData.severityLevel === option.value}
                                    onChange={(e) => handleInputChange('severityLevel', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                    {option.label}
                                  </span>
                                </label>
                              ))}
                            </div>
                            
                            {/* Additional details */}
                            <div className="mt-4">
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Additional details
                              </label>
                              <textarea
                                value={formData.severityAdditionalDetails}
                                onChange={(e) => handleInputChange('severityAdditionalDetails', e.target.value)}
                                className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                                rows={3}
                                placeholder="Please provide any additional detail on the severity level"
                              />
                            </div>
                          </div>

                          {/* Detection */}
                          <div>
                            <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                              Detection - what is the likelihood that the deviation is detected? <span className="text-red-500">*</span>
                            </label>
                            <div className="space-y-3">
                              {[
                                { value: 'high', label: 'High (1)' },
                                { value: 'medium', label: 'Medium (3)' },
                                { value: 'low', label: 'Low (10)' }
                              ].map((option) => (
                                <label key={option.value} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="detectionLevel"
                                    value={option.value}
                                    checked={formData.detectionLevel === option.value}
                                    onChange={(e) => handleInputChange('detectionLevel', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                    {option.label}
                                  </span>
                                </label>
                              ))}
                            </div>
                            
                            {/* Additional details */}
                            <div className="mt-4">
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Additional details
                              </label>
                              <textarea
                                value={formData.detectionAdditionalDetails}
                                onChange={(e) => handleInputChange('detectionAdditionalDetails', e.target.value)}
                                className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                                rows={3}
                                placeholder="Please provide any additional detail on the severity level"
                              />
                            </div>
                          </div>

                          {/* Occurrence */}
                          <div>
                            <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                              Occurrence - how often does this deviation occur? (Note: occurrence limits below are guidance and if the judgement of the site/quality representative considers the occurrence rate to be different, justification MUST be provided in the record) <span className="text-red-500">*</span>
                            </label>
                            <div className="space-y-3">
                              {[
                                { value: 'high', label: 'High (5)' },
                                { value: 'medium', label: 'Medium (2)' },
                                { value: 'low', label: 'Low (1)' }
                              ].map((option) => (
                                <label key={option.value} className="flex items-center">
                                  <input
                                    type="radio"
                                    name="occurrenceLevel"
                                    value={option.value}
                                    checked={formData.occurrenceLevel === option.value}
                                    onChange={(e) => handleInputChange('occurrenceLevel', e.target.value)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                                  />
                                  <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                    {option.label}
                                  </span>
                                </label>
                              ))}
                            </div>
                            
                            {/* Additional details */}
                            <div className="mt-4">
                              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                Additional details
                              </label>
                              <textarea
                                value={formData.occurrenceAdditionalDetails}
                                onChange={(e) => handleInputChange('occurrenceAdditionalDetails', e.target.value)}
                                className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                                rows={3}
                                placeholder="Please provide any additional detail on the severity level"
                              />
                            </div>
                          </div>

                          {/* Calculation and Leveling */}
                          <div>
                            <div className="flex items-center gap-2 mb-4">
                              <svg className="h-4 w-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                              </svg>
                              <span className="text-xs font-medium text-gray-900 dark:text-gray-100">
                                Calculation and leveling
                              </span>
                            </div>
                            
                            <div className="overflow-hidden border border-gray-200 dark:border-gray-600 rounded-lg">
                              {/* Table Header */}
                              <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 border-b border-gray-200 dark:border-gray-700">
                                <div className="grid grid-cols-4 gap-4 text-xs font-medium text-gray-700 dark:text-gray-300">
                                  <div>RPN Score = (Severity x Detection x Occurrence)</div>
                                  <div>If RPN score is &gt; 59 = <span className="text-red-600 font-bold">major</span></div>
                                  <div>If RPN score is 15-59 = <span className="text-yellow-600 font-bold">moderate</span></div>
                                  <div>If RPN score is &lt; 15 = <span className="text-green-600 font-bold">minor</span></div>
                                </div>
                              </div>
                              
                              {/* Table Content */}
                              <div className="p-4 bg-white dark:bg-gray-900">
                                <div className="grid grid-cols-4 gap-4 text-xs">
                                  <div>
                                    <div className="text-gray-600 dark:text-gray-400 mb-1">
                                      {(() => {
                                        const severityScore = formData.severityLevel === 'high' ? 6 : formData.severityLevel === 'medium' ? 2 : formData.severityLevel === 'low' ? 1 : 0
                                        const detectionScore = formData.detectionLevel === 'high' ? 1 : formData.detectionLevel === 'medium' ? 3 : formData.detectionLevel === 'low' ? 10 : 0
                                        const occurrenceScore = formData.occurrenceLevel === 'high' ? 5 : formData.occurrenceLevel === 'medium' ? 2 : formData.occurrenceLevel === 'low' ? 1 : 0
                                        return `${severityScore} x ${detectionScore} x ${occurrenceScore} = ${severityScore * detectionScore * occurrenceScore}`
                                      })()}
                                    </div>
                                  </div>
                                  <div className="text-center">
                                    {/* Empty - no content */}
                                  </div>
                                  <div className="text-center">
                                    {/* Empty - no content */}
                                  </div>
                                  <div className="text-center">
                                    {/* Your score section */}
                                    <div className="flex items-center justify-center gap-2">
                                      <span className="text-xs text-gray-900 dark:text-gray-100">
                                        Your score:
                                      </span>
                                      <div className={`inline-flex items-center ${getRPNClassificationInfo().bgColor} border ${getRPNClassificationInfo().borderColor} rounded px-2 py-1`}>
                                        {(() => {
                                          const info = getRPNClassificationInfo()
                                          if (info.classification === 'minor') {
                                            return <span className="text-green-600">✓</span>
                                          } else if (info.classification === 'moderate') {
                                            return (
                                              <svg className="w-3 h-3 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                                                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                              </svg>
                                            )
                                          } else if (info.classification === 'major') {
                                            return (
                                              <svg className="w-3 h-3 text-red-600" fill="currentColor" viewBox="0 20">
                                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                              </svg>
                                            )
                                          } else {
                                            return <span className="text-green-600">✓</span>
                                          }
                                        })()}
                                        <span className={`ml-1 text-xs ${getRPNClassificationInfo().color} capitalize font-medium`}>
                                          {getRPNClassificationInfo().classification || 'Minor'}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Confirm RPN classification */}
                          <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-6">
                            <h5 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-4">
                              Confirm RPN classification
                            </h5>
                            
                            <div className="mb-4">
                              <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                                Based on the information provided, the deviation classification is <strong className={getRPNClassificationInfo().color}>{getRPNClassificationInfo().classification || 'not calculated'}</strong>. Does the team/committee agreed on this classification? <span className="text-red-500">*</span>
                              </div>
                              <div className="flex gap-6">
                                {['yes', 'no'].map((option) => (
                                  <label key={option} className="flex items-center">
                                    <input
                                      type="radio"
                                      name="teamCommitteeAgreement"
                                      value={option}
                                      checked={formData.teamCommitteeAgreement === option}
                                      onChange={(e) => handleInputChange('teamCommitteeAgreement', e.target.value)}
                                      className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                                    />
                                    <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                      {option}
                                    </span>
                                  </label>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons for Step 2 */}
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between">
                        <button
                          type="button"
                          disabled={shouldDisableFormElements()}
                          className={`px-4 py-2 text-sm font-medium border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                            shouldDisableFormElements()
                              ? 'text-gray-400 bg-gray-100 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                              : 'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600'
                          }`}
                        >
                          Save
                        </button>
                        <div className="flex gap-3">
                          <button
                            type="button"
                            onClick={() => handleStepNavigation(1)}
                            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                          >
                            Back to {getPreviousStepLabel(currentStep)}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStepNavigation(3)}
                            disabled={!canAccessStep(3)}
                            className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                              canAccessStep(3)
                                ? 'text-white bg-blue-600 hover:bg-blue-700'
                                : 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                            }`}
                          >
                            Continue to {getNextStepLabel(currentStep)}
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                  </div>
                </FormCard>
              )}

              {currentStep === 3 && (
                /* Step 3: Investigation & RCA */
                <FormCard>
                  <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
                    {shouldDisableFormElements() && (
                      <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
                    )}
                    <form onSubmit={handleSubmit}>
                    <div className="space-y-6">
                      {/* Investigation section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Investigation
                          </h4>
                        </div>
                        
                        <div className="p-8 space-y-6">
                          <div className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                            Complete all required information to complete a new record
                          </div>
                          
                          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            Supporting documents
                          </label>

                          {/* Supporting documents table */}
                          <div className="overflow-hidden border border-gray-200 dark:border-gray-600 rounded-lg">
                            <table className="w-full divide-y divide-gray-200 dark:divide-gray-700">
                              <thead className="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 tracking-wider dark:text-gray-300">
                                    Name
                                  </th>
                                  <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 tracking-wider dark:text-gray-300">
                                    Date
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                  <td className="px-3 py-3 text-xs text-gray-900 dark:text-gray-100">
                                    QC-SQ-342.pdf
                                  </td>
                                  <td className="px-3 py-3 text-xs text-gray-900 dark:text-gray-100">
                                    30 May 27
                                  </td>
                                </tr>
                                <tr className="hover:bg-gray-50 dark:hover:bg-gray-700">
                                  <td className="px-3 py-3 text-xs text-gray-900 dark:text-gray-100">
                                    Document.pdf
                                  </td>
                                  <td className="px-3 py-3 text-xs text-gray-900 dark:text-gray-100">
                                    30 May 27
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </div>

                          {/* Supporting documents upload - moved after table */}
                          <div className="space-y-4">
                            <div className="text-xs text-gray-500 mb-2">
                              Upload documents
                            </div>
                            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                              <div className="space-y-2">
                                <div className="mx-auto h-12 w-12 text-gray-400">
                                  <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                                  </svg>
                                </div>
                                <div className="text-sm text-gray-600 dark:text-gray-400">
                                  <span className="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">
                                    Upload files
                                  </span> or drag and drop
                                </div>
                                <div className="text-xs text-gray-500">
                                  SUPPORTED FILE TYPES: .PDF • .DOCX • .XLSX • .CSV   MAX FILE SIZE: 25 MB
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Short Description section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Short Description
                          </h4>
                        </div>
                        
                        <div className="p-8">
                          <TextAreaField
                            id="shortDescription"
                            label=""
                            value={formData.shortDescription}
                            onChange={(value) => handleInputChange('shortDescription', value)}
                            placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
                            rows={4}
                          />
                        </div>
                      </div>

                      {/* Description section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Description
                          </h4>
                        </div>
                        
                        <div className="p-8">
                          <TextAreaField
                            id="description"
                            label=""
                            value={formData.description}
                            onChange={(value) => handleInputChange('description', value)}
                            placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
                            rows={6}
                          />
                        </div>
                      </div>

                      {/* Investigation & Root Cause Analysis section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Investigation & Root Cause Analysis
                          </h4>
                        </div>
                        
                        <div className="p-8">
                          <TextAreaField
                            id="riskAnalysis"
                            label=""
                            value={formData.riskAnalysis}
                            onChange={(value) => handleInputChange('riskAnalysis', value)}
                            placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
                            rows={6}
                          />
                        </div>
                      </div>

                      {/* Impact Analysis section */}
                      <div>
                        {/* Gray header background */}
                        <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                          <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                            Impact Analysis
                          </h4>
                        </div>
                        
                        <div className="p-8">
                          <TextAreaField
                            id="impactAnalysis"
                            label=""
                            value={formData.impactAnalysis}
                            onChange={(value) => handleInputChange('impactAnalysis', value)}
                            placeholder="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
                            rows={6}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons for Step 3 */}
                    <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                      <div className="flex justify-between">
                        <button
                          type="button"
                          disabled={shouldDisableFormElements()}
                          className={`px-4 py-2 text-sm font-medium border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                            shouldDisableFormElements()
                              ? 'text-gray-400 bg-gray-100 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                              : 'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600'
                          }`}
                        >
                          Save
                        </button>
                        <div className="flex gap-3">
                          <button
                            type="button"
                            onClick={() => handleStepNavigation(2)}
                            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                          >
                            Back to {getPreviousStepLabel(currentStep)}
                          </button>
                          <button
                            type="button"
                            onClick={() => handleStepNavigation(4)}
                            disabled={!canAccessStep(4)}
                            className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                              canAccessStep(4)
                                ? 'text-white bg-blue-600 hover:bg-blue-700'
                                : 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                            }`}
                          >
                            Continue to {getNextStepLabel(currentStep)}
                          </button>
                        </div>
                      </div>
                    </div>
                  </form>
                  </div>
                </FormCard>
              )}

              {currentStep === 4 && (
                /* Step 4: CAPA & conclusion - Placeholder */
                <FormCard>
                  <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
                    {shouldDisableFormElements() && (
                      <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
                    )}
                    <div className="p-8 text-center">
                    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                      CAPA & Conclusion
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      This step will be implemented in the future.
                    </p>
                    <div className="mt-6 flex justify-center gap-4">
                      <button
                        type="button"
                        onClick={() => handleStepNavigation(3)}
                        className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                      >
                        Back to {getPreviousStepLabel(currentStep)}
                      </button>
                      <button
                        type="submit"
                        disabled={shouldDisableFormElements()}
                        className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md ${
                          shouldDisableFormElements()
                            ? 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                            : 'text-white bg-blue-600 hover:bg-blue-700'
                        }`}
                      >
                        Complete Deviation Record
                      </button>
                    </div>
                  </div>
                  </div>
                </FormCard>
              )}
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <InvestigationAssistant />
            </div>
          </div>
        </MainContent>
        </div>
      </div>
      
      <Footer />
    </div>
  );
};

export default DeviationForm;
