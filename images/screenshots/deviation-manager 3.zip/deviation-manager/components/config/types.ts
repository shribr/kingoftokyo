// Configuration types for flexible data sources

export interface BaseDataSourceConfig {
  type: 'static' | 'rest' | 'mongodb' | 'postgresql' | 'mysql' | 'sqlite';
  name?: string;
  cache?: {
    enabled: boolean;
    ttl?: number; // time to live in seconds
  };
}

export interface StaticDataSourceConfig extends BaseDataSourceConfig {
  type: 'static';
  data?: {
    generateCount?: number;
    customData?: any[];
  };
}

export interface RestApiConfig extends BaseDataSourceConfig {
  type: 'rest';
  baseUrl: string;
  endpoints: {
    deviations?: string;
    kpis?: string;
    charts?: string;
  };
  auth?: {
    type: 'none' | 'bearer' | 'apikey' | 'basic';
    token?: string;
    apiKey?: string;
    username?: string;
    password?: string;
    headers?: Record<string, string>;
  };
  timeout?: number;
  retryAttempts?: number;
}

export interface DatabaseConfig extends BaseDataSourceConfig {
  type: 'mongodb' | 'postgresql' | 'mysql' | 'sqlite';
  connectionString: string;
  database?: string;
  queries: {
    deviations?: string;
    kpis?: string;
    charts?: string;
  };
  auth?: {
    username?: string;
    password?: string;
  };
}

export type DataSourceConfig = StaticDataSourceConfig | RestApiConfig | DatabaseConfig;

export interface DashboardConfig {
  dataSources: {
    primary: DataSourceConfig;
    fallback?: DataSourceConfig;
  };
  features: {
    realTimeUpdates?: boolean;
    offlineMode?: boolean;
    refreshInterval?: number; // seconds
  };
  ui: {
    itemsPerPage?: number;
    defaultFilters?: Record<string, string>;
    chartTypes?: string[];
  };
}

// Response interfaces for different data types
export interface DataSourceResponse<T = any> {
  success: boolean;
  data: T;
  error?: string;
  timestamp: Date;
  source: string;
}

export interface DeviationResponse {
  deviations: any[];
  total: number;
  page?: number;
  pageSize?: number;
}

export interface KpiResponse {
  kpis: any[];
  generated_at: Date;
}

export interface ChartResponse {
  charts: any[];
  type: string;
}
