import React from 'react'

export interface Step {
  id: number
  label: string
}

export interface StepperProps {
  steps: Step[]
  currentStep: number
  visitedStep?: number
  canAccessStep?: (stepId: number) => boolean
  getLegitimateCurrentStep?: () => number
  onStepClick?: (stepId: number) => void
  className?: string
}

export const Stepper: React.FC<StepperProps> = ({ steps, currentStep, visitedStep, canAccessStep, getLegitimateCurrentStep, onStepClick, className = '' }) => {
  const legitimateCurrentStep = getLegitimateCurrentStep ? getLegitimateCurrentStep() : currentStep
  return (
    <div className={`flex items-center justify-center py-6 px-6 mt-6 ${className}`}>
      {steps.map((step, index) => {
        const isCompleted = visitedStep ? visitedStep > step.id : false
        const isLegitimateCurrentStep = legitimateCurrentStep === step.id
        const isAccessible = canAccessStep ? canAccessStep(step.id) : true
        
        return (
          <React.Fragment key={step.id}>
            {/* Step Circle */}
            <button
              onClick={() => onStepClick?.(step.id)}
              className="flex flex-col items-center hover:scale-105 transition-transform cursor-pointer"
              disabled={!onStepClick}
            >
              <div className={`
                w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm font-medium transition-colors
                ${isCompleted
                  ? 'bg-green-50 border-green-500 text-green-600 dark:bg-green-900/20 dark:border-green-400 dark:text-green-400'
                  : isLegitimateCurrentStep
                  ? 'bg-blue-50 border-blue-500 text-blue-600 dark:bg-blue-900/20 dark:border-blue-400 dark:text-blue-400' 
                  : 'bg-gray-50 border-gray-300 text-gray-500 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400'
                }
              `}>
                {isCompleted ? (
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                ) : (
                  step.id
                )}
              </div>
              <span className={`mt-2 text-xs text-center max-w-20 transition-colors ${
                isCompleted
                  ? 'text-green-600 dark:text-green-400 font-medium'
                  : isLegitimateCurrentStep
                  ? 'text-blue-600 font-medium dark:text-blue-400' 
                  : 'text-gray-500 dark:text-gray-400'
              }`}>
                {step.label}
              </span>
            </button>
            
            {/* Connector Line */}
            {index < steps.length - 1 && (
              <div className={`
                flex-1 h-0.5 mx-2 min-w-9
                ${isCompleted ? 'bg-green-500 dark:bg-green-400' : 'bg-gray-300 dark:bg-gray-600'}
              `} />
            )}
          </React.Fragment>
        )
      })}
    </div>
  )
}

export default Stepper
