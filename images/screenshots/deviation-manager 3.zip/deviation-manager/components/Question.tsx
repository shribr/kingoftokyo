import { cn, defaultTextProps } from '~/utils';
import { useLocalize } from '~/hooks';
import { ControlType, DeviationQuestion } from '../services/DeviationManagerService';
import { useState } from 'react';
import DateInput from '~/features/shared/components/DateInput';

export type QuestionInputEvent = {
  target: {
    value: string;
    name: string;
  };
};

const Question: React.FC<{
  question: DeviationQuestion;
  onChange?: (event: QuestionInputEvent) => void;
  onBlur?: (event: QuestionInputEvent) => void;
}> = ({ question, onChange, onBlur }) => {
  const localize = useLocalize();
  const placeholder = question.placeHolder ?? localize('create_deviation_textbox_placeholder');
  const [prevDateYear, setPrevDateYear] = useState(0);

  const handleChange = (event: QuestionInputEvent) => {
    question.isDirty = true;
    if (onChange) {
      onChange(event);
    }
  };

  const handleBlur = (event: QuestionInputEvent) => {
    onBlur?.(event);
  };

  const handleDateInput = (e: React.FormEvent<HTMLInputElement>) => {
    const year = parseInt(e.currentTarget.value.split('-')[0], 10);
    if (year > 999 && year !== prevDateYear) {
      e.currentTarget.blur();
      setPrevDateYear(year);
    }
  };

  return (
    <div key={question.id} className="flex flex-col gap-2">
      <label htmlFor={`question-${question.id}`} className="text-sm font-medium text-text-primary">
        {question.label}
      </label>
      {question.controlType === ControlType.TEXTBOX && (
        <input
          type="text"
          value={question.value || ''}
          id={`question-${question.id}`}
          name={`question-${question.id}`}
          onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
          onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
          className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
          placeholder={placeholder}
        />
      )}
      {question.controlType === ControlType.TEXTAREA && (
        <textarea
          id={`question-${question.id}`}
          value={question.value || ''}
          name={`question-${question.id}`}
          onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
          onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
          className={cn(
            defaultTextProps,
            'max-h-[240px] min-h-[30px] w-full resize-none px-3 py-2',
          )}
          placeholder={placeholder}
        />
      )}
      {question.controlType === ControlType.DATE && (
        <>
          {/* <input
            type="date"
            value={question.value || ''}
            id={`question-${question.id}`}
            name={`question-${question.id}`}
            onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
            onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
            className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
            onInput={handleDateInput}
            placeholder={placeholder}
          /> */}
          <DateInput
            key={question.id}
            id={`question-${question.id}`}
            value={question.value || ''}
            onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
            onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
            className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
          />
        </>
      )}
      {question.controlType === ControlType.TIME && (
        <input
          type="time"
          value={question.value || ''}
          id={`question-${question.id}`}
          name={`question-${question.id}`}
          onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
          onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
          className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
          placeholder={placeholder}
        />
      )}
      {question.controlType === ControlType.DROPDOWN && question.options && (
        <select
          id={`question-${question.id}`}
          value={question.value || ''}
          name={`question-${question.id}`}
          onChange={(e) => handleChange(e as unknown as QuestionInputEvent)}
          onBlur={(e) => handleBlur(e as unknown as QuestionInputEvent)}
          className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
        >
          {question.options.map((option, index) => (
            <option key={index} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      )}
    </div>
  );
};

export default Question;