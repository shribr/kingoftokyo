import React, { createContext, useContext, ReactNode } from 'react'
import { useDeviationTable } from '../utils/hooks'
import type { Deviation } from '../utils/types'

interface TableContextType {
  deviations: Deviation[]
  pagination: {
    page: number
    totalPages: number
  }
  filters: {
    search: string
    site: string
    department: string
    classification: string
    stage: string
  }
  loading: boolean
  handlePageChange: (page: number) => void
  handleSearch: (search: string) => void
  handleFilter: (key: string, value: string) => void
  handleCreateRecord?: () => void
}

const TableContext = createContext<TableContextType | undefined>(undefined)

export const useTableContext = () => {
  const context = useContext(TableContext)
  if (!context) {
    throw new Error('useTableContext must be used within a TableProvider')
  }
  return context
}

interface TableProviderProps {
  children: ReactNode
  onCreateRecord?: () => void
}

export const TableProvider: React.FC<TableProviderProps> = ({ children, onCreateRecord }) => {
  const tableData = useDeviationTable()

  // Make sure we're not accidentally overriding handleCreateRecord
  const contextValue: TableContextType = {
    deviations: tableData.deviations,
    pagination: tableData.pagination,
    filters: tableData.filters,
    loading: tableData.loading,
    handlePageChange: tableData.handlePageChange,
    handleSearch: tableData.handleSearch,
    handleFilter: tableData.handleFilter,
    handleCreateRecord: onCreateRecord
  }

  console.log('TableProvider: onCreateRecord is', onCreateRecord)
  console.log('TableProvider: contextValue.handleCreateRecord is', contextValue.handleCreateRecord)

  return (
    <TableContext.Provider value={contextValue}>
      {children}
    </TableContext.Provider>
  )
}

export default TableProvider
