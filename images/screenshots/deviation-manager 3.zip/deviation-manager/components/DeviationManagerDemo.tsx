import React, { useState } from 'react';
import { KeyManagementComponent, DeviationManagerTestComponent, AuthExamplesComponent } from '../components';

/**
 * Deviation Manager Demo Page
 * 
 * This component demonstrates the toggle functionality between:
 * 1. LibreChat Proxy Mode - Routes through LibreChat's backend with authentication
 * 2. Direct Azure API Mode - Calls Azure API directly from the browser
 * 
 * Usage:
 * 1. Configure the API connection mode using KeyManagementComponent
 * 2. Test the API functionality using DeviationManagerTestComponent
 * 3. Switch between modes to see the difference in behavior
 */
const DeviationManagerDemo: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'config' | 'test' | 'examples'>('config');

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 py-8">
      <div className="max-w-6xl mx-auto px-4 space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            🔄 Deviation Manager API Demo
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Toggle between LibreChat Proxy mode and Direct Azure API mode to test different connection methods.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <div className="flex border-b border-gray-200 dark:border-gray-700">
            <button
              onClick={() => setActiveTab('config')}
              className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                activeTab === 'config'
                  ? 'bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-b-2 border-blue-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <span className="flex items-center">
                <span className="w-6 h-6 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center mr-2 text-xs">1</span>
                Configuration
              </span>
            </button>
            <button
              onClick={() => setActiveTab('test')}
              className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                activeTab === 'test'
                  ? 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300 border-b-2 border-green-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <span className="flex items-center">
                <span className="w-6 h-6 bg-green-100 dark:bg-green-900 rounded-full flex items-center justify-center mr-2 text-xs">2</span>
                Testing
              </span>
            </button>
            <button
              onClick={() => setActiveTab('examples')}
              className={`flex-1 px-6 py-4 text-sm font-medium transition-colors ${
                activeTab === 'examples'
                  ? 'bg-purple-50 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 border-b-2 border-purple-500'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <span className="flex items-center">
                <span className="w-6 h-6 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center mr-2 text-xs">🔐</span>
                Auth Examples
              </span>
            </button>
          </div>

          <div className="p-6">
            {activeTab === 'config' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  API Configuration
                </h2>
                <KeyManagementComponent />
              </div>
            )}

            {activeTab === 'test' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  API Testing
                </h2>
                <DeviationManagerTestComponent />
              </div>
            )}

            {activeTab === 'examples' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                  Authentication Examples
                </h2>
                <AuthExamplesComponent />
              </div>
            )}
          </div>
        </div>

        {/* Info Section */}
        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
          <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-3">
            📚 Mode Comparison
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <h4 className="font-medium text-blue-800 dark:text-blue-200">🔒 LibreChat Proxy Mode</h4>
              <ul className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                <li>• Routes through LibreChat backend</li>
                <li>• Requires API key authentication</li>
                <li>• Credentials stored encrypted in database</li>
                <li>• More secure for production use</li>
                <li>• Subject to LibreChat's authentication rules</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-medium text-green-800 dark:text-green-200">⚡ Direct Azure API Mode</h4>
              <ul className="text-sm text-green-700 dark:text-green-300 space-y-1">
                <li>• Direct browser to Azure communication</li>
                <li>• Multiple authentication options available</li>
                <li>• Faster response times</li>
                <li>• Good for development and testing</li>
                <li>• Subject to CORS and browser security</li>
              </ul>
              <div className="mt-2 p-2 bg-green-100 dark:bg-green-900/30 rounded text-xs">
                <strong>🔐 Auth Options:</strong> None, API Key, Bearer Token, Basic Auth
              </div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-amber-100 dark:bg-amber-900/30 rounded border border-amber-300 dark:border-amber-700">
            <p className="text-sm text-amber-800 dark:text-amber-200">
              <strong>💡 Pro Tip:</strong> Use Direct Mode for development and testing, 
              then switch to Proxy Mode for production deployments with proper authentication.
            </p>
          </div>
        </div>

        {/* Environment Configuration */}
        <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-6 border border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
            ⚙️ Environment Configuration
          </h3>
          
          <div className="space-y-3 text-sm">
            <div>
              <h4 className="font-medium text-gray-800 dark:text-gray-200">Environment Variables:</h4>
              <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded mt-1 font-mono text-xs">
                <div>REACT_APP_AZURE_DEVIATION_API_BASE_URL=https://cps-dev-scus-aml-dmapi.azurewebsites.net</div>
                <div>REACT_APP_DEVIATION_MANAGER_MODE=direct | proxy</div>
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-gray-800 dark:text-gray-200">Programmatic Usage:</h4>
              <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded mt-1 font-mono text-xs">
                <div>import deviationManagerService from './services/DeviationManagerService';</div>
                <div>deviationManagerService.setMode('direct', {'{'} directApiUrl: 'https://...', apiKey: '...' {'}'});</div>
                <div>const health = await deviationManagerService.healthCheck();</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeviationManagerDemo;
