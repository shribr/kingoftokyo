import PageNavigator from '~/features/shared/components/PageNavigator';
import EditableTextArea from '../../shared/components/EditableTextArea';
import Assistant from './Assistant';
import { useState } from 'react';
import { useLocalize } from '~/hooks';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';

import {
  useComposeGeneralDescription,
  useComposeImpactAnalysis,
  useComposeRiskAnalysis,
  useComposeRootCauseAnalysis,
  useUpdateGeneralDescription,
  useUpdateImpactAnalysis,
  useUpdateRootCauseAnalysis,
  useUpdateRiskAnalysis,
  useComposeShortDescription,
  useUpdateShortDescription,
} from '../queries/useDeviationMutations';

const DeviationOutput: React.FC<{
  label: string;
  data: RowData[];
  accessor: string;
  placeholder?: string;
  onComposeComplete?: (record: RowData) => void;
  defaultPage?: number;
}> = ({ label, data, accessor, placeholder, onComposeComplete, defaultPage = 0 }) => {
  const [record, setRecord] = useState<RowData>(data?.[defaultPage] || {});
  const composeGeneralDescriptionMutation = useComposeGeneralDescription();
  const composeImpactAnalysisMutation = useComposeImpactAnalysis();
  const composeRootCauseAnalysisMutation = useComposeRootCauseAnalysis();
  const composeRiskAnalysisMutation = useComposeRiskAnalysis();
  const updateGeneralDescriptionMutation = useUpdateGeneralDescription();
  const updateImpactAnalysisMutation = useUpdateImpactAnalysis();
  const updateRootCauseAnalysisMutation = useUpdateRootCauseAnalysis();
  const updateRiskAnalysisMutation = useUpdateRiskAnalysis();
  const composeShortDescriptionMutation = useComposeShortDescription();
  const updateShortDescriptionMutation = useUpdateShortDescription();

  const localize = useLocalize();
  const { showToast } = useToastContext();

  const handlePageChange = ({ page, record }: { page: number; record: RowData }) => {
    setRecord(record);
  };

  const mutateOptions = {
    onSuccess: () => {
      onComposeComplete?.(record);
    },
    onError: (error) => {
      showToast({
        message: localize('deviation_output_mutation_error'),
        severity: NotificationSeverity.ERROR,
        showIcon: true,
      });
    },
  };

  const isProcessing =
    composeGeneralDescriptionMutation.isLoading ||
    composeImpactAnalysisMutation.isLoading ||
    composeRootCauseAnalysisMutation.isLoading ||
    composeRiskAnalysisMutation.isLoading ||
    composeShortDescriptionMutation.isLoading;

  const handleSend = async (text: string) => {
    switch (label) {
      case localize('draft_deviation_general_information'):
        await composeGeneralDescriptionMutation.mutateAsync(
          {
            general_description_id: record.id,
            payload: { field_id: record['id'], user_input: text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_impact_analysis'):
        await composeImpactAnalysisMutation.mutateAsync(
          {
            impact_analysis_id: record.id,
            payload: { field_id: record['id'], user_input: text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_risk_analysis'):
        await composeRiskAnalysisMutation.mutateAsync(
          {
            risk_analysis_id: record.id,
            payload: { field_id: record['id'], user_input: text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_investigation'):
        await composeRootCauseAnalysisMutation.mutateAsync(
          {
            root_cause_analysis_id: record.id,
            payload: { field_id: record['id'], user_input: text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_short_description'):
        await composeShortDescriptionMutation.mutateAsync(
          {
            short_description_id: record.id,
            payload: { field_id: record['id'], user_input: text },
          },
          mutateOptions,
        );
        break;
    }
  };

  const isEdited =
    record?.created_on &&
    record?.updated_on &&
    Math.abs(new Date(record.updated_on).getTime() - new Date(record.created_on).getTime()) > 1000;

  const handleUpdate = async (text: string) => {
    switch (label) {
      case localize('draft_deviation_general_information'):
        await updateGeneralDescriptionMutation.mutateAsync(
          {
            general_description_id: record.id,
            payload: { text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_impact_analysis'):
        await updateImpactAnalysisMutation.mutateAsync(
          {
            impact_analysis_id: record.id,
            payload: { text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_risk_analysis'):
        await updateRiskAnalysisMutation.mutateAsync(
          {
            risk_analysis_id: record.id,
            payload: { text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_investigation'):
        await updateRootCauseAnalysisMutation.mutateAsync(
          {
            root_cause_analysis_id: record.id,
            payload: { text },
          },
          mutateOptions,
        );
        break;
      case localize('draft_deviation_short_description'):
        await updateShortDescriptionMutation.mutateAsync(
          {
            short_description_id: record.id,
            payload: { text },
          },
          mutateOptions,
        );
        break;
    }
  };

  return (
    <div className="mt-2 flex flex-col gap-2 border-t border-gray-400 pb-2 pt-4">
      <EditableTextArea
        id={`${record?.id}`}
        key={`editable-text-${record?.id}`}
        label={label}
        defaultValue={record ? record[accessor] : ''}
        isEdited={isEdited}
        placeholder={placeholder}
        onSave={handleUpdate}
        disabled={isProcessing}
      />
      <Assistant onSend={handleSend} isProcessing={isProcessing} id={record?.id} />
      <PageNavigator
        data={data}
        onChange={handlePageChange}
        disabled={isProcessing}
        defaultPage={defaultPage}
      />
    </div>
  );
};

export default DeviationOutput;
