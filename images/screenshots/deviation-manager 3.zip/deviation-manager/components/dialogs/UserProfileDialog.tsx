import React from 'react';
import { useAuthContext } from '~/hooks/AuthContext';

interface UserProfileDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

const UserProfileDialog: React.FC<UserProfileDialogProps> = ({ isOpen, onClose }) => {
  const { user } = useAuthContext();

  if (!isOpen) return null;

  // Mock user data that would come from Entra/Azure AD
  const userProfile = {
    displayName: user?.name || 'John Doe',
    email: user?.email || 'john.doe@company.com',
    jobTitle: 'Quality Assurance Manager',
    department: 'Manufacturing',
    location: 'San Diego, CA',
    manager: 'Sarah Johnson',
    phoneNumber: '+1 (555) 123-4567',
    employeeId: 'EMP123456',
    startDate: '2020-03-15',
    timezone: 'Pacific Standard Time',
    avatar: user?.avatar || null
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full mx-4 max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Profile
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 rounded-md p-1"
            aria-label="Close dialog"
            title="Close dialog"
          >
            <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
          {/* Profile Picture and Basic Info */}
          <div className="text-center mb-6">
            <div className="mx-auto h-24 w-24 rounded-full bg-blue-500 flex items-center justify-center mb-4">
              {userProfile.avatar ? (
                <img
                  src={userProfile.avatar}
                  alt={userProfile.displayName}
                  className="h-24 w-24 rounded-full object-cover"
                />
              ) : (
                <span className="text-white text-2xl font-medium">
                  {getInitials(userProfile.displayName)}
                </span>
              )}
            </div>
            <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
              {userProfile.displayName}
            </h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {userProfile.jobTitle}
            </p>
            <p className="text-sm text-gray-500 dark:text-gray-500">
              {userProfile.department}
            </p>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <div className="border-b border-gray-200 dark:border-gray-700 pb-4">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">
                Contact Information
              </h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-3">
                  <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-400">{userProfile.email}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-400">{userProfile.phoneNumber}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <svg className="h-4 w-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-sm text-gray-600 dark:text-gray-400">{userProfile.location}</span>
                </div>
              </div>
            </div>

            {/* Organization Information */}
            <div className="border-b border-gray-200 dark:border-gray-700 pb-4">
              <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-3">
                Organization
              </h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Manager</span>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{userProfile.manager}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Employee ID</span>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{userProfile.employeeId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Start Date</span>
                  <span className="text-sm text-gray-600 dark:text-gray-300">
                    {new Date(userProfile.startDate).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 dark:text-gray-400">Timezone</span>
                  <span className="text-sm text-gray-600 dark:text-gray-300">{userProfile.timezone}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2">
              <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium">
                View in Azure AD
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfileDialog;
