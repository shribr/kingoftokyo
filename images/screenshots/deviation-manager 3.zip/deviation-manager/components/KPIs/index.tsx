import React from 'react'
import { KpiBarsIcon, KpiSearchIcon, KpiCheckIcon, KpiClockIcon } from '../utils/icons'
import type { IconProps } from '../utils/types'
import { useKpis, useTrendString } from '../utils/hooks'

// Arrow SVG components
const ArrowUpIcon: React.FC<{ className?: string }> = ({ className = "h-3 w-3" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 4L20 12H16V20H8V12H4L12 4Z" fill="currentColor"/>
  </svg>
)

const ArrowDownIcon: React.FC<{ className?: string }> = ({ className = "h-3 w-3" }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 20L4 12H8V4H16V12H20L12 20Z" fill="currentColor"/>
  </svg>
)

interface KpiCardProps {
  title: string
  value: string | number
  trend: string
  trendType: 'up' | 'down' | 'neutral'
  Icon: React.FC<IconProps>
  iconBgClass: string
}

const KpiCard: React.FC<KpiCardProps> = ({ title, value, trend, trendType, Icon, iconBgClass }) => {
  const renderTrendWithArrow = () => {
    if (trendType === 'neutral') {
      return <span>{trend}</span>
    }
    
    const ArrowIcon = trendType === 'up' ? ArrowUpIcon : ArrowDownIcon
    
    return (
      <div className="flex items-center gap-1">
        <span>{trend}</span>
        <ArrowIcon className="h-3 w-3" />
      </div>
    )
  }

  return (
    <div className="bg-white shadow-lg rounded-xl border border-gray-200 dark:bg-gray-800 dark:border-gray-700 p-4">
      <div className="flex items-start gap-4">
        <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${iconBgClass}`}>
          <Icon className="h-6 w-6" />
        </div>

        <div>
          <div className="text-gray-600 text-xs font-medium dark:text-gray-400">{title}</div>
          <div className="text-2xl font-semibold text-gray-900 dark:text-gray-100">{value}</div>
          <div className={`text-xs font-medium ${trendType === 'up' ? 'text-green-600 dark:text-green-400' : trendType === 'down' ? 'text-red-600 dark:text-red-400' : 'text-gray-500'}`}>
            {renderTrendWithArrow()}
          </div>
        </div>
      </div>
    </div>
  )
}

export const KPIs: React.FC = () => {
  const { kpis } = useKpis()
  const [total, investigation, capas, resolution] = kpis.items

  const totalTrend = useTrendString(total.deltaPct, total.trend)
  const invTrend   = useTrendString(investigation.deltaPct, investigation.trend)
  const capaTrend  = useTrendString(capas.deltaPct, capas.trend)
  const resTrend   = useTrendString(resolution.deltaPct, resolution.trend)

  return (
    <section className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4 opacity-100">
      <KpiCard
        title={total.title}
        value={total.display}
        trend={totalTrend}
        trendType={total.trend}
        Icon={KpiBarsIcon}
        iconBgClass="bg-amber-100 text-amber-700"
      />
      <KpiCard
        title={investigation.title}
        value={investigation.display}
        trend={invTrend}
        trendType={investigation.trend}
        Icon={KpiSearchIcon}
        iconBgClass="bg-red-100 text-red-700"
      />
      <KpiCard
        title={capas.title}
        value={capas.display}
        trend={capaTrend}
        trendType={capas.trend}
        Icon={KpiCheckIcon}
        iconBgClass="bg-blue-100 text-blue-700"
      />
      <KpiCard
        title={resolution.title}
        value={resolution.display}
        trend={resTrend}
        trendType={resolution.trend}
        Icon={KpiClockIcon}
        iconBgClass="bg-green-100 text-green-700"
      />
    </section>
  )
}

export default KPIs
