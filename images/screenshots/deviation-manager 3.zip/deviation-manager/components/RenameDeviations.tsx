import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocalize } from '~/hooks';
import type { MouseEvent, FocusEvent, KeyboardEvent } from 'react';
import { Check, X } from 'lucide-react';
import { Spinner } from '~/components';

type KeyEvent = KeyboardEvent<HTMLInputElement>;

function RenameDeviation({
  title,
  onCancelRename,
  onRename,
  isProcessing = false,
}: {
  title: string;
  onCancelRename: () => void;
  onRename: (newTitle: string) => void;
  isProcessing?: boolean;
}) {
  const localize = useLocalize();
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [titleInput, setTitleInput] = useState(title);

  const handleOnRename = useCallback(
    (e: MouseEvent<HTMLButtonElement> | FocusEvent<HTMLInputElement> | KeyEvent) => {
      e.preventDefault();
      onRename(titleInput);
    },
    [title, titleInput, onRename],
  );

  const cancelRename = useCallback(
    (e: MouseEvent<HTMLButtonElement>) => {
      e.preventDefault();
      setTitleInput(title);
      onCancelRename();
    },
    [title, onCancelRename],
  );

  const handleKeyDown = useCallback(
    (e: KeyEvent) => {
      if (e.key === 'Escape') {
        setTitleInput(title);
        onCancelRename();
      } else if (e.key === 'Enter') {
        handleOnRename(e);
      }
    },
    [title, handleOnRename],
  );

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.focus();
    }
  }, []);

  return (
    <div className="absolute inset-0 z-20 flex w-full items-center rounded-lg bg-surface-active-alt p-1.5">
      <input
        ref={inputRef}
        type="text"
        className={`w-full rounded bg-transparent p-0.5 text-sm leading-tight focus-visible:outline-none ${
          isProcessing ? 'cursor-not-allowed opacity-50' : ''
        }`}
        value={titleInput ?? ''}
        onChange={(e) => setTitleInput(e.target.value)}
        onKeyDown={handleKeyDown}
        aria-label={`${localize('com_ui_rename')} ${localize('com_ui_chat')}`}
        disabled={isProcessing}
      />
      <div className="flex gap-1">
        <button
          onClick={cancelRename}
          aria-label={`${localize('com_ui_cancel')} ${localize('com_ui_rename')}`}
          disabled={isProcessing}
        >
          {isProcessing ? null : (
            <X
              aria-hidden={true}
              className="h-4 w-4 transition-colors duration-200 ease-in-out hover:opacity-70"
            />
          )}
        </button>
        <button
          onClick={handleOnRename}
          aria-label={`${localize('com_ui_submit')} ${localize('com_ui_rename')}`}
          disabled={isProcessing}
        >
          {isProcessing ? (
            <Spinner className="h-4 w-4" aria-hidden={true} />
          ) : (
            <Check
              aria-hidden={true}
              className="h-4 w-4 transition-colors duration-200 ease-in-out hover:opacity-70"
            />
          )}
        </button>
      </div>
    </div>
  );
}

export default RenameDeviation;
