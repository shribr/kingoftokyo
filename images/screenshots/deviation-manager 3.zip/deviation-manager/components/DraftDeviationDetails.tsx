import {
  useDeviationGeneralDescription,
  useDeviationImpactAnalysis,
  useDeviationRootCauseAnalysis,
  useDeviationRiskAnalysis,
  useDeviationShortDescription,
  useDraftDeviation,
} from '../queries/useDeviationQueries';
import useLocalize from '~/hooks/useLocalize';
import DeviationOutput from './DeviationOutput';
import SupportingDocuments from './Documents/SupportingDocuments';
import RelevantDeviations from './RelevantDeviations';
import { useEffect, useState } from 'react';
import Callout from '~/features/shared/components/Callout';
import Classification from './Classification';
import { useExportDraftDeviation } from '../queries/useDeviationMutations';
import { Spinner, TooltipAnchor } from '~/components';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';
import { ArrowLeft } from 'lucide-react';

function DeviationOutputSkeleton() {
  return (
    <div className="mt-2 flex animate-pulse flex-col gap-2 border-t border-gray-400 pb-2 pt-4">
      <div className="flex items-center justify-between space-x-2">
        <div className="h-4 w-36 rounded-lg bg-gray-200" />
        <div className="flex gap-2">
          <div className="h-4 w-5 rounded-lg bg-gray-300" />
          <div className="h-4 w-5 rounded-lg bg-gray-300" />
        </div>
      </div>
      <div className="h-24 rounded-lg bg-gray-200" />
      <div className="flex items-center space-x-2">
        <div className="h-10 flex-1 rounded-lg bg-gray-200" />
        <div className="h-10 w-20 rounded-lg bg-gray-300" />
      </div>
    </div>
  );
}

export default function DraftDeviationDetails({
  deviationId,
  onNavigateBack,
}: {
  deviationId: string;
  onNavigateBack: () => void;
}) {
  const localize = useLocalize();
  const [isOpen, setIsOpen] = useState(false);
  const [startDate, setStartDate] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const exportMutation = useExportDraftDeviation();
  const { showToast } = useToastContext();

  const {
    data: deviation,
    isLoading: isDeviationLoading,
    refetch: refetchDeviation,
    isRefetching: isDeviationRefetching,
  } = useDraftDeviation(deviationId);

  const {
    data: shortDescription,
    isLoading: isShortDescriptionLoading,
    refetch: refetchShortDescription,
    isRefetching: isShortDescriptionRefetching,
  } = useDeviationShortDescription(deviationId);

  const {
    data: generalDescription,
    isLoading: isGeneralDescriptionLoading,
    refetch: refetchGeneralDescription,
    isRefetching: isGeneralDescriptionRefetching,
  } = useDeviationGeneralDescription(deviationId);

  const {
    data: impactAnalysis,
    isLoading: isImpactAnalysisLoading,
    refetch: refetchImpactAnalysis,
    isRefetching: isImpactAnalysisRefetching,
  } = useDeviationImpactAnalysis(deviationId);

  const {
    data: rootCauseAnalysis,
    isLoading: isRootCauseAnalysisLoading,
    refetch: refetchRootCauseAnalysis,
    isRefetching: isRootCauseAnalysisRefetching,
  } = useDeviationRootCauseAnalysis(deviationId);

  const {
    data: riskAnalysis,
    isLoading: isRiskAnalysisLoading,
    refetch: refetchRiskAnalysis,
    isRefetching: isRiskAnalysisRefetching,
  } = useDeviationRiskAnalysis(deviationId);

  const handleFileChanged = (documents) => {
    refetchGeneralDescription();
    refetchImpactAnalysis();
    refetchRootCauseAnalysis();
    refetchRiskAnalysis();
    refetchShortDescription();
    setIsRefreshing(true);
  };

  const handleComposeComplete = async (type) => {
    switch (type) {
      case 'general_description':
        await refetchGeneralDescription();
        break;
      case 'impact_analysis':
        await refetchImpactAnalysis();
        break;
      case 'root_cause_analysis':
        await refetchRootCauseAnalysis();
        break;
      case 'risk_analysis':
        await refetchRiskAnalysis();
        break;
      case 'short_description':
        await refetchShortDescription();
        break;
    }
  };

  const handleViewRecentDeviationsClick = () => {
    setIsOpen(true);
  };

  const handleRefreshComplete = () => {
    setIsRefreshing(false);
  };

  const handleExportClick = async () => {
    exportMutation.mutateAsync(
      {
        draft_deviation_id: deviationId,
      },
      {
        onSuccess: (response) => {
          const filename = deviation?.name
            ? `${deviation?.name}.docx`
            : `draft_deviation_${deviationId}.docx`;
          const blob = new Blob([response.result], {
            type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          });
          downloadFile(blob, filename);
        },
        onError: (error) => {
          console.error('Error exporting draft deviation:', error);
          showToast({
            message: localize('draft_deviation_details_export_error'),
            severity: NotificationSeverity.ERROR,
            showIcon: true,
          });
        },
      },
    );
  };

  function downloadFile(blob: Blob, fileName: string) {
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  const sortedOutput = (data) => {
    return data
      ?.slice()
      .sort((a, b) => new Date(a.created_on).getTime() - new Date(b.created_on).getTime());
  };

  const sortedGeneralDescription = sortedOutput(generalDescription);

  const Outputs = [
    {
      label: localize('draft_deviation_short_description'),
      data: sortedOutput(shortDescription) ?? [],
      isLoading: isShortDescriptionLoading || isShortDescriptionRefetching,
      type: 'short_description',
    },
    {
      label: localize('draft_deviation_general_information'),
      data: sortedGeneralDescription ?? [],
      isLoading: isGeneralDescriptionLoading || isGeneralDescriptionRefetching,
      type: 'general_description',
    },
    {
      label: localize('draft_deviation_investigation'),
      data: sortedOutput(rootCauseAnalysis) ?? [],
      isLoading: isRootCauseAnalysisLoading || isRootCauseAnalysisRefetching,
      type: 'root_cause_analysis',
    },
    {
      label: localize('draft_deviation_risk_analysis'),
      data: sortedOutput(riskAnalysis) ?? [],
      isLoading: isRiskAnalysisLoading || isRiskAnalysisRefetching,
      type: 'risk_analysis',
    },
    {
      label: localize('draft_deviation_impact_analysis'),
      data: sortedOutput(impactAnalysis) ?? [],
      isLoading: isImpactAnalysisLoading || isImpactAnalysisRefetching,
      type: 'impact_analysis',
    },
  ];

  useEffect(() => {
    const rawDate = deviation?.input_details?.['Date of occurrence'];
    const start_date = new Date(rawDate && rawDate.trim() !== '' ? rawDate : new Date());
    start_date.setFullYear(start_date.getFullYear() - 2);
    setStartDate(start_date.toISOString());
  }, [deviation]);

  const handleNavigateBack = () => {
    onNavigateBack();
  };

  return (
    <div className="relative flex h-full flex-col">
      <div className="sticky top-0 z-10 flex w-full items-center justify-between px-4 pb-1">
        <div className="flex items-center gap-2">
          <TooltipAnchor
            description={`${localize('draft_deviation_details_navigate_back')}`}
            side="bottom"
            render={
              <button
                type="button"
                className="btn cursor-pointer hover:bg-surface-hover"
                onClick={handleNavigateBack}
                aria-label={localize('draft_deviation_details_navigate_back')}
                disabled={exportMutation.isLoading}
              >
                <ArrowLeft className="text-text-primary" />
              </button>
            }
          />

          <h3 className="text-lg font-bold text-text-primary">
            {localize('draft_deviation_details_heading')}
          </h3>
        </div>
        <button
          type="button"
          className="btn btn-primary relative mt-2 cursor-pointer"
          onClick={handleExportClick}
          disabled={exportMutation.isLoading}
        >
          {exportMutation.isLoading ? (
            <div className="flex gap-2">
              <Spinner size="1.5em" />
              {localize('draft_deviation_details_exporting')}
            </div>
          ) : (
            localize('draft_deviation_details_export_button')
          )}
        </button>
      </div>
      <div className="mb-4 flex w-full items-center justify-between px-4">
        <h6 className="text-xs text-text-primary">
          {localize('draft_deviation_details_sub_heading')}
        </h6>
      </div>
      <div className="px-4 pb-2">
        <Callout text={localize('review_deviation_callout_text')} />
      </div>
      <div className={'h-full overflow-y-auto pt-2'}>
        <div className="mb-2 flex flex-col gap-2 px-4">
          <div className="flex w-full gap-2 pb-2">
            <div className="w-full flex-1">
              <Classification
                deviationId={deviationId}
                refresh={isRefreshing}
                onRefreshComplete={handleRefreshComplete}
              />
            </div>
            <div>
              <button
                type="button"
                className="btn btn-secondary relative cursor-pointer"
                onClick={handleViewRecentDeviationsClick}
                disabled={
                  isGeneralDescriptionLoading ||
                  isGeneralDescriptionRefetching ||
                  isDeviationLoading ||
                  isDeviationRefetching
                }
              >
                {localize('review_deviation_header_view_button')}
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-2 border-t border-gray-400 pb-2 pt-2">
            <SupportingDocuments deviationId={deviationId} onFileChanged={handleFileChanged} />
          </div>
          {Outputs.map((output, index) => (
            <div key={index} className="mb-2">
              {output.isLoading && <DeviationOutputSkeleton />}
              {!output.isLoading && (
                <DeviationOutput
                  label={output.label}
                  data={output.data}
                  defaultPage={output.data?.length - 1}
                  accessor="text"
                  onComposeComplete={() => handleComposeComplete(output.type)}
                />
              )}
            </div>
          ))}
        </div>
      </div>
      <RelevantDeviations
        open={isOpen}
        onOpenChange={setIsOpen}
        text={sortedGeneralDescription?.at(-1)?.text ?? ''}
        start_date={startDate}
      />
    </div>
  );
}
