import React, { useEffect, useRef } from 'react'
import { Chart as ChartJS, ChartType, ChartConfiguration, ChartData, ChartOptions } from 'chart.js/auto'

export interface BaseChartProps {
  type: ChartType
  data: ChartData
  options?: ChartOptions
  height?: string | number
  className?: string
}

export const BaseChart: React.FC<BaseChartProps> = ({ 
  type, 
  data, 
  options = {}, 
  height = '300px',
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const chartRef = useRef<ChartJS | null>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    // Destroy existing chart if it exists
    if (chartRef.current) {
      chartRef.current.destroy()
      chartRef.current = null
    }

    // Default options that work well for all chart types
    const defaultOptions: ChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: type !== 'bar' // Hide legend for bar charts by default
        }
      },
      scales: type === 'pie' || type === 'doughnut' ? undefined : {
        x: {
          grid: {
            display: false
          },
          border: {
            color: '#e5e7eb' // gray-200
          },
          ticks: {
            color: '#6B7280' // gray-500
          }
        },
        y: {
          border: {
            display: false
          },
          grid: {
            color: '#e5e7eb' // gray-200
          },
          ticks: {
            color: '#6B7280' // gray-500
          }
        }
      }
    }

    // Merge default options with provided options
    const mergedOptions = {
      ...defaultOptions,
      ...options,
      plugins: {
        ...defaultOptions.plugins,
        ...options.plugins
      }
    }

    const config: ChartConfiguration = {
      type,
      data,
      options: mergedOptions
    }

    chartRef.current = new ChartJS(canvasRef.current, config)

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy()
        chartRef.current = null
      }
    }
  }, [type, data, options])

  // Update chart when data changes
  useEffect(() => {
    if (chartRef.current) {
      chartRef.current.data = data
      chartRef.current.update()
    }
  }, [data])

  return (
    <div className={`chart-container ${className}`} style={{ height: typeof height === 'string' ? height : `${height}px` }}>
      <canvas ref={canvasRef} />
    </div>
  )
}

export default BaseChart
