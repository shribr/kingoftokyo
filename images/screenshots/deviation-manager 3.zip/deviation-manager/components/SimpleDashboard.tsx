import React from 'react'

// Ultra-simple dashboard with zero dependencies
const SimpleDashboard: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Sample Data Banner */}
        <div className="bg-amber-50 border-l-4 border-amber-400 p-3 mb-6">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <svg className="h-4 w-4 text-amber-400" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-amber-700">
                <span className="font-medium">Sample Data Mode:</span> Live data services are currently unavailable. The application is displaying representative sample data for demonstration purposes.
              </p>
            </div>
          </div>
        </div>

        {/* Header */}
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
          Deviation Manager Dashboard
        </h1>
        
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              Total Deviations
            </h3>
            <p className="text-3xl font-bold text-blue-600">42</p>
            <p className="text-sm text-gray-500">Sample data</p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              Pending Review
            </h3>
            <p className="text-3xl font-bold text-yellow-600">12</p>
            <p className="text-sm text-gray-500">Sample data</p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
              Completed
            </h3>
            <p className="text-3xl font-bold text-green-600">30</p>
            <p className="text-sm text-gray-500">Sample data</p>
          </div>
        </div>
        
        {/* Simple Table */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
          <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recent Deviations (Sample Data)
            </h2>
          </div>
          <div className="p-6">
            <div className="overflow-x-auto">
              <table className="min-w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700">
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                      ID
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                      Title
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                      Status
                    </th>
                    <th className="text-left py-3 px-4 text-sm font-medium text-gray-900 dark:text-white">
                      Date
                    </th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-gray-100 dark:border-gray-700">
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">DEV-001</td>
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">Temperature Variance</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                        Pending
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-500">2024-01-15</td>
                  </tr>
                  <tr className="border-b border-gray-100 dark:border-gray-700">
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">DEV-002</td>
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">Equipment Malfunction</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                        Completed
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-500">2024-01-14</td>
                  </tr>
                  <tr className="border-b border-gray-100 dark:border-gray-700">
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">DEV-003</td>
                    <td className="py-3 px-4 text-sm text-gray-900 dark:text-white">Process Deviation</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-800">
                        In Review
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-gray-500">2024-01-13</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-center text-gray-500">
          <p>✅ Dashboard loaded successfully with sample data!</p>
          <p>No API calls • No infinite loops • Pure static content</p>
        </div>
      </div>
    </div>
  )
}

export default SimpleDashboard
