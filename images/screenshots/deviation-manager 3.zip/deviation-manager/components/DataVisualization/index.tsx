import React, { useState } from 'react'
import { KpiBarChart, PieChart, LineChart, DoughnutChart } from '../Charts'
import { useKpis } from '../utils/hooks'

export const DataVisualization: React.FC = () => {
  const [selectedChart, setSelectedChart] = useState('bar')
  const { kpis } = useKpis()
  
  // Extract actual KPI values to ensure total deviations is correct
  const kpiData: [number, number, number, number] = [
    kpis.items[0]?.value || 0, // Total deviations
    kpis.items[1]?.value || 0, // Under investigation  
    kpis.items[2]?.value || 0, // CAPA required
    kpis.items[3]?.value || 0  // Pending resolution
  ]
  const pieData = [45, 30, 15, 10]
  const pieLabels = ['Production', 'Quality', 'Packaging', 'Logistics']
  const lineData = [12, 15, 18, 14, 20, 16, 19]
  const lineLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']

  const chartOptions = [
    { value: 'bar', label: 'Bar Chart' },
    { value: 'pie', label: 'Pie Chart' },
    { value: 'line', label: 'Line Chart' },
    { value: 'doughnut', label: 'Doughnut Chart' }
  ]

  const renderChart = () => {
    switch (selectedChart) {
      case 'bar':
        return <KpiBarChart data={kpiData} height="250px" />
      case 'pie':
        return <PieChart data={pieData} labels={pieLabels} height="250px" />
      case 'line':
        return <LineChart 
          data={lineData} 
          labels={lineLabels}
          label="Deviations"
          color="#3B82F6"
          height="250px"
        />
      case 'doughnut':
        return <DoughnutChart data={pieData} labels={pieLabels} height="250px" />
      default:
        return <KpiBarChart data={kpiData} height="250px" />
    }
  }

  return (
    <div className="bg-white rounded-lg shadow p-6 dark:bg-gray-800">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Data Visualization</h3>
        <div className="flex items-center gap-2">
          <label htmlFor="chart-selector" className="text-sm font-medium text-gray-700 dark:text-gray-300">
            Chart Type:
          </label>
          <select 
            id="chart-selector"
            value={selectedChart}
            onChange={(e) => setSelectedChart(e.target.value)}
            className="px-2.5 py-1.5 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100"
            aria-label="Select chart type"
          >
            {chartOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>
      
      <div className="w-full">
        {renderChart()}
      </div>
    </div>
  )
}

export default DataVisualization
