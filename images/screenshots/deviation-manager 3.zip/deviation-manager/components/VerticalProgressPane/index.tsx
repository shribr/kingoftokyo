import React from 'react'

export interface ProgressStep {
  id: number
  label: string
  description?: string
  completed?: boolean
}

export interface VerticalProgressPaneProps {
  steps: ProgressStep[]
  currentStep: number
  visitedStep?: number
  canAccessStep?: (stepId: number) => boolean
  getLegitimateCurrentStep?: () => number
  onStepClick?: (stepId: number) => void
  className?: string
}

export const VerticalProgressPane: React.FC<VerticalProgressPaneProps> = ({ 
  steps, 
  currentStep, 
  visitedStep,
  canAccessStep,
  getLegitimateCurrentStep,
  onStepClick,
  className = '' 
}) => {
  const progressWidth = (currentStep / steps.length) * 100
  const legitimateCurrentStep = getLegitimateCurrentStep ? getLegitimateCurrentStep() : currentStep
  
  return (
    <div className={`w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col ${className}`}>
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
          Progress
        </h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
          Timeline Steps
        </p>
      </div>

      {/* Progress Steps */}
      <div className="flex-1 p-4">
        <div className="space-y-6">
          {steps.map((step, index) => {
            const isCompleted = step.completed || false
            const isLegitimateCurrentStep = legitimateCurrentStep === step.id
            const isViewingThisStep = currentStep === step.id
            const isAccessible = canAccessStep ? canAccessStep(step.id) : true
            const isVisited = visitedStep ? visitedStep >= step.id : isViewingThisStep
            
            // Determine visual state:
            // - If completed: green
            // - If this is the legitimate current step (where user should be working): blue  
            // - Otherwise: gray
            
            return (
              <div key={step.id} className="relative">
                {/* Connector Line - Show for all except last step */}
                {index < steps.length - 1 && (
                  <div className={`absolute left-4 top-8 w-0.5 h-6 ${
                    isCompleted 
                      ? 'bg-green-500 dark:bg-green-500' 
                      : 'bg-gray-200 dark:bg-gray-600'
                  }`} />
                )}
                
                {/* Step Content */}
                <button
                  onClick={() => onStepClick?.(step.id)}
                  className="flex items-start space-x-3 w-full text-left hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg p-2 -m-2 transition-colors cursor-pointer"
                  disabled={!onStepClick}
                >
                  {/* Step Circle */}
                  <div className={`
                    flex-shrink-0 w-8 h-8 rounded-full border-2 flex items-center justify-center text-sm font-medium transition-colors
                    ${isCompleted 
                      ? 'bg-green-50 border-green-500 text-green-600 dark:bg-green-900/20 dark:border-green-400 dark:text-green-400'
                      : isLegitimateCurrentStep
                      ? 'bg-blue-50 border-blue-500 text-blue-600 dark:bg-blue-900/20 dark:border-blue-400 dark:text-blue-400' 
                      : 'bg-gray-50 border-gray-300 text-gray-500 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-400'
                    }
                  `}>
                    {isCompleted ? (
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    ) : (
                      step.id
                    )}
                  </div>
                  
                  {/* Step Info */}
                  <div className="flex-1 min-w-0">
                    <div className={`text-sm font-medium transition-colors ${
                      isCompleted
                        ? 'text-green-600 dark:text-green-400'
                        : isLegitimateCurrentStep
                        ? 'text-blue-600 dark:text-blue-400' 
                        : 'text-gray-500 dark:text-gray-400'
                    }`}>
                      {step.label}
                    </div>
                    {step.description && (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {step.description}
                      </div>
                    )}
                    {isLegitimateCurrentStep && (
                      <div className="text-xs text-blue-600 dark:text-blue-400 mt-1 font-medium">
                        In Progress
                      </div>
                    )}
                  </div>
                </button>
              </div>
            )
          })}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="text-xs text-gray-500 dark:text-gray-400">
          Step {currentStep} of {steps.length}
        </div>
        <div className="mt-2">
          <div className="w-full bg-gray-200 rounded-full h-1.5 dark:bg-gray-700">
            <div 
              className={`bg-blue-600 h-1.5 rounded-full transition-all duration-300 ${
                progressWidth === 0 ? 'w-0' :
                progressWidth <= 25 ? 'w-1/4' :
                progressWidth <= 50 ? 'w-1/2' :
                progressWidth <= 75 ? 'w-3/4' :
                'w-full'
              }`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}

export default VerticalProgressPane
