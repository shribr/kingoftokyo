import React, { useState } from 'react';
import type { DashboardConfig, DataSourceConfig } from '../config/types';
import { useDataSourceConfig } from '../utils/flexibleHooks';
import { 
  defaultDashboardConfig, 
  restApiConfig, 
  mongoDbConfig, 
  postgresConfig 
} from '../config/defaultConfig';

interface DataSourceConfigurationProps {
  onConfigChange?: (config: DashboardConfig) => void;
}

const DataSourceConfiguration: React.FC<DataSourceConfigurationProps> = ({ 
  onConfigChange 
}) => {
  const { health, loading, error, switchConfig } = useDataSourceConfig();
  const [selectedConfig, setSelectedConfig] = useState<string>('static');
  const [customConfig, setCustomConfig] = useState<string>('');
  const [showCustomConfig, setShowCustomConfig] = useState(false);

  const predefinedConfigs: Record<string, DashboardConfig> = {
    static: defaultDashboardConfig,
    restApi: restApiConfig,
    mongodb: mongoDbConfig,
    postgres: postgresConfig
  };

  const handleConfigChange = async (configName: string) => {
    try {
      let config: DashboardConfig;
      
      if (configName === 'custom') {
        if (!customConfig.trim()) {
          alert('Please provide a custom configuration');
          return;
        }
        config = JSON.parse(customConfig);
      } else {
        config = predefinedConfigs[configName];
      }
      
      await switchConfig(config);
      setSelectedConfig(configName);
      onConfigChange?.(config);
    } catch (err) {
      console.error('Failed to apply configuration:', err);
      alert('Failed to apply configuration. Please check the format and try again.');
    }
  };

  const getStatusColor = (connected: boolean) => {
    return connected ? 'text-green-600' : 'text-red-600';
  };

  const getStatusText = (connected: boolean) => {
    return connected ? 'Connected' : 'Disconnected';
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
        Data Source Configuration
      </h3>
      
      {/* Health Status */}
      {health && (
        <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-md">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Connection Status
          </h4>
          <div className="space-y-1 text-sm">
            <div>
              Primary: 
              <span className={`ml-1 font-medium ${getStatusColor(health.health?.primary)}`}>
                {getStatusText(health.health?.primary)}
              </span>
            </div>
            {health.health?.fallback !== undefined && (
              <div>
                Fallback: 
                <span className={`ml-1 font-medium ${getStatusColor(health.health.fallback)}`}>
                  {getStatusText(health.health.fallback)}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Error Display */}
      {error && (
        <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md">
          <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
        </div>
      )}

      {/* Configuration Options */}
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Select Data Source
          </label>
          <select
            value={selectedConfig}
            onChange={(e) => setSelectedConfig(e.target.value)}
            title="Select data source type"
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={loading}
          >
            <option value="static">Static Test Data</option>
            <option value="restApi">REST API</option>
            <option value="mongodb">MongoDB</option>
            <option value="postgres">PostgreSQL</option>
            <option value="custom">Custom Configuration</option>
          </select>
        </div>

        {/* Custom Configuration */}
        {selectedConfig === 'custom' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Custom Configuration (JSON)
            </label>
            <textarea
              value={customConfig}
              onChange={(e) => setCustomConfig(e.target.value)}
              placeholder="Enter your custom dashboard configuration in JSON format..."
              rows={10}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm"
            />
          </div>
        )}

        {/* Configuration Preview */}
        <div>
          <button
            onClick={() => setShowCustomConfig(!showCustomConfig)}
            className="text-sm text-blue-600 dark:text-blue-400 hover:underline"
          >
            {showCustomConfig ? 'Hide' : 'Show'} Configuration Preview
          </button>
          
          {showCustomConfig && (
            <div className="mt-2">
              <pre className="text-xs bg-gray-100 dark:bg-gray-900 p-3 rounded-md overflow-auto max-h-60">
                {JSON.stringify(
                  selectedConfig === 'custom' 
                    ? (customConfig ? JSON.parse(customConfig || '{}') : {})
                    : predefinedConfigs[selectedConfig] || {}, 
                  null, 
                  2
                )}
              </pre>
            </div>
          )}
        </div>

        {/* Apply Button */}
        <button
          onClick={() => handleConfigChange(selectedConfig)}
          disabled={loading}
          className="w-full px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-medium rounded-md transition-colors duration-200"
        >
          {loading ? 'Applying...' : 'Apply Configuration'}
        </button>

        {/* Documentation */}
        <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-md">
          <h4 className="text-sm font-medium text-blue-900 dark:text-blue-300 mb-2">
            Configuration Options
          </h4>
          <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
            <li><strong>Static Test Data:</strong> Uses generated test data (default)</li>
            <li><strong>REST API:</strong> Connects to REST endpoints for data</li>
            <li><strong>MongoDB:</strong> Connects to MongoDB database (requires backend)</li>
            <li><strong>PostgreSQL:</strong> Connects to PostgreSQL database (requires backend)</li>
            <li><strong>Custom:</strong> Use your own JSON configuration</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default DataSourceConfiguration;
