import React, { useState, useEffect } from 'react';
import type { TDialogProps } from '~/common';
import { Dialog, DialogPanel, Transition, TransitionChild } from '@headlessui/react';
import { Spinner } from '~/components/svg';
import { useLocalize } from '~/hooks';
import { cn } from '~/utils';
import UploadEvidence from './UploadEvidence';
import { useReGenerateDeviation } from '../../queries/useDeviationMutations';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';
import Callout, { CalloutType } from '~/features/shared/components/Callout';

export default function ManageDocuments({
  open,
  onOpenChange,
  evidences,
  draftDeviationId,
  onSuccess,
  onCancel,
}: TDialogProps & {
  draftDeviationId: string;
  evidences: FileEvidence[];
  onSuccess?: () => void;
  onCancel?: () => void;
}) {
  const localize = useLocalize();
  const { showToast } = useToastContext();
  const [documents, setDocuments] = useState<FileEvidence[]>([]);
  const regenerateMutation = useReGenerateDeviation();
  const [deletedDocuments, setDeletedDocuments] = useState<FileEvidence[]>([]);

  useEffect(() => {
    if (open) {
      setDeletedDocuments([]);
      setDocuments([]);
    }
  }, [open]);

  const handleFileChanged = (files: FileEvidence[]) => {
    setDocuments(files);
  };

  const handleCancel = () => {
    onOpenChange(false);
    onCancel?.();
  };

  const handleDelete = async (deletedFile: FileEvidence | undefined) => {
    if (deletedFile && deletedFile.id && deletedFile.id !== '') {
      setDeletedDocuments((prev) => [...prev, deletedFile]);
    }
  };

  const handleReGenerate = async () => {
    await regenerateMutation.mutateAsync(
      {
        draft_deviation_id: draftDeviationId,
        evidences: documents,
        removed_evidences: deletedDocuments,
      },
      {
        onSuccess: () => {
          showToast({
            message: localize('manage_documents_regenerate_success'),
            severity: NotificationSeverity.SUCCESS,
          });
          onOpenChange(false);
          onSuccess?.();
        },
        onError: () => {
          showToast({
            message: localize('manage_documents_regenerate_error'),
            severity: NotificationSeverity.ERROR,
            showIcon: true,
          });
        },
      },
    );
  };

  return (
    <Transition appear show={open}>
      <Dialog as="div" className="relative z-50" onClose={() => {}}>
        <TransitionChild
          enter="ease-out duration-200"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-black opacity-50 dark:opacity-80" aria-hidden="true" />
        </TransitionChild>

        <TransitionChild
          enter="ease-out duration-200"
          enterFrom="opacity-0 scale-95"
          enterTo="opacity-100 scale-100"
          leave="ease-in duration-100"
          leaveFrom="opacity-100 scale-100"
          leaveTo="opacity-0 scale-95"
        >
          <div className={cn('fixed inset-0 flex w-screen items-center justify-center p-4')}>
            <DialogPanel
              className={cn(
                'w-full overflow-hidden rounded-xl rounded-b-lg bg-background pb-6 shadow-2xl backdrop-blur-2xl animate-in sm:rounded-2xl md:w-[70%] lg:w-[50%]',
              )}
            >
              <div className="overflow-auto p-2 md:w-full">
                <UploadEvidence
                  title={localize('manage_documents_heading')}
                  subTitle={localize('manage_documents_sub_heading')}
                  evidences={evidences}
                  onFileChanged={(e) => handleFileChanged(e)}
                  onDelete={(e) => handleDelete(e)}
                  disableUpload={regenerateMutation.isLoading}
                  disableDelete={regenerateMutation.isLoading}
                />
              </div>
              <div className="mb-2 px-6">
                <Callout text={localize('manage_documents_info_text')} type={CalloutType.Error} />
              </div>
              <div className={'flex w-full items-center justify-end gap-4 px-4'}>
                <button
                  type="button"
                  className="btn btn-secondary relative mt-2 cursor-pointer"
                  disabled={regenerateMutation.isLoading}
                  onClick={handleCancel}
                >
                  {localize('manage_documents_cancel_button_text')}
                </button>
                <button
                  type="button"
                  className="btn btn-primary relative mr-2 mt-2 cursor-pointer"
                  disabled={regenerateMutation.isLoading}
                  onClick={handleReGenerate}
                >
                  {regenerateMutation.isLoading ? (
                    <div className="flex gap-2">
                      {localize('busy_operation_text')}
                      <Spinner size="1.5em" className={'ml-1'} />
                    </div>
                  ) : (
                    localize('manage_documents_generate_button_text')
                  )}
                </button>
              </div>
            </DialogPanel>
          </div>
        </TransitionChild>
      </Dialog>
    </Transition>
  );
}