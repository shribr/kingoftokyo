import React, { useState, useEffect } from 'react';

export interface ToastProps {
  message: string;
  type?: 'success' | 'error' | 'info';
  duration?: number;
  onClose?: () => void;
  category?: string;
}

export const Toast: React.FC<ToastProps> = ({ 
  message, 
  type = 'info', 
  duration = 3000, 
  onClose,
  category
}) => {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    // Shorter duration for data source notifications
    const actualDuration = category === 'data-source' ? 2000 : duration;
    
    const timer = setTimeout(() => {
      setIsVisible(false);
      setTimeout(() => onClose?.(), 300); // Wait for fade out animation
    }, actualDuration);

    return () => clearTimeout(timer);
  }, [duration, onClose, category]);

  const getTypeClasses = () => {
    switch (type) {
      case 'success':
        return 'bg-green-500 text-white';
      case 'error':
        return 'bg-red-500 text-white';
      case 'info':
      default:
        return 'bg-blue-500 text-white';
    }
  };

  return (
    <div 
      className={`
        p-3 rounded-lg shadow-lg transition-all duration-300 ease-in-out
        ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-2'}
        ${getTypeClasses()}
        ${category === 'data-source' ? 'scale-105' : ''}
      `}
    >
      <div className="flex items-center space-x-2">
        <span className="text-sm font-medium">{message}</span>
        <button
          onClick={() => {
            setIsVisible(false);
            setTimeout(() => onClose?.(), 300);
          }}
          className="ml-2 text-white hover:text-gray-200"
          aria-label="Close notification"
          title="Close notification"
        >
          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
    </div>
  );
};

export interface ToastContextType {
  showToast: (message: string, type?: 'success' | 'error' | 'info', category?: string) => void;
}

const ToastContext = React.createContext<ToastContextType | undefined>(undefined);

export const useToast = () => {
  const context = React.useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Array<{ 
    id: number; 
    message: string; 
    type: 'success' | 'error' | 'info';
    category?: string;
  }>>([]);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info', category?: string) => {
    const id = Date.now();
    
    setToasts(prev => {
      // If this is a categorized toast, remove any existing toasts in the same category
      if (category) {
        const filtered = prev.filter(toast => toast.category !== category);
        return [...filtered, { id, message, type, category }];
      }
      
      // For uncategorized toasts, just add to the array
      return [...prev, { id, message, type, category }];
    });
  };

  const removeToast = (id: number) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed bottom-20 right-4 z-50 space-y-2">
        {toasts.map(toast => (
          <Toast
            key={toast.id}
            message={toast.message}
            type={toast.type}
            category={toast.category}
            onClose={() => removeToast(toast.id)}
          />
        ))}
      </div>
    </ToastContext.Provider>
  );
};
