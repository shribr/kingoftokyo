import { cn } from '~/utils';
import { Search, X } from 'lucide-react';
import { useState } from 'react';

export default function SearchDeviations() {
  const isSmallScreen = true;
  const [text, setText] = useState('');
  const [showClearIcon, setShowClearIcon] = useState(false);

  const clearText = () => {
    setShowClearIcon(false);
    setText('');
  };

  return (
    <div
      // ref={ref}
      className={cn(
        'group relative mt-1 flex h-10 cursor-pointer items-center gap-3 bg-white rounded-lg border-border-medium px-3 py-2 text-text-primary transition-colors duration-200 focus-within:bg-white hover:bg-white',
        isSmallScreen === true ? 'mb-2 h-14 rounded-2xl' : '',
      )}
    >
      {
        <Search className="absolute left-3 h-4 w-4 text-text-secondary group-focus-within:text-text-primary group-hover:text-text-primary" />
      }
      <input
        type="text"
        className="m-0 mr-0 w-full border-none bg-transparent p-0 pl-7 text-sm leading-tight placeholder-text-secondary placeholder-opacity-100 focus-visible:outline-none group-focus-within:placeholder-text-primary group-hover:placeholder-text-primary"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          e.code === 'Space' ? e.stopPropagation() : null;
        }}
        aria-label={'label'}
        placeholder={'Search deviations...'}
        // onKeyUp={handleKeyUp}
        // onFocus={() => setIsSearching(true)}
        // onBlur={() => setIsSearching(true)}
        autoComplete="off"
        dir="auto"
      />
      <X
        className={cn(
          'absolute right-[7px] h-5 w-5 cursor-pointer transition-opacity duration-200',
          showClearIcon ? 'opacity-100' : 'opacity-0',
          isSmallScreen === true ? 'right-[16px]' : '',
        )}
        onClick={clearText}
      />
    </div>
  )
}