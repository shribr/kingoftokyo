import React, { useEffect, useState } from 'react';
import { Hourglass, Trash } from 'lucide-react';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';
import useLocalize from '~/hooks/useLocalize';
import DraggableArea from '~/features/shared/components/DraggableArea';

const UploadEvidence: React.FC<{
  title?: string;
  subTitle?: string;
  evidences?: FileEvidence[];
  disableUpload?: boolean;
  disableDelete?: boolean;
  onFileChanged?: (files: FileEvidence[]) => void;
  onDelete?: (file: FileEvidence | undefined) => void;
}> = ({ title, subTitle, evidences, disableUpload, disableDelete, onFileChanged, onDelete }) => {
  const localize = useLocalize();
  const [files, setFiles] = useState<FileEvidence[]>(evidences || []);
  const { showToast } = useToastContext();
  const titleText = title || localize('upload_evidence_default_title');
  const subTitleText = subTitle || '';
  const [deletingId, setDeletingId] = useState<number>();

  const allowedTypes = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/csv',
  ];

  const validate = (files) => {
    const errors: string[] = [];
    for (let file of files) {
      if (file.size > 25 * 1024 * 1024) {
        errors.push(`${localize('upload_evidence_validation_file_length')}: ${file.name}`);
      }

      if (!allowedTypes.includes(file.type)) {
        errors.push(`${localize('upload_evidence_validation_file_type')}: ${file.name}`);
      }
    }
    if (errors.length > 0) {
      showToast({
        message: errors.join('\n'),
        severity: NotificationSeverity.ERROR,
      });
      return false;
    }
    return true;
  };

  const handleFileUpload = (files: File[]) => {
    const newFiles = files;
    if (newFiles.length === 0) return;
    if (!validate(newFiles)) return;
    setFiles((prevFiles) => {
      const newEvidences = newFiles.map((file) => ({
        file: file,
        file_name: file.name,
        content_type: file.type,
        id: '',
      }));

      const updatedEvidences = [...prevFiles, ...newEvidences];
      onFileChanged?.(updatedEvidences);
      return updatedEvidences;
    });
  };

  const handleDelete = async (indexToDelete) => {
    setDeletingId(indexToDelete);

    let updatedFiles;
    setFiles((prevFiles) => {
      updatedFiles = prevFiles.filter((_, index) => index !== indexToDelete);
      return updatedFiles;
    });

    await onDelete?.(files.find((_, index) => index === indexToDelete));

    onFileChanged?.(updatedFiles);

    setDeletingId(undefined);
  };

  useEffect(() => {
    if (evidences) {
      setFiles(evidences);
    }
  }, [evidences]);

  return (
    <div className="mx-auto rounded-lg px-4 py-2">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-text-primary">{titleText}</h2>
      </div>
      {subTitleText !== '' && (
        <div className="flex w-full items-center justify-between pt-3">
          <h6 className="text-xs text-text-primary">{subTitleText}</h6>
        </div>
      )}
      <div className="flex items-center justify-between py-4">
        <DraggableArea onFilesUploaded={handleFileUpload} disable={disableUpload}>
          <div className="flex w-full items-center justify-center bg-gray-50 p-2 text-xs font-medium text-gray-500">
            {localize('upload_evidence_info_text_1')}:{' '}
            <strong className="text-s px-1">{localize('upload_evidence_info_text_2')}</strong>{' '}
            <span className="px-1 text-base font-thin text-gray-300"> | </span>
            {localize('upload_evidence_info_text_3')}:{' '}
            <strong>{localize('upload_evidence_info_text_4')}</strong>
          </div>
        </DraggableArea>
      </div>
      <div className="mt-2 rounded-md border border-gray-200 dark:border-gray-500">
        <div className="flex items-center justify-between bg-gray-50 p-2 text-sm font-semibold text-text-primary dark:bg-gray-600">
          <span>{localize('upload_evidence_name_column')}</span>
        </div>
        <div
          className={`flex ${(files?.length ?? 0 > 0) ? 'max-h-[300px] md:max-h-[370px]' : ''} flex-col overflow-y-auto`}
        >
          {files.length === 0 ? (
            <div className="p-2 text-center text-gray-500">
              {localize('upload_evidence_no_files_found')}
            </div>
          ) : (
            files
              .sort((a, b) => a.file_name.localeCompare(b.file_name))
              .map((file, index) => (
                <div
                  key={index}
                  className={`flex items-center justify-between border-b p-2 dark:border-gray-500 ${deletingId === index ? 'animate-pulse bg-gray-200' : ''}`}
                >
                  <span className="text-sm text-text-primary">{file.file_name}</span>
                  <button
                    key={index}
                    type="button"
                    onClick={() => handleDelete(index)}
                    className="text-gray-500 hover:text-red-500"
                    disabled={disableDelete}
                  >
                    {deletingId === index ? (
                      <Hourglass size={16} className="animate-spin text-red-500" />
                    ) : (
                      <Trash
                        size={16}
                        className={`${disableDelete ? 'cursor-not-allowed opacity-[0.5]' : ''}`}
                      />
                    )}
                  </button>
                </div>
              ))
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadEvidence;
