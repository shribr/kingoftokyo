import React, { useState } from 'react'
import { useTableContext } from '../context/TableContext'

import type { Deviation, TableColumn } from '../utils/types'

import { isUsingLiveData } from '../utils/dataHelper'
import { refreshDeviationRecords } from '../../services/DeviationManagerService';

type SortDirection = 'asc' | 'desc' | null

interface SortState {
  column: string | null
  direction: SortDirection
}

// Classification styling: red=major, yellow=moderate, green=minor
const getClassificationStyle = (classification: string) => {
  switch (classification?.toLowerCase()) {
    case 'major':
      return 'bg-red-100 text-red-800 border-red-200'
    case 'moderate':
      return 'bg-yellow-100 text-yellow-800 border-yellow-200'
    case 'minor':
      return 'bg-green-100 text-green-800 border-green-200'
    default:
      return 'bg-gray-100 text-gray-800 border-gray-200'
  }
}

// Stage styling (using colorful pill colors based on screenshot)
const getStageStyle = (stage: string) => {
  switch (stage?.toLowerCase()) {
    case 'initial review & impact':
      return 'bg-brand-100 text-brand-800 border-brand-200'
    case 'investigation in progress':
      return 'bg-purple-100 text-purple-800 border-purple-200'
    case 'root cause analysis':
      return 'bg-orange-100 text-orange-800 border-orange-200'
    case 'capa development':
      return 'bg-indigo-100 text-indigo-800 border-indigo-200'
    case 'capa & conclusion':
      return 'bg-green-100 text-green-800 border-green-200'
    default:
      return 'bg-brand-100 text-brand-800 border-brand-200'
  }
}

// Styled cell component
interface StyledCellProps {
  content: string
  type: 'classification' | 'stage'
}

const StyledCell: React.FC<StyledCellProps> = ({ content, type }) => {
  const styleClass = type === 'classification' 
    ? getClassificationStyle(content) 
    : getStageStyle(content)

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap ${styleClass}`}>
      {content}
    </span>
  )
}

// AD Profile Cell component
interface ADProfileCellProps {
  user: {
    name: string
    avatar?: string
    status?: 'online' | 'away' | 'busy' | 'offline'
  }
}

const ADProfileCell: React.FC<ADProfileCellProps> = ({ user }) => {
  const getStatusColor = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'bg-green-500'
      case 'away': return 'bg-yellow-500'
      case 'busy': return 'bg-red-500'
      case 'offline': return 'bg-gray-400'
      default: return 'bg-gray-400'
    }
  }

  const getStatusTitle = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'Online'
      case 'away': return 'Away'
      case 'busy': return 'Busy'
      case 'offline': return 'Offline'
      default: return 'Unknown'
    }
  }

  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="relative flex-shrink-0">
        <div className="h-8 w-8 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center dark:bg-gray-600 dark:border-gray-500">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" className="text-gray-600 dark:text-gray-300">
            <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm0 2c-4.418 0-8 2.239-8 5v1h16v-1c0-2.761-3.582-5-8-5z"/>
          </svg>
        </div>
        <div 
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white dark:border-gray-800 ${getStatusColor(user.status)}`}
          title={getStatusTitle(user.status)}
        />
      </div>
      <span className="text-xs text-gray-900 truncate dark:text-gray-100">{user.name}</span>
    </div>
  )
}

// Built-in Pagination component
interface PaginationProps {
  currentPage: number
  totalPages: number
  onPageChange: (page: number) => void
  isLiveData?: boolean
  onRefreshData?: () => Promise<void>
}

const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange, isLiveData, onRefreshData }) => {
  // Don't show pagination if there's only one page or no pages
  if (totalPages <= 1) return null
  
  // Ensure we have valid page numbers
  const safeTotalPages = Math.max(totalPages, 1)
  const safeCurrentPage = Math.max(Math.min(currentPage, safeTotalPages), 1)
  
  return (
    <div className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6 mt-4 dark:border-gray-700 dark:bg-gray-800">
      {/* Left side - data source indicator */}
      <div className="flex items-center">
        <button
          onClick={onRefreshData}
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border whitespace-nowrap transition-colors cursor-pointer hover:opacity-80 ${
            isLiveData 
              ? 'bg-green-100 text-green-800 border-green-200 hover:bg-green-200' // Minor style (green)
              : 'bg-yellow-100 text-yellow-800 border-yellow-200 hover:bg-yellow-200' // Moderate style (yellow)
          }`}
          title="Click to refresh data"
        >
          <span>{isLiveData ? 'Live Data' : 'Sample Data'}</span>
        </button>
      </div>
      
      {/* Right side - pagination controls */}
      <div className="flex items-center space-x-4">
        {/* Page info */}
        <span className="text-sm text-gray-700 dark:text-gray-300">
          Page <span className="font-medium">{safeCurrentPage}</span> of{' '}
          <span className="font-medium">{safeTotalPages}</span>
        </span>
        
        {/* Navigation controls */}
        <div className="flex items-center space-x-1">
          <button
            onClick={() => onPageChange(safeCurrentPage - 1)}
            disabled={safeCurrentPage === 1}
            className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
          >
            Previous
          </button>
          
          {/* Page number buttons - show smart pagination */}
          <div className="flex items-center space-x-1">
            {/* Always show first page */}
            <button
              onClick={() => onPageChange(1)}
              className={`relative inline-flex items-center px-3 py-2 text-sm font-semibold rounded-md ${
                safeCurrentPage === 1
                  ? 'bg-brand-600 text-white'
                  : 'text-gray-900 bg-white border border-gray-300 hover:bg-gray-50 dark:text-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:hover:bg-gray-600'
              }`}
            >
              1
            </button>
            
            {/* Show ellipsis if current page is far from start */}
            {safeCurrentPage > 3 && safeTotalPages > 5 && (
              <span className="relative inline-flex items-center px-3 py-2 text-sm font-semibold text-gray-700 dark:text-gray-300">
                ...
              </span>
            )}
            
            {/* Show pages around current page */}
            {Array.from({ length: safeTotalPages }, (_, i) => i + 1)
              .filter(pageNum => {
                if (pageNum === 1 || pageNum === safeTotalPages) return false
                return Math.abs(pageNum - safeCurrentPage) <= 1
              })
              .map(pageNum => (
                <button
                  key={pageNum}
                  onClick={() => onPageChange(pageNum)}
                  className={`relative inline-flex items-center px-3 py-2 text-sm font-semibold rounded-md ${
                    safeCurrentPage === pageNum
                      ? 'bg-brand-600 text-white'
                      : 'text-gray-900 bg-white border border-gray-300 hover:bg-gray-50 dark:text-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:hover:bg-gray-600'
                  }`}
                >
                  {pageNum}
                </button>
              ))}
            
            {/* Show ellipsis if current page is far from end */}
            {safeCurrentPage < safeTotalPages - 2 && safeTotalPages > 5 && (
              <span className="relative inline-flex items-center px-3 py-2 text-sm font-semibold text-gray-700 dark:text-gray-300">
                ...
              </span>
            )}
            
            {/* Always show last page if there's more than 1 page */}
            {safeTotalPages > 1 && (
              <button
                onClick={() => onPageChange(safeTotalPages)}
                className={`relative inline-flex items-center px-3 py-2 text-sm font-semibold rounded-md ${
                  safeCurrentPage === safeTotalPages
                    ? 'bg-brand-600 text-white'
                    : 'text-gray-900 bg-white border border-gray-300 hover:bg-gray-50 dark:text-gray-100 dark:bg-gray-700 dark:border-gray-600 dark:hover:bg-gray-600'
                }`}
              >
                {safeTotalPages}
              </button>
            )}
          </div>
          
          <button
            onClick={() => onPageChange(safeCurrentPage + 1)}
            disabled={safeCurrentPage === safeTotalPages}
            className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  )
}

export const Table: React.FC = () => {
  const { 
    deviations, 
    pagination,
    loading,
    handlePageChange,
    handleCreateRecord
  } = useTableContext()

  console.log('Table: useTableContext() returned:', { 
    deviations: deviations?.length, 
    pagination, 
    loading, 
    handlePageChange: !!handlePageChange,
    handleCreateRecord: !!handleCreateRecord,
    handleCreateRecordType: typeof handleCreateRecord
  })

  // Add debugging for loading state
  console.log('Table: Loading state is:', loading)

  const [sortState, setSortState] = useState<SortState>({
    column: null,
    direction: null
  })

  // Add shared refresh state
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Constants for table sizing
  const ROWS_PER_PAGE = 5
  const ROW_HEIGHT = 48 // px-3 py-3 with text content ≈ 48px
  const HEADER_HEIGHT = 48 // Header row height
  const TABLE_HEADER_HEIGHT = 64 // Table title and create button section
  const PAGINATION_HEIGHT = 60 // Pagination section height
  
  // Calculate expected table content height
  const expectedTableHeight = TABLE_HEADER_HEIGHT + HEADER_HEIGHT + (ROW_HEIGHT * ROWS_PER_PAGE) + PAGINATION_HEIGHT

  // Create a refresh handler that manages the loading state
  const handleRefreshData = async () => {
    if (isRefreshing) return // Prevent multiple simultaneous refresh operations
    
    console.log('Refreshing deviation data...')
    setIsRefreshing(true)
    try {
      await refreshDeviationRecords()
      console.log('Data refresh completed')
      // The table context should automatically pick up the new data
    } catch (error) {
      console.error('Failed to refresh data:', error)
    } finally {
      setIsRefreshing(false)
    }
  }

  // Sort data based on current sort state
  const sortedDeviations = React.useMemo(() => {
    if (!sortState.column || !sortState.direction) {
      return deviations
    }

    return [...deviations].sort((a, b) => {
      const aValue = a[sortState.column as keyof Deviation]
      const bValue = b[sortState.column as keyof Deviation]
      
      // Handle different data types
      let comparison = 0
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        comparison = aValue.localeCompare(bValue)
      } else if (aValue instanceof Date && bValue instanceof Date) {
        comparison = aValue.getTime() - bValue.getTime()
      } else {
        comparison = String(aValue).localeCompare(String(bValue))
      }

      return sortState.direction === 'asc' ? comparison : -comparison
    })
  }, [deviations, sortState])

  // Handle column header click for sorting
  const handleSort = (columnKey: string) => {
    setSortState(prev => {
      if (prev.column === columnKey) {
        // Cycle through: asc -> desc -> null
        const nextDirection: SortDirection = 
          prev.direction === 'asc' ? 'desc' : 
          prev.direction === 'desc' ? null : 'asc'
        
        return {
          column: nextDirection ? columnKey : null,
          direction: nextDirection
        }
      } else {
        return {
          column: columnKey,
          direction: 'asc'
        }
      }
    })
  }

  // Sort indicator component
  const SortIndicator: React.FC<{ column: string }> = ({ column }) => {
    if (sortState.column !== column) {
      return (
        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4" />
        </svg>
      )
    }

    if (sortState.direction === 'asc') {
      return (
        <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" />
        </svg>
      )
    }

    return (
      <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
      </svg>
    )
  }

  const columns: TableColumn<Deviation>[] = [
    {
      header: 'Trackwise Record',
      key: 'trackwiseRecord',
      render: (row) => (
        <span className="text-xs text-gray-900 dark:text-gray-100">
          {row.trackwiseRecord || `TW-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 9999) + 1).padStart(4, '0')}`}
        </span>
      )
    },
    {
      header: 'Deviation Name',
      key: 'name',
      render: (row) => {
        // Add debugging to see what's actually in the row
        console.log('Deviation name row:', { 
          id: row.id, 
          name: row.name, 
          title: row.title, 
          fullRow: row 
        });
        
        return (
          <span className="truncate block max-w-xs" title={row.name || row.title || 'No name available'}>
            {row.name || row.title || 'No name available'}
          </span>
        );
      }
    },
    {
      header: 'Department',
      key: 'department'
    },
    {
      header: 'Classification',
      key: 'classification',
      render: (row) => <StyledCell content={row.classification} type="classification" />
    },
    {
      header: 'Stage',
      key: 'stage',
      render: (row) => <StyledCell content={row.stage} type="stage" />
    },
    {
      header: 'Date of Occurrence',
      key: 'date',
      render: (row) => {
        const date = new Date(row.date);
        return date.toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        });
      }
    },
    {
      header: 'Assignee',
      key: 'assignee',
      render: (row) => <ADProfileCell user={row.assignee} />
    }
  ]

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden dark:bg-gray-800 relative" style={{ minHeight: `${expectedTableHeight}px` }}>

   
      {/* Refresh Overlay */}
      {isRefreshing && (
        <div className="absolute inset-0 bg-white/50 dark:bg-gray-800/50 flex items-center justify-center z-10 backdrop-blur-sm">
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-3">
              <svg 
                className="h-6 w-6 animate-spin text-brand-600" 
                xmlns="http://www.w3.org/2000/svg" 
                fill="none" 
                viewBox="0 0 24 24"
              >
                <circle 
                  className="opacity-25" 
                  cx="12" 
                  cy="12" 
                  r="10" 
                  stroke="currentColor" 
                  strokeWidth="4"
                />
                <path 
                  className="opacity-75" 
                  fill="currentColor" 
                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                />
              </svg>
              <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                Refreshing data...
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Loading Overlay - shown during initial load with improved z-index and styling */}
      {loading && (
        <div 
          className="fixed inset-0 bg-black/20 flex items-center justify-center z-50" 
          style={{ 
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            zIndex: 9999
          }}
        >
          <div className="bg-white dark:bg-gray-800 rounded-lg p-8 shadow-2xl border border-gray-200 dark:border-gray-700 max-w-sm mx-4">
            <div className="flex flex-col items-center space-y-4">
              <div className="relative">
                <svg 
                  className="h-12 w-12 animate-spin text-brand-600" 
                  xmlns="http://www.w3.org/2000/svg" 
                  fill="none" 
                  viewBox="0 0 24 24"
                >
                  <circle 
                    className="opacity-25" 
                    cx="12" 
                    cy="12" 
                    r="10" 
                    stroke="currentColor" 
                    strokeWidth="4"
                  />
                  <path 
                    className="opacity-75" 
                    fill="currentColor" 
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  />
                </svg>
              </div>
              <div className="text-center space-y-2">
                <p className="text-lg font-medium text-gray-900 dark:text-gray-100">Loading deviation records</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">Please wait while we fetch your data...</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Table Header with Title, Refresh Icon, and Create Button */}
      <div className="px-3 py-4 border-b border-gray-200 flex items-center justify-between dark:border-gray-700" style={{ height: `${TABLE_HEADER_HEIGHT}px` }}>
        <div className="flex items-center space-x-3">
          <h2 className="text-lg font-semibold text-brand-600">Recent records</h2>
          <button
            onClick={handleRefreshData}
            disabled={isRefreshing || loading}
            className="p-1.5 text-gray-400 hover:text-brand-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            title="Refresh data"
          >
            <svg 
              className={`h-5 w-5 ${isRefreshing ? 'animate-spin' : ''}`} 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24" 
              xmlns="http://www.w3.org/2000/svg"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" 
              />
            </svg>
          </button>
        </div>
        <button
          className={`px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
            loading 
              ? 'bg-gray-300 text-gray-500 cursor-not-allowed' 
              : 'bg-brand-600 hover:bg-brand-700 text-white'
          }`}
          disabled={loading}
          onClick={() => {
            console.log('Table: Create button clicked')
            console.log('Table: handleCreateRecord is', handleCreateRecord)
            if (handleCreateRecord) {
              console.log('Table: Calling handleCreateRecord')
              handleCreateRecord()
            } else {
              console.log('Create record clicked - no handler provided')
            }
          }}
        >
          Create record
        </button>
      </div>

      {/* Table */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full min-w-[1200px] divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-700" style={{ height: `${HEADER_HEIGHT}px` }}>
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="px-3 py-3 text-left text-xs font-medium text-gray-500 tracking-wider cursor-pointer hover:bg-gray-100 transition-colors dark:text-gray-300 dark:hover:bg-gray-600"
                  onClick={() => handleSort(column.key)}
                >
                  <div className="flex items-center space-x-1">
                    <span>{column.header}</span>
                    <SortIndicator column={column.key} />
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700" style={{ minHeight: `${ROW_HEIGHT * ROWS_PER_PAGE}px` }}>
            {!loading && sortedDeviations.map((row, rowIndex) => (
              <tr key={rowIndex} className="hover:bg-gray-50 dark:hover:bg-gray-700" style={{ height: `${ROW_HEIGHT}px` }}>
                {columns.map((column, columnIndex) => (
                  <td 
                    key={column.key} 
                    className={`px-3 py-3 text-xs text-gray-900 dark:text-gray-100 ${
                      columnIndex === 1 ? 'max-w-xs' : '' // Allow deviation name column to be wider
                    }`}
                  >
                    {column.render ? column.render(row) : String(row[column.key] || '')}
                  </td>
                ))}
              </tr>
            ))}
            {/* Fill empty rows to maintain consistent height */}
            {!loading && Array.from({ length: Math.max(0, ROWS_PER_PAGE - sortedDeviations.length) }, (_, index) => (
              <tr key={`empty-${index}`} style={{ height: `${ROW_HEIGHT}px` }}>
                {columns.map((column) => (
                  <td key={column.key} className="px-3 py-3">
                    &nbsp;
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Built-in Pagination */}
      <div style={{ height: `${PAGINATION_HEIGHT}px` }}>
        {!loading && (
          <Pagination 
            currentPage={pagination.page}
            totalPages={pagination.totalPages}
            onPageChange={handlePageChange}
            isLiveData={isUsingLiveData()}
            onRefreshData={handleRefreshData}
          />
        )}
      </div>
    </div>
  )
}

export default Table