import React, { useCallback, useEffect, useState } from 'react';
import { cn } from '~/utils';
import { Link } from 'react-router-dom';
import DeviationOptions from './DeviationOptions';
import RenameDeviation from './RenameDeviation';
import { useUpdateDeviation } from '../queries/useDeviationMutations';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';
import { useLocalize } from '~/hooks';

type props = {
  id: string;
  label: string;
  onClick?: (id: string) => void;
  isActive?: boolean;
};

export default function DeviationListItem({ id, label, onClick, isActive = false }: props) {
  const localize = useLocalize();
  const updateDeviation = useUpdateDeviation();
  const { showToast } = useToastContext();
  const [isPopoverActive, setIsPopoverActive] = useState(false);
  const [renaming, setRenaming] = useState(false);
  const [deviationName, setDeviationName] = useState(label);

  const onClickHandler = useCallback(() => {
    if (onClick) {
      onClick(id);
    }
  }, [id, onClick, deviationName]);

  const renameHandler = useCallback(() => {
    setIsPopoverActive(false);
    setRenaming(true);
  }, [deviationName]);

  const handleCancelRename = useCallback(() => {
    setRenaming(false);
    setIsPopoverActive(false);
  }, [setRenaming, setIsPopoverActive]);

  const mutateOptions = {
    onSuccess: (response) => {
      setRenaming(false);
      setDeviationName(response.result?.name);
      showToast({
        message: localize('deviation_name_change_success'),
        severity: NotificationSeverity.SUCCESS,
        showIcon: true,
      });
    },
    onError: (error) => {
      showToast({
        message: localize('deviation_name_change_error'),
        severity: NotificationSeverity.ERROR,
        showIcon: true,
      });
    },
  };

  const handleRename = useCallback(
    (newTitle: string) => {
      if (newTitle === deviationName) {
        setRenaming(false);
        setIsPopoverActive(false);
        return;
      }

      updateDeviation.mutate(
        {
          draft_deviation_id: id,
          payload: {
            name: newTitle,
          },
        },
        mutateOptions,
      );
    },
    [id, updateDeviation, mutateOptions],
  );

  useEffect(() => {
    if (isActive) {
      document.title = deviationName;
    }
  }, [isActive, deviationName]);

  return (
    <div
      className={cn(
        'group relative mt-1 flex h-9 w-full items-center border-b hover:bg-surface-active-alt',
        isActive ? 'bg-surface-active-alt' : '',
      )}
      onDoubleClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        setRenaming(true);
      }}
    >
      {renaming ? (
        <RenameDeviation
          title={deviationName}
          onCancelRename={handleCancelRename}
          onRename={handleRename}
          isProcessing={updateDeviation.isLoading}
        />
      ) : (
        <>
          <Link
            to={`/c/${id}`}
            className={cn(
              'flex grow cursor-pointer items-center gap-2 overflow-hidden whitespace-nowrap break-all border-b px-2 py-2',
              isActive ? 'bg-surface-active-alt' : '',
            )}
            onClick={onClickHandler}
            title={deviationName}
          >
            {deviationName}
          </Link>
          <DeviationOptions
            deviationId={id}
            renameHandler={renameHandler}
            isPopoverActive={isPopoverActive}
            setIsPopoverActive={setIsPopoverActive}
          />
        </>
      )}
    </div>
  );
}
