import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useDeviationManagerService } from '~/features/deviation-manager/hooks/useDeviationManagerService';
import type { DraftDeviation, GenerateDeviationRequest, FileEvidence } from '../services/DeviationManagerService';
import { QueryKeys } from '../constants/queryKeys';

export const useCreateDeviationMutation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async (data: Partial<DraftDeviation>) => {
      return await deviationService.createDraftDeviation(data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
    },
  });
};

export const useGenerateDeviationMutation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ draftId, data }: { draftId: string; data: GenerateDeviationRequest }) => {
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
    },
  });
};

export const useUpdateDeviationMutation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<DraftDeviation> }) => {
      return await deviationService.updateDraftDeviation(id, updates);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.id] });
    },
  });
};

// This is a rename of your existing useUpdateDeviationMutation
export const useUpdateDeviation = useUpdateDeviationMutation;

export const useDeleteDeviationMutation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async (id: string) => {
      return await deviationService.deleteDraftDeviation(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
    },
  });
};

export const useSubmitDeviationMutation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async (id: string) => {
      return await deviationService.submitDraftDeviation(id);
    },
    onSuccess: (_, id) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, id] });
    },
  });
};

export const useComposeGeneralDescription = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      context 
    }: { 
      draftId: string; 
      context?: string;
    }) => {
      // Generate a general description for the deviation
      const data: GenerateDeviationRequest = {
        prompt: 'Compose a general description for this deviation',
        context: context,
      };
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

export const useComposeImpactAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      context,
      impactData 
    }: { 
      draftId: string; 
      context?: string;
      impactData?: any;
    }) => {
      // Generate an impact analysis for the deviation
      const data: GenerateDeviationRequest = {
        prompt: 'Compose an impact analysis for this deviation',
        context: context,
        metadata: {
          impactData,
          analysisType: 'impact'
        }
      };
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

export const useComposeRiskAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      context,
      riskData 
    }: { 
      draftId: string; 
      context?: string;
      riskData?: {
        severity?: string;
        likelihood?: string;
        category?: string;
      };
    }) => {
      // Generate a risk analysis for the deviation
      const data: GenerateDeviationRequest = {
        prompt: 'Compose a risk analysis for this deviation',
        context: context,
        metadata: {
          riskData,
          analysisType: 'risk'
        }
      };
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

export const useComposeRootCauseAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      context,
      rootCauseData 
    }: { 
      draftId: string; 
      context?: string;
      rootCauseData?: {
        method?: string; // e.g., '5-whys', 'fishbone', 'fault-tree'
        findings?: string[];
        primaryCause?: string;
      };
    }) => {
      // Generate a root cause analysis for the deviation
      const data: GenerateDeviationRequest = {
        prompt: 'Compose a root cause analysis for this deviation',
        context: context,
        metadata: {
          rootCauseData,
          analysisType: 'root-cause'
        }
      };
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

export const useReGenerateDeviation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draft_deviation_id, 
      evidences, 
      removed_evidences 
    }: { 
      draft_deviation_id: string; 
      evidences: FileEvidence[]; 
      removed_evidences: FileEvidence[] 
    }) => {
      // You'll need to add a method to handle this in DeviationManagerService
      // or adapt the existing generateDraftDeviation to accept this payload
      const data: GenerateDeviationRequest = {
        metadata: {
          evidences,
          removed_evidences
        }
      };
      return await deviationService.generateDraftDeviation(draft_deviation_id, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draft_deviation_id] });
    },
  });
};

// Combined mutation for create and generate workflow
export const useCreateAndGenerateDeviationMutation = () => {
  const deviationService = useDeviationManagerService();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: GenerateDeviationRequest) => {
      // First create a draft
      const draft = await deviationService.createDraftDeviation({
        title: 'New Deviation',
        description: data.prompt || 'Generated deviation',
        status: 'draft',
        category: 'general',
        severity: 'medium'
      });
      
      // Then generate content for it
      const generated = await deviationService.generateDraftDeviation(draft.id, data);
      
      return generated;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
    },
  });
};

// Add this new mutation for exporting draft deviations
export const useExportDraftDeviation = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async (id: string) => {
      // You'll need to add an export method to DeviationManagerService
      // For now, this returns the deviation data that can be exported
      return await deviationService.getDraftDeviation(id);
    },
    onSuccess: (data) => {
      // Handle export logic - download as file, copy to clipboard, etc.
      const jsonData = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonData], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `deviation-${data.id}.json`;
      link.click();
      URL.revokeObjectURL(url);
    },
  });
};

// Add this for deviation form submission
export const useSubmitDeviationForm = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async (formData: {
      id: string;
      data: Partial<DraftDeviation>;
    }) => {
      // First update the deviation with form data
      const updated = await deviationService.updateDraftDeviation(formData.id, formData.data);
      // Then submit it
      return await deviationService.submitDraftDeviation(formData.id);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.id] });
    },
  });
};

// Add this mutation for composing short descriptions
export const useComposeShortDescription = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      context,
      descriptionData 
    }: { 
      draftId: string; 
      context?: string;
      descriptionData?: {
        maxLength?: number;
        focus?: string;
      };
    }) => {
      // Generate a short description for the deviation
      const data: GenerateDeviationRequest = {
        prompt: 'Compose a short description for this deviation',
        context: context,
        metadata: {
          descriptionData,
          analysisType: 'short-description',
          maxLength: descriptionData?.maxLength || 200
        }
      };
      return await deviationService.generateDraftDeviation(draftId, data);
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

// Add this mutation for deleting evidence
export const useDeleteEvidence = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      deviationId, 
      evidenceId 
    }: { 
      deviationId: string; 
      evidenceId: string;
    }) => {
      // You'll need to add a deleteEvidence method to DeviationManagerService
      // For now, update the deviation to remove the evidence
      const deviation = await deviationService.getDraftDeviation(deviationId);
      const updatedEvidences = ((deviation.metadata?.evidences || []) as FileEvidence[])
        .filter((evidence: FileEvidence) => evidence.id !== evidenceId);
      
      return await deviationService.updateDraftDeviation(deviationId, {
        metadata: {
          ...deviation.metadata,
          evidences: updatedEvidences
        }
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.deviationId] });
    },
  });
};

// Add update mutation for short description
export const useUpdateShortDescription = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      shortDescription 
    }: { 
      draftId: string; 
      shortDescription: string;
    }) => {
      return await deviationService.updateDraftDeviation(draftId, {
        metadata: {
          shortDescription
        }
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

// Add update mutation for general description
export const useUpdateGeneralDescription = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      generalDescription 
    }: { 
      draftId: string; 
      generalDescription: string;
    }) => {
      return await deviationService.updateDraftDeviation(draftId, {
        description: generalDescription
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

// Add update mutation for impact analysis
export const useUpdateImpactAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      impactAnalysis 
    }: { 
      draftId: string; 
      impactAnalysis: string | {
        description: string;
        severity: string;
        affectedAreas: string[];
      };
    }) => {
      return await deviationService.updateDraftDeviation(draftId, {
        metadata: {
          impactAnalysis
        }
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

// Add update mutation for root cause analysis
export const useUpdateRootCauseAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      rootCauseAnalysis 
    }: { 
      draftId: string; 
      rootCauseAnalysis: string | {
        description: string;
        method: string;
        findings: string[];
        primaryCause: string;
      };
    }) => {
      return await deviationService.updateDraftDeviation(draftId, {
        metadata: {
          rootCauseAnalysis
        }
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};

// Add update mutation for risk analysis
export const useUpdateRiskAnalysis = () => {
  const queryClient = useQueryClient();
  const deviationService = useDeviationManagerService();

  return useMutation({
    mutationFn: async ({ 
      draftId, 
      riskAnalysis 
    }: { 
      draftId: string; 
      riskAnalysis: string | {
        description: string;
        severity: string;
        likelihood: string;
        riskLevel: string;
        mitigationMeasures: string[];
      };
    }) => {
      return await deviationService.updateDraftDeviation(draftId, {
        metadata: {
          riskAnalysis
        }
      });
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviations] });
      queryClient.invalidateQueries({ queryKey: [QueryKeys.draftDeviation, variables.draftId] });
    },
  });
};