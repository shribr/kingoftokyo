import { useInfiniteQuery, useQuery } from "@tanstack/react-query";
import { useDeviationManagerService } from '~/features/deviation-manager/hooks/useDeviationManagerService';
import { QUERY_KEYS } from "~/features/shared/constants/queryKeys";
import { DeviationManagerQuestion } from "../services/DeviationManagerService";

export const useDeviationQuestions = () => {
  const deviationService = useDeviationManagerService();

  return useQuery<DeviationManagerQuestion[]>({
    queryKey: [QUERY_KEYS.DEVIATION_QUESTIONS],
    queryFn: () => deviationService.service.getDeviationQuestions(),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useSupportingDocuments = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DRAFT_DEVIATION_EVIDENCE, deviation_id],
    queryFn: async () => {
      if (!deviation_id) {
        return [];
      }

      // Return empty array since Deviation interface doesn't have formData
      try {
        await deviationService.service.getDraftDeviation(deviation_id);
        return [];
      } catch (error) {
        console.error('Error fetching supporting documents:', error);
        return [];
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
};

export const useDraftDeviation = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DRAFT_DEVIATION, deviation_id],
    queryFn: () => deviationService.service.getDraftDeviation(deviation_id),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
};

export const useDraftDeviationList = ({skip = 0, limit = 100000}: {skip?: number, limit?: number} = {}) => {
  const deviationService = useDeviationManagerService();
  return useQuery({
    queryKey: [QUERY_KEYS.DRAFT_DEVIATION_LIST, skip, limit],
    queryFn: () => deviationService.service.getDraftDeviations({offset: skip, limit}),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false
  });
}

export const usePagedDraftDeviationList = ({ 
  pageSize = 30, 
  enabled = true 
}: { 
  pageSize?: number;
  enabled?: boolean;
} = {}) => {
  const deviationService = useDeviationManagerService();
  const query = useInfiniteQuery<
    { data: any[]; nextSkip: number },
    Error,
    { data: any[]; nextSkip: number },
    (string | number)[]
  >({
    queryKey: ['draft-deviation-paged', pageSize],
    queryFn: async ({ pageParam = 0 }) => {
      const data = await deviationService.service.getDraftDeviations({
        offset: pageParam as number,
        limit: pageSize,
      });

      return {
        data,
        nextSkip: (pageParam as number) + pageSize,
      };
    },
    getNextPageParam: (lastPage) => {
      return lastPage.data.length === pageSize ? lastPage.nextSkip : undefined;
    },
    enabled,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });

  return {
    ...query,
    items: query.data?.pages.flatMap((page: any) => page.data) ?? [],
    refetch: query.refetch,
  };
};

export const useRelevantDeviation = (text: string, start_date: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.RELEVANT_DEVIATION, text, start_date],
    queryFn: () => deviationService.service.searchRelevantDeviations({
      query: text,
    }),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!text && !!start_date,
  });
}

export const useRelevantDeviationsSearch = (searchParams: { text: string; start_date: string; limit?: number }, enabled: boolean = true) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.RELEVANT_DEVIATION_SEARCH, searchParams.text, searchParams.start_date, searchParams.limit],
    queryFn: () => deviationService.service.searchRelevantDeviationsEndpoint(searchParams),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: enabled && !!searchParams.text && !!searchParams.start_date,
  });
};

export const useDeviationShortDescription = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DEVIATION_SHORT_DESCRIPTION, deviation_id],
    queryFn: async () => {
      if (!deviation_id) return null;
      try {
        const deviation = await deviationService.service.getDraftDeviation(deviation_id);
        return deviation?.description || null;
      } catch (error) {
        console.error('Error fetching deviation short description:', error);
        return null;
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
}

export const useDeviationGeneralDescription = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DEVIATION_GENERAL_DESCRIPTION, deviation_id],
    queryFn: async () => {
      if (!deviation_id) return null;
      try {
        const deviation = await deviationService.service.getDraftDeviation(deviation_id);
        return deviation?.description || null;
      } catch (error) {
        console.error('Error fetching deviation general description:', error);
        return null;
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
}

export const useDeviationImpactAnalysis = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DEVIATION_IMPACT_ANALYSIS, deviation_id],
    queryFn: async () => {
      if (!deviation_id) return null;
      try {
        const deviation = await deviationService.service.getDraftDeviation(deviation_id);
        return deviation?.severity || null;
      } catch (error) {
        console.error('Error fetching deviation impact analysis:', error);
        return null;
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
};

export const useDeviationRootCauseAnalysis = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DEVIATION_ROOT_CAUSE_ANALYSIS, deviation_id],
    queryFn: async () => {
      if (!deviation_id) return null;
      try {
        const deviation = await deviationService.service.getDraftDeviation(deviation_id);
        return deviation?.category || null;
      } catch (error) {
        console.error('Error fetching deviation root cause analysis:', error);
        return null;
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
}

export const useDeviationRiskAnalysis = (deviation_id: string) => {
  const deviationService = useDeviationManagerService();

  return useQuery({
    queryKey: [QUERY_KEYS.DEVIATION_RISK_ANALYSIS, deviation_id],
    queryFn: async () => {
      if (!deviation_id) return null;
      try {
        const deviation = await deviationService.service.getDraftDeviation(deviation_id);
        if (!deviation?.severity && !deviation?.status) return null;
        return { severity: deviation?.severity, status: deviation?.status };
      } catch (error) {
        console.error('Error fetching deviation risk analysis:', error);
        return null;
      }
    },
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!deviation_id,
  });
};