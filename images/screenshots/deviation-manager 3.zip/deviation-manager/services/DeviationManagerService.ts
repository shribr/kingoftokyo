import { request } from 'librechat-data-provider';
import { AxiosResponse } from 'axios';
import * as data from '../components/utils/data';

// Import helper functions from dataHelper
import {
  pick,
  randomInt,
  randomPercent,
  generateKpiData,
  generateDeviationRecords,
  filterDeviationData,
  paginateData,
  getTotalPages,
  convertDeviationRecordToDeviationData,
  searchTrackwiseRecords as searchTrackwiseRecordsFromHelper,
  generateStatusChartData,
  generateSiteChartData,
  generateTrendChartData,
  DEVIATION_RECORDS_SAMPLE
} from '../components/utils/dataHelper';

// Import configuration and adapters
import { defaultDashboardConfig } from '../components/config/defaultConfig';
import type { DashboardConfig } from '../components/config/types';
import { DataSourceManager } from '../components/adapters/DataSourceManager';

// Import types
import type { 
  DeviationData,
  RelevantDeviationsSearchResponse, 
  RelevantDeviationsSearchRequest, 
  TrackwiseSearchRequest, 
  DeviationRecord, 
  TrackwiseRecord, 
  TrackwiseSearchResponse 
} from '../components/utils/data';

// ====================================================================
// CONFIGURATION & CONSTANTS
// ====================================================================

const DEVIATION_MANAGER_API_BASE = '/api/deviation-manager';
const DEVIATIONS_API_PATH = `${DEVIATION_MANAGER_API_BASE}/api/deviations`;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

let USE_LIVE_DATA = true;
let lastFetchTime: number = 0;
let dataSourceManager: DataSourceManager | null = null;

// Simple logger implementation
const logger = {
  debug: (message: string, ...args: any[]) => console.log('[DEBUG]', message, ...args),
  error: (message: string, ...args: any[]) => console.error('[ERROR]', message, ...args),
  info: (message: string, ...args: any[]) => console.info('[INFO]', message, ...args),
  warn: (message: string, ...args: any[]) => console.warn('[WARN]', message, ...args)
};

export let cachedDeviationRecords: DeviationRecord[] | null = null;

// DEVIATION MANAGER SERVICE CLASS
// ====================================================================


class DeviationManagerService {
  public azureApiBaseUrl?: string;

  constructor(azureApiBaseUrl?: string) {
    logger.info('Initializing DeviationManagerService in proxy mode');
    this.azureApiBaseUrl = azureApiBaseUrl;
  }

  async healthCheck(): Promise<HealthCheckResponse> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/health`) as HealthCheckResponse;
      return response;
    } catch (error: any) {
      logger.error('Health check failed:', error);
      return {
        status: 'error',
        message: error.message || 'Health check failed',
        configured: false
      };
    }
  }

  async getDraftDeviations(params?: { limit?: number; offset?: number }): Promise<Deviation[]> {
    try {
      const response = await request.get(DEVIATIONS_API_PATH, { params }) as Deviation[];
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Get draft deviations failed:', error);
      throw error;
    }
  }

  async getDraftDeviation(id: string): Promise<Deviation> {
    try {
      const response = await request.get(`${DEVIATIONS_API_PATH}/${id}`) as Deviation;
      return response;
    } catch (error: any) {
      logger.error(`DeviationManagerService: Get draft deviation ${id} failed:`, error);
      throw error;
    }
  }

  async createDraftDeviation(data: Partial<Deviation>): Promise<Deviation> {
    try {
      const response = await request.post(DEVIATIONS_API_PATH, data) as Deviation;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Create draft deviation failed:', error);
      throw error;
    }
  }

  async searchRelevantDeviations(searchRequest: SearchRequest): Promise<Deviation[]> {
    try {
      const response = await request.post(`${DEVIATIONS_API_PATH}/search`, searchRequest) as Deviation[];
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Search relevant deviations failed:', error);
      throw error;
    }
  }

  async getDeviationQuestions(): Promise<DeviationManagerQuestion[]> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/api/questions`) as DeviationManagerQuestion[];
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Get deviation questions failed:', error);
      throw error;
    }
  }

  async generateDraftDeviation(draftId: string, data: GenerateDeviationRequest): Promise<DraftDeviation> {
    try {
      const response = await request.post(`${DEVIATIONS_API_PATH}/${draftId}/generate`, data) as DraftDeviation;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Generate draft deviation failed:', error);
      throw error;
    }
  }

  async updateDraftDeviation(id: string, updates: Partial<DraftDeviation>): Promise<DraftDeviation> {
    try {
      const response = await request.put(`${DEVIATIONS_API_PATH}/${id}`, updates) as DraftDeviation;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Update draft deviation failed:', error);
      throw error;
    }
  }

  async deleteDraftDeviation(id: string): Promise<void> {
    try {
      await request.delete(`${DEVIATIONS_API_PATH}/${id}`);
    } catch (error: any) {
      logger.error('DeviationManagerService: Delete draft deviation failed:', error);
      throw error;
    }
  }

  async submitDraftDeviation(id: string): Promise<DraftDeviation> {
    try {
      const response = await request.post(`${DEVIATIONS_API_PATH}/${id}/submit`) as DraftDeviation;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Submit draft deviation failed:', error);
      throw error;
    }
  }

  async getBanner(): Promise<any> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/api/banner`) as any;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Get banner failed:', error);
      throw error;
    }
  }

  async getConfig(): Promise<any> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/api/config`) as any;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Get config failed:', error);
      throw error;
    }
  }

  async debugCredentials(): Promise<DebugCredentialsResponse> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/debug/credentials`) as any;
      return {
        hasApiKey: response.hasApiKey || false,
        apiKeyPreview: response.apiKeyPreview,
        apiKeyLength: response.apiKeyLength,
        baseURL: response.baseURL,
        lastUpdated: response.lastUpdated
      };
    } catch (error) {
      logger.warn('Debug credentials endpoint not available, making inference from health check');
      
      try {
        const healthResponse = await this.healthCheck();
        return {
          hasApiKey: healthResponse.configured,
          baseURL: healthResponse.baseURL
        };
      } catch (healthError) {
        return {
          hasApiKey: false
        };
      }
    }
  }

  async getDraftDeviationList(params?: { skip?: number; limit?: number }): Promise<any[]> {
    try {
      const queryParams = {
        offset: params?.skip || 0,
        limit: params?.limit || 10
      };

      const response = await request.get(DEVIATIONS_API_PATH, { params: queryParams });
      return Array.isArray(response) ? response : [];
    } catch (error: any) {
      logger.error('DeviationManagerService: Get draft deviation list failed:', error);
      throw error;
    }
  }

  async searchRelevantDeviationsEndpoint(searchRequest: RelevantDeviationSearchRequest): Promise<RelevantDeviationSearchResponse> {
    try {
      const response = await request.post(`${DEVIATIONS_API_PATH}/relevant-deviations/search`, searchRequest) as RelevantDeviationSearchResponse;
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Search relevant deviations endpoint failed:', error);
      throw error;
    }
  }
}

//const deviationManagerService = new DeviationManagerService();

// Initialize the service instance immediately
const createServiceInstance = (): DeviationManagerService => {
  // Create service without URL initially - will be set from React hook
  const service = new DeviationManagerService();
  console.warn('DeviationManagerService created without URL. Will be initialized from useGetStartupConfig.');
  return service;
};

let deviationManagerService: DeviationManagerService = createServiceInstance();

// ====================================================================

// TYPES & INTERFACES
// ====================================================================

export interface Deviation {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, any>;
}

export interface DraftDeviation {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
  content?: string;
  metadata?: Record<string, any>;
}

export interface FileEvidence {
  id?: string;
  filename: string;
  url?: string;
  size?: number;
  mimeType?: string;
  uploadedAt?: string;
  uploadedBy?: string;
  description?: string;
}

export interface GenerateDeviationRequest {
  prompt?: string;
  context?: string;
  template?: string;
  metadata?: Record<string, any>;
}

export interface SearchRequest {
  query: string;
  category?: string;
  severity?: string;
  status?: string;
  limit?: number;
  offset?: number;
}

export interface HealthCheckResponse {
  status: 'ok' | 'error';
  message: string;
  configured: boolean;
  baseURL?: string;
}

export interface DebugCredentialsResponse {
  hasApiKey: boolean;
  apiKeyPreview?: string;
  apiKeyLength?: number;
  baseURL?: string;
  lastUpdated?: string;
}

export enum ControlType {
  TEXTBOX = 'textbox',
  DROPDOWN = 'dropdown',
  DATE = 'date',
  TIME = 'time',
  TEXTAREA = 'textarea'
}

export interface DeviationManagerQuestion {
  id: number;
  label: string;
  controlType: ControlType;
  options?: { label: string; value: string | number }[];
  cssClass?: string;
  placeHolder?: string;
  value?: string;
  isDirty?: boolean;
}

export interface RelevantDeviationSearchRequest {
  text: string;
  start_date: string;
  limit?: number;
}

export interface RelevantDeviationSearchResponse {
  deviations: Deviation[];
  total?: number;
}

// ====================================================================
// DATA SOURCE MANAGEMENT
// ====================================================================

export const getDashboardConfig = (): DashboardConfig => {
  return dataSourceManager?.getConfig() || defaultDashboardConfig;
};

export const ensureDataSourceInitialized = async (): Promise<DataSourceManager> => {
  if (!dataSourceManager) {
    await configureDashboardData(defaultDashboardConfig);
  }
  return dataSourceManager!;
};

export const configureDashboardData = (config: DashboardConfig): Promise<boolean> => {
  dataSourceManager = new DataSourceManager(config);
  return dataSourceManager.initialize();
};

export const checkDataSourceHealth = async () => {
  if (!dataSourceManager) {
    return { connected: false, health: null };
  }
  
  const health = await dataSourceManager.healthCheck();
  return { 
    connected: dataSourceManager.isConnected(), 
    health 
  };
};

export const switchDataSource = async (config: DashboardConfig): Promise<boolean> => {
  try {
    if (dataSourceManager) {
      await dataSourceManager.disconnect();
    }
    return await configureDashboardData(config);
  } catch (error) {
    console.error('Failed to switch data source:', error);
    return false;
  }
};

// ====================================================================
// DATA FETCHING FUNCTIONS
// ====================================================================

export const fetchDeviationsData = async (filters?: any, pagination?: any) => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchDeviations(filters, pagination);
};

export const fetchKpisData = async () => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchKpis();
};

export const fetchChartData = async (chartType: string) => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchChartData(chartType);
};

// ====================================================================
// API CONNECTION & HEALTH CHECKS
// ====================================================================

export const checkApiConnection = async (): Promise<{
  isAvailable: boolean;
  error?: string;
  responseTime?: number;
  status?: number;
  statusText?: string;
}> => {
  const startTime = Date.now();
  
  try {
    if (!deviationManagerService.azureApiBaseUrl) {
      return {
        isAvailable: false,
        error: 'DeviationManagerService not initialized with azureApiBaseUrl',
        responseTime: Date.now() - startTime
      };
    }
    const apiBaseUrl = deviationManagerService.azureApiBaseUrl;
    const apiUrl = `${apiBaseUrl}/api/deviations`;
    const response = await request.getResponse<AxiosResponse<any>>(apiUrl);
    const responseTime = Date.now() - startTime;
    
    const isSuccessful = response.status >= 200 && response.status < 300;
    
    return {
      isAvailable: isSuccessful,
      responseTime,
      status: response.status,
      statusText: response.statusText,
      ...(isSuccessful ? {} : { error: `HTTP ${response.status}: ${response.statusText}` })
    };
  } catch (error) {
    return {
      isAvailable: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: Date.now() - startTime
    };
  }
};

const checkApiConnectionWithUrl = async (baseUrl: string): Promise<{
  isAvailable: boolean;
  error?: string;
  responseTime?: number;
  status?: number;
  statusText?: string;
}> => {
  const startTime = Date.now();
  
  try {
    const apiUrl = `${baseUrl}/api/deviations`;
    const response = await request.getResponse<AxiosResponse<any>>(apiUrl);
    const responseTime = Date.now() - startTime;
    
    const isSuccessful = response.status >= 200 && response.status < 300;
    
    return {
      isAvailable: isSuccessful,
      responseTime,
      status: response.status,
      statusText: response.statusText,
      ...(isSuccessful ? {} : { error: `HTTP ${response.status}: ${response.statusText}` })
    };
  } catch (error) {
    return {
      isAvailable: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: Date.now() - startTime
    };
  }
};

export const checkRelevantDeviationsSearchConnection = async (): Promise<{
  isAvailable: boolean;
  error?: string;
  responseTime?: number;
  status?: number;
  statusText?: string;
}> => {
  const startTime = Date.now();
  
  try {
    const requestParams: RelevantDeviationsSearchRequest = {
      text: 'test',
      start_date: new Date().toISOString().split('T')[0],
      limit: 1
    };

    const apiUrl = `${deviationManagerService.azureApiBaseUrl}/relevant-deviations/search`;
    const response = await request.getResponse<AxiosResponse<any>>(apiUrl, {
      method: 'POST',
      data: requestParams
    });
    
    const responseTime = Date.now() - startTime;
    const isSuccessful = response.status >= 200 && response.status < 300;
    
    return {
      isAvailable: isSuccessful,
      responseTime,
      status: response.status,
      statusText: response.statusText,
      ...(isSuccessful ? {} : { error: `HTTP ${response.status}: ${response.statusText}` })
    };
  } catch (error) {
    return {
      isAvailable: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: Date.now() - startTime
    };
  }
};

export const checkTrackwiseSearchConnection = async (): Promise<{
  isAvailable: boolean;
  error?: string;
  responseTime?: number;
}> => {
  const startTime = Date.now();
  
  try {
    const requestParams: TrackwiseSearchRequest = {
      text: 'test',
      start_date: new Date().toISOString().split('T')[0],
      limit: 1
    };

    await request.post(`${deviationManagerService.azureApiBaseUrl}/relevant-deviations/search`, requestParams);
    const responseTime = Date.now() - startTime;
    
    return {
      isAvailable: true,
      responseTime
    };
  } catch (error) {
    return {
      isAvailable: false,
      error: error instanceof Error ? error.message : 'Unknown error',
      responseTime: Date.now() - startTime
    };
  }
};

// ====================================================================
// SEARCH FUNCTIONS
// ====================================================================

export const searchRelevantDeviations = async (
  searchText: string,
  startDate?: string,
  limit: number = 10
): Promise<RelevantDeviationsSearchResponse[]> => {
  try {
    const isApiAvailable = await checkApiConnection().then(res => res.isAvailable);
    
    if (!isApiAvailable) {
      console.warn(`API endpoint ${deviationManagerService.azureApiBaseUrl}/relevant-deviations/search is not available - returning empty results`);
      return [];
    }

    const requestParams: RelevantDeviationsSearchRequest = {
      text: searchText,
      start_date: startDate || new Date(Date.now() - 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      limit: Math.max(1, Math.min(limit, 100))
    };

    console.log('Searching relevant deviations with params:', requestParams);

    const apiUrl = `${deviationManagerService.azureApiBaseUrl}/relevant-deviations/search`;
    const response = await request.post(apiUrl, requestParams) as RelevantDeviationsSearchResponse[];

    if (!Array.isArray(response)) {
      console.warn('API response is not an array:', typeof response, response);
      return [];
    }

    console.log(`Found ${response.length} relevant deviations for search: "${searchText}"`);
    
    if (response.length > 0) {
      console.log('Sample search result:', response[0]);
    }

    return response;
  } catch (error) {
    console.error('Error searching relevant deviations:', error);
    
    if (error instanceof SyntaxError && error.message.includes('Unexpected token')) {
      console.error('API returned HTML instead of JSON - search endpoint may not exist or may be returning an error page');
    }
    
    console.warn('Returning empty results due to API error');
    return [];
  }
};

export const searchTrackwiseRecordsUpdated = async (
  searchText: string = '',
  startDate?: string,
  limit: number = 10
): Promise<TrackwiseRecord[]> => {
  if (!searchText.trim()) {
    return [];
  }

  try {
    const searchResults = await searchRelevantDeviations(searchText, startDate, limit);
    
    if (searchResults.length > 0) {
      return convertRelevantDeviationsToTrackwiseRecords(searchResults);
    }
    
    console.log('No results from API search, falling back to local records');
    return searchTrackwiseRecordsFromHelper(searchText, startDate, limit);
    
  } catch (error) {
    console.error('Error in searchTrackwiseRecordsUpdated:', error);
    console.warn('Falling back to helper function search due to error');
    return searchTrackwiseRecordsFromHelper(searchText, startDate, limit);
  }
};

// ====================================================================
// DATA CONVERSION FUNCTIONS
// ====================================================================

export const convertRelevantDeviationsToTrackwiseRecords = (searchResults: RelevantDeviationsSearchResponse[]): TrackwiseRecord[] => {
  return searchResults.map((item, index) => ({
    id: item.id || `RD-${Date.now()}-${index}`,
    name: item.title || 'Unknown Record',
    description: item.description || 'No description available',
    classification: item.deviation_type || 'Unknown',
    createdOn: item.created_date || new Date().toISOString().split('T')[0],
    createdBy: 'System User',
    department: item.department || pick(data.DEPT_OPTIONS.filter(d => d !== 'All')),
    
    deviationName: item.title || 'Unknown Deviation',
    potentialImpact: 'To be determined based on investigation',
    whatDefectObserved: item.description || 'Description from search result',
    objectDefectObserved: 'Object to be determined',
    specifications: 'Specifications to be documented',
    issueOccurred: item.site || 'Location to be determined',
    timeOfOccurrence: '00:00',
    actualDefectOccurrence: item.created_date || new Date().toISOString().split('T')[0],
    dateDefectDiscovered: item.created_date || new Date().toISOString().split('T')[0],
    dateReported: item.created_date || new Date().toISOString().split('T')[0],
    detectionMethods: 'Detection methods to be documented',
    personWhoObserved: 'Observer to be identified',
    personWhoReported: item.assignee || 'Reporter to be identified',
    immediateAction: 'Immediate actions to be documented',
    backgroundInformation: item.description || 'Background information from search result',
    attachmentsDescription: 'Supporting documents to be attached',
    additionalComments: `Found via relevant deviations search with similarity score: ${item.similarity_score?.toFixed(2) || 'N/A'}`,
    finalAnalysis: 'Analysis to be completed during investigation'
  }));
};

const convertApiResponseToDeviationRecord = (apiResponse: any): DeviationRecord[] => {
  if (!apiResponse) {
    console.warn('API response is null or undefined');
    return [];
  }

  if (typeof apiResponse === 'object' && !Array.isArray(apiResponse)) {
    if (Array.isArray(apiResponse.data)) {
      apiResponse = apiResponse.data;
    } else if (Array.isArray(apiResponse.results)) {
      apiResponse = apiResponse.results;
    } else if (Array.isArray(apiResponse.items)) {
      apiResponse = apiResponse.items;
    } else {
      console.warn('API response is not an array and does not contain expected array properties:', apiResponse);
      return [];
    }
  }

  if (!Array.isArray(apiResponse)) {
    console.warn('API response is not an array after processing:', typeof apiResponse, apiResponse);
    return [];
  }

  return apiResponse.map((item, index) => ({
    id: item.id || `API-${Date.now()}-${index}`,
    trackwiseId: `TW-${new Date().getFullYear()}-${String(index + 1).padStart(4, '0')}`,
    formData: {
      deviationName: item.title || 'Unknown Deviation',
      site: item.site || pick(data.SITE_OPTIONS),
      department: item.department || pick(data.DEPT_OPTIONS.filter(d => d !== 'All')),
      assignee: item.assignee || `${pick(data.LAST_NAMES)}, ${pick(data.FIRST_NAMES)}`,
      createdOn: item.created_date || new Date().toISOString().split('T')[0],
      stage: item.stage || item.deviation_type || pick(data.STAGES),
      selectedTrackwiseRecord: null,
      step1: {
        trackwiseSearchQuery: '',
        whatDefectObserved: item.description || 'Description from API',
        objectDefectObserved: 'Object to be determined',
        wantSpecifications: 'Specifications to be determined',
        issueOccurred: 'Location to be determined',
        dateOccurrence: item.created_date || new Date().toISOString().split('T')[0],
        timeOccurrence: '00:00',
        dateDetection: item.created_date || new Date().toISOString().split('T')[0],
        impactOfIssue: 'Impact to be assessed',
        processStepDefect: 'Process step to be identified',
        whoInvolvedProcess: 'Personnel to be identified',
        whoObservedIssue: 'Observer to be identified',
        processDescription: item.description || 'Process description from API',
        immediateActions: 'Immediate actions to be documented',
        materialsToolsEquipment: 'Materials/tools to be listed',
        supportingDocuments: []
      },
      step2: {
        riskQuestion1: '',
        riskQuestion2: '',
        riskQuestion3: '',
        riskQuestion4: '',
        severityLevel: '',
        severityDetails: '',
        detectionLevel: '',
        detectionDetails: '',
        occurrenceLevel: '',
        occurrenceDetails: '',
        rpnScore: '',
        localClassification: '',
        teamCommitteeAgreement: ''
      },
      step3: {
        investigationPlan: '',
        rootCauseAnalysis: '',
        contributingFactors: []
      },
      step4: {
        correctiveActions: '',
        preventiveActions: '',
        effectiveness: '',
        conclusion: ''
      }
    }
  }));
};

const fetchLiveDeviationData = async (azureApiBaseUrl?: string): Promise<DeviationRecord[]> => {
  const baseUrl = azureApiBaseUrl || deviationManagerService.azureApiBaseUrl;
  
  if (!baseUrl) {
    console.warn('No azureApiBaseUrl provided - falling back to sample data');
    return [...DEVIATION_RECORDS_SAMPLE];
  }
  const apiUrl = `${baseUrl}/api/deviations`;
  
  try {
    const isApiAvailable = await checkApiConnectionWithUrl(baseUrl).then(res => res.isAvailable);
    if (!isApiAvailable) {
      console.warn(`API endpoint ${baseUrl}/api/deviations is not available - falling back to sample data`);
      return [...DEVIATION_RECORDS_SAMPLE];
    }

    const response = await request.getResponse<AxiosResponse<any>>(apiUrl);

    if (!response || response.status < 200 || response.status >= 300) {
      throw new Error(`HTTP error! status: ${response?.status || 'unknown'}, message: ${response?.statusText || 'unknown error'}`);
    }

    const contentType = typeof response.headers.get === 'function' 
      ? response.headers.get('content-type') 
      : response.headers['content-type'];
    if (!contentType || !contentType.includes('application/json')) {
      throw new Error(`Expected JSON response but received: ${contentType}`);
    }

    const apiData = response.data;
    const convertedData = convertApiResponseToDeviationRecord(apiData);

    console.log('=== CONVERTED LIVE DATA ===');
    console.log('Number of records converted:', convertedData.length);
    console.log('=== END CONVERTED DATA ===');

    return convertedData;
  } catch (error) {
    console.error('Error fetching live deviation data:', error);
    
    if (error instanceof SyntaxError && error.message.includes('Unexpected token')) {
      console.error('API returned HTML instead of JSON - endpoint may not exist or may be returning an error page');
    }
    
    console.warn('Falling back to sample data due to API error');
    return [...DEVIATION_RECORDS_SAMPLE];
  }
};

// ====================================================================
// UTILITY FUNCTIONS
// ====================================================================

export const generateWelcomeName = (): string => {
  return pick(data.FIRST_NAMES);
};

export const getAzureApiBaseUrl = (): string | undefined => {
  return deviationManagerService.azureApiBaseUrl;
};

// ====================================================================

// ====================================================================
// SERVICE INITIALIZATION
// ====================================================================

export const initializeDeviationManagerService = (azureApiBaseUrl: string): DeviationManagerService => {
  console.log('Initializing DeviationManagerService with URL:', azureApiBaseUrl);
  
  if (deviationManagerService?.azureApiBaseUrl === azureApiBaseUrl) {
    console.log('Service already initialized with this URL');
    return deviationManagerService;
  }
  
  // Store in localStorage for persistence
  localStorage.setItem('azureApiBaseUrl', azureApiBaseUrl);
  
  // Create new instance with the URL
  deviationManagerService = new DeviationManagerService(azureApiBaseUrl);
  
  console.log('Service initialized successfully with azureApiBaseUrl:', deviationManagerService.azureApiBaseUrl);
  return deviationManagerService;
};

// ====================================================================
// STANDALONE FUNCTIONS (using global service instance)
// ====================================================================

export const getDeviationRecords = async (forceRefresh: boolean = false): Promise<DeviationRecord[]> => {
  const now = Date.now();
  const isCacheValid = cachedDeviationRecords && (now - lastFetchTime) < CACHE_DURATION;

  if (!forceRefresh && isCacheValid) {
    return cachedDeviationRecords!;
  }

  if (USE_LIVE_DATA) {
    const liveData = await fetchLiveDeviationData();
    cachedDeviationRecords = liveData;
    lastFetchTime = now;
    return liveData;
  } else {
    const sampleData = [...DEVIATION_RECORDS_SAMPLE];
    cachedDeviationRecords = sampleData;
    lastFetchTime = now;
    return sampleData;
  }
};

export const refreshDeviationRecords = async (): Promise<DeviationRecord[]> => {
  return getDeviationRecords(true);
};

export const searchDeviations = async (searchTerm: string = ''): Promise<DeviationRecord[]> => {
  const records = await getDeviationRecords();
  
  if (!searchTerm.trim()) {
    return records;
  }
  
  const filteredRecords = records.filter(record => {
    const searchableText = [
      record.formData.deviationName,
      record.formData.site,
      record.formData.department,
      record.formData.assignee,
      record.formData.stage,
      record.formData.step1.whatDefectObserved,
      record.trackwiseId
    ].join(' ').toLowerCase();
    
    return searchableText.includes(searchTerm.toLowerCase());
  });
  
  return filteredRecords;
};

// ====================================================================
// EXPORTS FOR BACKWARD COMPATIBILITY
// ====================================================================

export {
  generateKpiData,
  generateDeviationRecords,
  filterDeviationData,
  paginateData,
  getTotalPages,
  convertDeviationRecordToDeviationData,
  generateStatusChartData as generateStatusDistributionData,
  generateSiteChartData as generateSiteDistributionData,
  generateTrendChartData as generateTrendData
};

export default deviationManagerService;
export { DeviationManagerService };