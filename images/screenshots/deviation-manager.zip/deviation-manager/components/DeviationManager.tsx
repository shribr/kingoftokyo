import React, { useState, createContext, useContext } from 'react';
import DeviationManagerDashboard from './DeviationManagerDashboard';
import DeviationForm from '~/features/deviation-manager/components/DeviationForm/DeviationForm';
import Deviations from '~/features/deviation-manager/components/Deviations';
import TrendReports from '~/features/deviation-manager/components/TrendReports';
import { ToastProvider } from '~/Providers';
import Header from './layout/Header';
import { DeviationFormProvider } from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';

export const DASHBOARD_VIEW = 'dashboard';
export const DEVIATION_FORM_VIEW = 'deviation_form_view';
export const DEVIATIONS_VIEW = 'deviations_view';
export const TREND_REPORTS_VIEW = 'trend_reports';
export type DeviationManagerViewMode = typeof DASHBOARD_VIEW | typeof DEVIATION_FORM_VIEW | typeof DEVIATIONS_VIEW | typeof TREND_REPORTS_VIEW;

// Context setup
interface DeviationManagerContextType {
  currentView: DeviationManagerViewMode;
  setCurrentView: React.Dispatch<React.SetStateAction<DeviationManagerViewMode>>;
}
export const DeviationManagerContext = createContext<DeviationManagerContextType | undefined>(undefined);
export const useDeviationManagerContext = (): DeviationManagerContextType => {
  const context = useContext(DeviationManagerContext);
  if (!context) {
    throw new Error('useDeviationManagerContext must be used within a DeviationManagerProvider');
  }
  return context;
};

interface DashboardProps {
  // Legacy props for backward compatibility
  deviationId?: string
  isEditMode?: boolean
  onGenerate?: (response: any) => void
  onNavigateDetails?: () => void
}

const DeviationManager: React.FC<DashboardProps> = () => {
  const [currentView, setCurrentView] = useState<DeviationManagerViewMode>(DASHBOARD_VIEW);

  const getViewComponent = () => {
    switch (currentView) {
      case DASHBOARD_VIEW:
        return <div><DeviationManagerDashboard /></div>;
      case DEVIATION_FORM_VIEW:
        return <div><DeviationForm /></div>;
      case DEVIATIONS_VIEW:
        return <div><Deviations /></div>;
      case TREND_REPORTS_VIEW:
        return <div><TrendReports /></div>;
      default:
        return <div><DeviationManagerDashboard /></div>;
    }
  };
  return (
    <ToastProvider>
      <DeviationManagerContext.Provider value={{ currentView, setCurrentView }}>
        <DeviationFormProvider>
          <div className="min-h-screen flex flex-col bg-gray-100 dark:bg-gray-900">
            <Header />
            {currentView === DEVIATION_FORM_VIEW }
            {getViewComponent()}
          </div>
        </DeviationFormProvider>
      </DeviationManagerContext.Provider>
    </ToastProvider>
  );
};

export default DeviationManager;