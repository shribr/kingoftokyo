import React from 'react';
import { DEVIATION_FORM_VIEW, useDeviationManagerContext } from '~/features/deviation-manager/components/DeviationManager';

const Deviations: React.FC = () => {
  const { setCurrentView } = useDeviationManagerContext();
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
      <div className="text-center">
        <div className="mb-8">
          <div className="mx-auto h-32 w-32 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mb-6">
            <svg 
              className="h-16 w-16 text-gray-400 dark:text-gray-500" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
              strokeWidth={1.5}
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0118 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" 
              />
            </svg>
          </div>
        </div>
        
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
          Coming Soon...
        </h1>
        
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
          The Deviations view is currently under development. Check back soon for exciting new features!
        </p>
        
        <div className="flex items-center justify-center text-sm text-gray-700 dark:text-gray-300">
          <span>Looking to create a new Deviation Record? </span>
          <button
            onClick={() => setCurrentView(DEVIATION_FORM_VIEW)}
            className="text-brand-600 hover:text-brand-700 dark:text-brand-400 dark:hover:text-brand-300 underline ml-1 transition-colors"
          >
            Click here to get started.
          </button>
        </div>
      </div>
    </div>
  );
};

export default Deviations;