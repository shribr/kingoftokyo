import useLocalize from '~/hooks/useLocalize';
import { useCallback, useEffect, useState } from 'react';
import { useToastContext } from '~/Providers';
import { NotificationSeverity } from '~/common';
import { TooltipAnchor } from '~/components/ui';
import { Spinner } from '~/components';
import { useDeviationById } from '~/features/deviation-manager/queries/deviationManagerQueries';
import { useUpdateDeviationMutation } from '~/features/deviation-manager/queries/deviationManagerMutations';

function ClassificationSkeleton() {
  return (
    <div className="w-full animate-pulse space-y-2 py-2">
      <div className="flex items-center gap-2">
        <div className="h-4 w-24 rounded bg-gray-300" />
        <div className="h-6 w-14 rounded bg-gray-200" />
        <div className="h-6 w-14 rounded bg-gray-200" />
        <div className="h-6 w-14 rounded bg-gray-200" />
        <div className="h-6 w-14 rounded bg-gray-200" />
      </div>
      <div className="flex w-full items-center gap-2">
        <div className="h-2 w-[55%] rounded bg-gray-100" />
      </div>
    </div>
  );
}

const Classification = ({
  deviationId,
  refresh,
  onRefreshComplete,
}: {
  deviationId: string;
  refresh?: boolean;
  onRefreshComplete?: () => void;
}) => {
  const localize = useLocalize();
  const { showToast } = useToastContext();
  const { data: deviation, isLoading, refetch, isRefetching } = useDeviationById(deviationId);
  const updateDeviation = useUpdateDeviationMutation();
  const badgeLabels = {
    critical: localize('classification_critical'),
    major: localize('classification_major'),
    minor: localize('classification_minor'),
    none: localize('classification_none'),
  };

  const classification = {
    critical: 'critical',
    major: 'major',
    minor: 'minor',
    none: 'none',
  };

  const defaultClassification = badgeLabels.none;

  const [userClassification, setUserClassification] = useState(deviation?.user_classification);
  const [systemClassification, setSystemClassification] = useState(
    deviation?.system_classification,
  );
  const [selectedClassification, setSelectedClassification] = useState('');

  const badges = [
    {
      label: badgeLabels.critical,
      value: classification.critical,
      selected:
        equals(userClassification, classification.critical) ||
        equals(selectedClassification, classification.critical),
    },
    {
      label: badgeLabels.major,
      value: classification.major,
      selected:
        equals(userClassification, classification.major) ||
        equals(selectedClassification, classification.major),
    },
    {
      label: badgeLabels.minor,
      value: classification.minor,
      selected:
        equals(userClassification, classification.minor) ||
        equals(selectedClassification, classification.minor),
    },
    {
      label: badgeLabels.none,
      value: classification.none,
      selected:
        equals(userClassification, classification.none) ||
        equals(selectedClassification, classification.none),
    },
  ];

  const mutateOptions = {
    onSuccess: (response) => {
      setUserClassification(response.result?.user_classification);
      setSelectedClassification('');
      showToast({
        message: localize('classification_update_success'),
        severity: NotificationSeverity.SUCCESS,
        showIcon: true,
      });
    },
    onError: (error) => {
      setSelectedClassification('');
      showToast({
        message: localize('classification_update_error'),
        severity: NotificationSeverity.ERROR,
        showIcon: true,
      });
    },
  };

  const handleBadgeClick = useCallback(
    (newClassification: string) => {
      setSelectedClassification(newClassification);
      updateDeviation.mutate(
        {
          id: deviationId,
          updates: {
            user_classification: newClassification as keyof typeof classification,
          },
        },
        mutateOptions,
      );
    },
    [deviationId, updateDeviation, mutateOptions],
  );

  useEffect(() => {
    if (deviation === undefined) {
      return;
    }

    setUserClassification(
      deviation?.user_classification ?? (defaultClassification as keyof typeof classification),
    );
    setSystemClassification(
      deviation?.system_classification ?? (defaultClassification as keyof typeof classification),
    );
  }, [deviation]);

  function equals(a?: string | null, b?: string | null): boolean {
    return a?.toLowerCase() === b?.toLowerCase();
  }

  useEffect(() => {
    const fetchData = async () => {
      if (refresh) {
        await refetch();
        onRefreshComplete?.();
      }
    };
    fetchData();
  }, [refresh, refetch]);

  if (isLoading || isRefetching) {
    return <ClassificationSkeleton />;
  }

  return (
    <>
      <div className="mx-full rounded-lg">
        <div className={`mb-2 flex items-center gap-2`}>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-text-primary">
              {localize('classification_heading')}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {badges.map((badge) => (
              <div key={badge.value} className="flex items-center gap-2">
                {badge.selected ? (
                  <span
                    className={`inline-flex items-center rounded-md bg-blue-100 px-2 py-1 text-xs font-medium text-blue-700 ring-2 ring-inset ring-blue-700/10 dark:bg-white dark:text-black`}
                  >
                    {equals(selectedClassification, badge.value) ? (
                      <span className="flex items-center gap-1">
                        {badge.label} <Spinner className="h-4 w-4" aria-hidden={true} />
                      </span>
                    ) : (
                      badge.label
                    )}
                  </span>
                ) : (
                  <TooltipAnchor
                    description={`${localize('classification_update_tooltip_text')} ${badge.label}`}
                    render={
                      <span
                        className={`inline-flex items-center rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-text-primary opacity-60 ring-2 ring-inset ring-gray-700/10 dark:bg-gray-800 dark:text-text-secondary dark:ring-gray-400/50 ${
                          updateDeviation.isLoading
                            ? 'cursor-not-allowed opacity-50'
                            : 'cursor-pointer'
                        }`}
                        onClick={() =>
                          updateDeviation.isLoading ? undefined : handleBadgeClick(badge.value)
                        }
                      >
                        {badge.label}
                      </span>
                    }
                  />
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="flex w-full items-center gap-1 pt-1">
          <h6 className="text-xs text-text-primary">
            {localize('classification_sub_heading_1')}{' '}
            <span className="pr-1 text-xs font-semibold capitalize text-text-secondary">
              {systemClassification}.
            </span>
            {localize('classification_sub_heading_2')}
          </h6>
        </div>
      </div>
    </>
  );
};

export default Classification;
