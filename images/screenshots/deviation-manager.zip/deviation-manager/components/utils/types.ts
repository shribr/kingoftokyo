import { IconProps } from './icons'

export type { IconProps }

export type TrendType = 'up' | 'down' | 'neutral'

export interface KpiData {
  title: string
  display: string
  value: number
  deltaPct: number
  trend: TrendType
}


export interface TableColumn<T> {
  header: string
  key: string
  render?: (row: T) => React.ReactNode
}

// User/Assignee types
export interface User {
  name: string
  avatar?: string
}
