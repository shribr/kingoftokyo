// src/utils/icons.ts
import React from 'react'

export interface IconProps {
  className?: string;
}

const Svg: React.FC<React.PropsWithChildren<IconProps>> = ({ className, children }) => (
  <svg viewBox="0 0 24 24" fill="none" className={className} aria-hidden="true">{children}</svg>
)

/** BRAND + NAV **/
export const BrandLogo: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <circle cx="12" cy="12" r="10" fill="currentColor" />
  </Svg>
)

export const BellIcon: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <path d="M12 3a6 6 0 0 0-6 6v3l-1.5 2v1h15v-1L18 12V9a6 6 0 0 0-6-6z" fill="currentColor"/>
  </Svg>
)

export const ProfileIcon: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <circle cx="12" cy="8" r="4" fill="currentColor"/>
    <path d="M4 21a8 8 0 0 1 16 0" fill="currentColor"/>
  </Svg>
)

/** KPI ICONS **/
export const KpiBarsIcon: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <path d="M4 20h16v-2H4v2zm0-6h16v-2H4v2zm0-8v2h16V6H4z" fill="currentColor"/>
  </Svg>
)

export const KpiSearchIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true"
       stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
    <circle cx="11" cy="11" r="7"></circle>
    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
  </svg>
)

export const KpiCheckIcon: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" fill="currentColor"/>
  </Svg>
)

export const KpiClockIcon: React.FC<IconProps> = ({ className }) => (
  <Svg className={className}>
    <path d="M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z" fill="currentColor"/>
    <path d="M12.5 7H11v6l5.25 3.15.75-1.23-4.5-2.67z" fill="currentColor"/>
  </Svg>
)

/** UI ICONS **/
export const SearchIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true"
       stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
    <circle cx="11" cy="11" r="7"></circle>
    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
  </svg>
)

export const ClearIcon: React.FC<IconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true"
       stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
    <line x1="6"  y1="6"  x2="18" y2="18"></line>
    <line x1="18" y1="6"  x2="6"  y2="18"></line>
  </svg>
)
