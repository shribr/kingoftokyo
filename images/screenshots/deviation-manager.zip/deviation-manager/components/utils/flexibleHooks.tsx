// New flexible hooks that use configurable data sources
import { useState, useEffect, useCallback } from 'react';
import type { KpiData, TrendType, Deviation } from './types';
import type { DashboardConfig } from '../config/types';
import { 
  fetchDeviationsData,
  fetchKpisData,
  fetchChartData,
  checkDataSourceHealth,
  configureDashboardData,
  switchDataSource,
} from '../../services/DeviationManagerService';

// Enhanced KPI hook with flexible data source support
export const useFlexibleKpis = () => {
  const [kpis, setKpis] = useState<{ items: KpiData[] }>({ items: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadKpis = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetchKpisData();
      
      if (response.success && response.data.kpis) {
        const kpiItems = response.data.kpis.map((kpi: any) => ({
          title: kpi.title,
          display: kpi.title.includes('days') ? `${kpi.value} days` : kpi.value.toString(),
          value: kpi.value,
          deltaPct: kpi.delta?.percent || 0,
          trend: (kpi.delta?.dir || 'neutral') as TrendType
        }));
        
        setKpis({ items: kpiItems });
      } else {
        throw new Error(response.error || 'Failed to fetch KPIs');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      console.error('Error loading KPIs:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadKpis();
  }, [loadKpis]);

  return { kpis, loading, error, reload: loadKpis };
};

// Enhanced deviation table hook with flexible data source support
interface FlexibleTableState {
  deviations: Deviation[];
  pagination: {
    page: number;
    totalPages: number;
    total: number;
  };
  filters: {
    search: string;
    site: string;
    department: string;
    classification: string;
    stage: string;
  };
  loading: boolean;
  error: string | null;
}

const convertToDeviation = (data: any): Deviation => ({
  id: data.id || data._id,
  name: data.title || data.name,
  department: data.dept || data.department,
  classification: data.classification as 'Critical' | 'Major' | 'Minor',
  stage: data.stage,
  date: data.createdDate || data.created_date || data.date,
  assignee: {
    name: data.assignee || data.assignee_name,
    status: data.assigneeStatus || data.assignee_status || 'offline'
  },
  site: data.site,
  trackwiseRecord: data.trackwiseRecord || data.trackwise_record || data.id
});

export const useFlexibleDeviationTable = (itemsPerPage: number = 5) => {
  const [state, setState] = useState<FlexibleTableState>({
    deviations: [],
    pagination: {
      page: 1,
      totalPages: 1,
      total: 0
    },
    filters: {
      search: '',
      site: '',
      department: '',
      classification: '',
      stage: ''
    },
    loading: true,
    error: null
  });

  const loadDeviations = useCallback(async () => {
    try {
      setState(prev => ({ ...prev, loading: true, error: null }));
      
      const response = await fetchDeviationsData(
        state.filters,
        { page: state.pagination.page, pageSize: itemsPerPage }
      );
      
      if (response.success && response.data) {
        const convertedData = response.data.deviations.map(convertToDeviation);
        const totalPages = Math.max(Math.ceil(response.data.total / itemsPerPage), 1);
        
        setState(prev => ({
          ...prev,
          deviations: convertedData,
          loading: false,
          pagination: {
            ...prev.pagination,
            totalPages,
            total: response.data.total
          }
        }));
      } else {
        throw new Error(response.error || 'Failed to fetch deviations');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setState(prev => ({
        ...prev,
        loading: false,
        error: errorMessage
      }));
      console.error('Error loading deviations:', err);
    }
  }, [state.pagination.page, state.filters, itemsPerPage]);

  useEffect(() => {
    loadDeviations();
  }, [loadDeviations]);

  const handlePageChange = useCallback((page: number) => {
    setState(prev => ({
      ...prev,
      pagination: { ...prev.pagination, page }
    }));
  }, []);

  const handleSearch = useCallback((search: string) => {
    setState(prev => ({
      ...prev,
      filters: { ...prev.filters, search },
      pagination: { ...prev.pagination, page: 1 }
    }));
  }, []);

  const handleFilter = useCallback((key: string, value: string) => {
    setState(prev => ({
      ...prev,
      filters: { ...prev.filters, [key]: value },
      pagination: { ...prev.pagination, page: 1 }
    }));
  }, []);

  return {
    ...state,
    handlePageChange,
    handleSearch,
    handleFilter,
    reload: loadDeviations
  };
};

// Chart data hook with flexible data source support
export const useFlexibleChartData = (chartType: string) => {
  const [chartData, setChartData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadChartData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await fetchChartData(chartType);
      
      if (response.success && response.data.charts?.length > 0) {
        setChartData(response.data.charts[0]);
      } else {
        throw new Error(response.error || 'Failed to fetch chart data');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unknown error occurred');
      console.error('Error loading chart data:', err);
    } finally {
      setLoading(false);
    }
  }, [chartType]);

  useEffect(() => {
    loadChartData();
  }, [loadChartData]);

  return { chartData, loading, error, reload: loadChartData };
};

// Data source configuration hook
export const useDataSourceConfig = () => {
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const checkHealth = useCallback(async () => {
    try {
      setLoading(true);
      const result = await checkDataSourceHealth();
      setHealth(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Health check failed');
    } finally {
      setLoading(false);
    }
  }, []);

  const switchConfig = useCallback(async (config: DashboardConfig) => {
    try {
      setLoading(true);
      setError(null);
      
      const success = await switchDataSource(config);
      if (!success) {
        throw new Error('Failed to switch data source configuration');
      }
      
      await checkHealth();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Configuration switch failed');
    } finally {
      setLoading(false);
    }
  }, [checkHealth]);

  const configure = useCallback(async (config: DashboardConfig) => {
    try {
      setLoading(true);
      setError(null);
      
      const success = await configureDashboardData(config);
      if (!success) {
        throw new Error('Failed to configure data source');
      }
      
      await checkHealth();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Configuration failed');
    } finally {
      setLoading(false);
    }
  }, [checkHealth]);

  useEffect(() => {
    checkHealth();
  }, [checkHealth]);

  return {
    health,
    loading,
    error,
    checkHealth,
    switchConfig,
    configure
  };
};
