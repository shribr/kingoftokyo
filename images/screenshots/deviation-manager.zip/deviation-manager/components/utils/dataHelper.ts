import { request } from 'librechat-data-provider';
import type { 
  DeviationRecord, 
  DeviationFormData, 
  DeviationTableData,
  TrackwiseRecord,
  DeviationApiResponse,
  TrackwiseSearchRequest,
  TrackwiseSearchResponse,
} from './data';
import { 
  SITE_OPTIONS, 
  DEPT_OPTIONS, 
  FIRST_NAMES, 
  LAST_NAMES, 
  CLASSIFICATIONS, 
  STAGES, 
  STATUS_OPTIONS, 
  DEVIATION_NAMES,
  TRACKWISE_RECORDS
} from './data';

// ====================================================================
// CONFIGURATION & STATE
// ====================================================================

// Configuration flag for data source
let USE_LIVE_DATA = true;

export const isUsingLiveData = (): boolean => {
  return USE_LIVE_DATA;
};

export const setUseLiveData = (useLive: boolean): void => {
  USE_LIVE_DATA = useLive;
};

// ====================================================================
// UTILITY FUNCTIONS
// ====================================================================

export const pick = <T>(array: T[]): T => array[Math.floor(Math.random() * array.length)];
export const randomInt = (min: number, max: number): number => Math.floor(Math.random() * (max - min + 1)) + min;
export const randomPercent = (): number => Number((Math.random() * 15).toFixed(1));

export const shuffle = <T>(array: T[]): T[] => {
  const result = array.slice();
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
};

// ====================================================================
// DATA CONVERSION UTILITIES
// ====================================================================

export const convertDeviationDataToDeviationRecord = (deviationData: DeviationTableData): DeviationRecord => {
  return {
    id: deviationData.id,
    trackwiseId: deviationData.trackwiseRecord,
    formData: {
      deviationName: deviationData.title,
      site: deviationData.site,
      department: deviationData.dept,
      assignee: deviationData.assignee,
      createdOn: deviationData.createdDate,
      stage: deviationData.stage,
      selectedTrackwiseRecord: null,
      step1: {
        trackwiseSearchQuery: '',
        whatDefectObserved: `Defect observed in ${deviationData.title.toLowerCase()}`,
        objectDefectObserved: 'Equipment/Process/Material',
        wantSpecifications: 'Standard operating specifications',
        issueOccurred: `${deviationData.site} facility`,
        dateOccurrence: deviationData.createdDate,
        timeOccurrence: `${randomInt(8, 17)}:${randomInt(0, 59).toString().padStart(2, '0')}`,
        dateDetection: deviationData.createdDate,
        impactOfIssue: 'Potential impact on product quality',
        processStepDefect: 'Process step where defect occurred',
        whoInvolvedProcess: 'Process team members',
        whoObservedIssue: deviationData.assignee,
        processDescription: 'Description of the process and what went wrong',
        immediateActions: 'Immediate corrective actions taken',
        materialsToolsEquipment: 'Equipment and materials involved',
        supportingDocuments: []
      },
      step2: {
        riskQuestion1: pick(['yes', 'no', '']),
        riskQuestion2: pick(['yes', 'no', '']),
        riskQuestion3: pick(['yes', 'no', '']),
        riskQuestion4: pick(['yes', 'no', '']),
        severityLevel: deviationData.classification.toLowerCase() === 'critical' ? 'high' : 
                     deviationData.classification.toLowerCase() === 'major' ? 'medium' : 'low',
        severityDetails: 'Severity assessment details',
        detectionLevel: pick(['high', 'medium', 'low']),
        detectionDetails: 'Detection assessment details',
        occurrenceLevel: pick(['high', 'medium', 'low']),
        occurrenceDetails: 'Occurrence assessment details',
        rpnScore: randomInt(1, 10).toString(),
        localClassification: pick(['yes', 'no', '']),
        teamCommitteeAgreement: pick(['yes', 'no', ''])
      },
      step3: {
        investigationPlan: '',
        rootCauseAnalysis: '',
        contributingFactors: []
      },
      step4: {
        correctiveActions: '',
        preventiveActions: '',
        effectiveness: '',
        conclusion: ''
      }
    }
  };
};

export const convertDeviationRecordToDeviationData = (record: DeviationRecord): DeviationTableData => {
  // Map severity level to classification
    const mapSeverityToClassification = (severityLevel: string): 'Critical' | 'Major' | 'Minor' => {
      switch (severityLevel?.toLowerCase()) {
      case 'high': return 'Critical';
      case 'medium': return 'Major';
      case 'low': return 'Minor';
      default: return 'Minor';
    }
  };

  return {
    id: record.id,
    trackwiseRecord: record.trackwiseId || record.id,
    title: record.formData.deviationName,
    site: record.formData.site,
    dept: record.formData.department,
    classification: mapSeverityToClassification(record.formData.step2.severityLevel),
    stage: record.formData.stage,
    createdDate: record.formData.createdOn,
    assignee: record.formData.assignee,
    dateOfOccurrence: record.formData.step1?.dateOccurrence ?? record.formData.createdOn
  };
};

// ====================================================================
// DATA GENERATION FUNCTIONS
// ====================================================================

export const generateTrackwiseId = (): string => {
  const prefix = pick(['ADEV', 'BDEV', 'CDEV', 'DDEV', 'EDEV']);
  const year = new Date().getFullYear();
  const number = randomInt(1, 999).toString().padStart(3, '0');
  return `${prefix}-${year}-${number}`;
};

export const generateRandomDate = (): string => {
  const start = new Date('2025-01-01');
  const end = new Date('2025-12-31');
  const randomTime = start.getTime() + Math.random() * (end.getTime() - start.getTime());
  return new Date(randomTime).toISOString().split('T')[0];
};

export const generateAssignee = (): string => {
  return `${pick(LAST_NAMES)}, ${pick(FIRST_NAMES)}`;
};

export const generateDeviationRecord = (): DeviationTableData => {
  return {
    id: generateTrackwiseId(),
    trackwiseRecord: generateTrackwiseId(),
    title: pick(DEVIATION_NAMES),
    site: pick(SITE_OPTIONS),
    dept: pick(DEPT_OPTIONS.filter(d => d !== 'All')),
    classification: pick(CLASSIFICATIONS),
    stage: pick(STAGES),
    assignee: generateAssignee(),
    createdDate: generateRandomDate(),
    dateOfOccurrence: generateRandomDate()
  };
};

export const generateDeviationData = (count: number = 30): DeviationTableData[] => {
  return Array.from({ length: count }, generateDeviationRecord);
};

export const generateDeviationRecords = (count: number = 30): DeviationRecord[] => {
  const deviationDataArray = Array.from({ length: count }, generateDeviationRecord);
  return deviationDataArray.map(convertDeviationDataToDeviationRecord);
};

// Generate sample deviation records using helper function
export const DEVIATION_RECORDS_SAMPLE: DeviationRecord[] = generateDeviationRecords(30);

// ====================================================================
// KPI & CHART DATA GENERATION
// ====================================================================

export const generateKpiData = () => {
  const total = randomInt(30, 180);
  const under = randomInt(Math.round(total * 0.10), Math.round(total * 0.60));
  const capas = randomInt(0, Math.round(total * 0.50));
  const avg = randomInt(5, 45);

  return {
    total: { value: total, delta: { dir: pick(['up', 'down']) as 'up' | 'down', percent: randomPercent() }},
    under: { value: under, delta: { dir: pick(['up', 'down']) as 'up' | 'down', percent: randomPercent() }},
    capas: { value: capas, delta: { dir: pick(['up', 'down']) as 'up' | 'down', percent: randomPercent() }},
    avg: { value: avg, delta: { dir: pick(['up', 'down']) as 'up' | 'down', percent: randomPercent() }}
  };
};

export const generateStatusChartData = (data: DeviationTableData[]) => {
  const statusCounts = STAGES.reduce((acc, stage) => {
    acc[stage] = data.filter(item => item.stage === stage).length;
    return acc;
  }, {} as Record<string, number>);

  return {
    labels: STAGES,
    datasets: [{
      data: Object.values(statusCounts),
      backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981', '#8b5cf6']
    }]
  };
};

export const generateSiteChartData = (data: DeviationTableData[]) => {
  const siteCounts = SITE_OPTIONS.reduce((acc, site) => {
    acc[site] = data.filter(item => item.site === site).length;
    return acc;
  }, {} as Record<string, number>);

  return {
    labels: SITE_OPTIONS,
    datasets: [{
      data: Object.values(siteCounts),
      backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6']
    }]
  };
};

export const generateTrendChartData = () => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const data = months.map(() => randomInt(10, 50));

  return {
    labels: months,
    datasets: [{
      label: 'Deviations',
      data,
      borderColor: '#60a5fa',
      backgroundColor: 'rgba(96, 165, 250, 0.1)',
      tension: 0.4
    }]
  };
};

// ====================================================================
// DATA FILTERING & PAGINATION
// ====================================================================

export const filterDeviationData = (
  data: DeviationTableData[],
  filters: {
    search?: string;
    site?: string;
    department?: string;
    classification?: string;
    stage?: string;
  }
): DeviationTableData[] => {
  return data.filter(item => {
    const matchesSearch = !filters.search || 
      item.title.toLowerCase().includes(filters.search.toLowerCase()) ||
      item.assignee.toLowerCase().includes(filters.search.toLowerCase()) ||
      item.id.toLowerCase().includes(filters.search.toLowerCase());
      
    const matchesSite = !filters.site || item.site === filters.site;
    const matchesDepartment = !filters.department || item.dept === filters.department;
    const matchesClassification = !filters.classification || item.classification === filters.classification;
    const matchesStage = !filters.stage || item.stage === filters.stage;
    
    return matchesSearch && matchesSite && matchesDepartment && matchesClassification && matchesStage;
  });
};

export const paginateData = <T>(data: T[], page: number, pageSize: number): T[] => {
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  return data.slice(startIndex, endIndex);
};

export const getTotalPages = (totalItems: number, pageSize: number): number => {
  return Math.ceil(totalItems / pageSize);
};

// ====================================================================
// TRACKWISE SEARCH FUNCTIONS
// ====================================================================

export const searchTrackwiseRecords = async (
  searchText: string,
  startDate?: string,
  limit: number = 10
): Promise<TrackwiseRecord[]> => {
  try {
    // For now, fallback to searching existing TRACKWISE_RECORDS
    if (!searchText.trim()) {
      return TRACKWISE_RECORDS.slice(0, limit);
    }
    
    return TRACKWISE_RECORDS.filter(record => 
      record.name.toLowerCase().includes(searchText.toLowerCase()) ||
      record.description.toLowerCase().includes(searchText.toLowerCase()) ||
      record.deviationName.toLowerCase().includes(searchText.toLowerCase())
    ).slice(0, limit);
  } catch (error) {
    console.error('Error in searchTrackwiseRecords:', error);
    
    // Fallback to searching existing TRACKWISE_RECORDS
    return TRACKWISE_RECORDS.filter(record => 
      record.name.toLowerCase().includes(searchText.toLowerCase()) ||
      record.description.toLowerCase().includes(searchText.toLowerCase())
    ).slice(0, limit);
  }
};
