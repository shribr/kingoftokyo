import React, { useEffect } from 'react';
import {
  type AssistantTip,
  Footer,
  FormCard,
  InvestigationAssistant,
  MainContent,
  type ProgressStep,
  Stepper,
  VerticalProgressPane,
} from '../index';
import Filter from '../layout/MainHeader/FilterBar/Filter';
import { DEPARTMENT_FILTER_OPTIONS, SITE_FILTER_OPTIONS } from '../utils/data';
import '../dashboard.css';
import ADProfileCell from '../User/ADProfileCell';
import { useDeviationFormContext } from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';
import IntakeStepOne from '~/features/deviation-manager/components/DeviationForm/DeviationFormStepOne';
import DeviationFormStepTwo from '~/features/deviation-manager/components/DeviationForm/DeviationFormStepTwo';
import DeviationFormStepFour from '~/features/deviation-manager/components/DeviationForm/DeviationFormStepFour';
import DeviationFormStepThree from '~/features/deviation-manager/components/DeviationForm/DeviationFormStepThree';
import {
  DASHBOARD_VIEW,
  useDeviationManagerContext,
} from '~/features/deviation-manager/components/DeviationManager';

const DeviationForm: React.FC = () => {
  const { setCurrentView } = useDeviationManagerContext();

  const handleBackToDashboard = () => {
    setCurrentView(DASHBOARD_VIEW);
  };

  const {
    // State
    formData,
    setFormData,
    currentStep,
    setCurrentStep,
    visitedStep,
    setVisitedStep,
    isStep1Complete,
    isStep2Complete,
    isStep3Complete,
    isStep4Complete,
    canAccessStep,
    getHighestAccessibleStep,
    getLegitimateCurrentStep,
    getStageForStep,

    // Navigation
    handleStepNavigation,
    isCurrentStepAccessible,

    // Handlers
    handleInputChange,

    // Methods
    calculateRPN,
    getRPNClassificationInfo,
    deviationSteps,
  } = useDeviationFormContext();

  // Update stage when currentStep changes
  useEffect(() => {
    setFormData((prev) => ({
      ...prev,
      stage: getStageForStep(currentStep),
    }));
  }, [currentStep]);

  // Update visitedStep when accessibility changes
  useEffect(() => {
    const highestAccessible = getHighestAccessibleStep();
    setVisitedStep(Math.max(visitedStep, highestAccessible));
  }, [visitedStep, getHighestAccessibleStep]);

  const handleCancel = () => {
    // Cancel returns user to dashboard context
    setCurrentView(DASHBOARD_VIEW);
  };

  // Define the progress steps for the vertical pane
  const progressSteps: ProgressStep[] = [
    {
      id: 1,
      label: 'Intake',
      description: 'Collect initial deviation information',
      completed: isStep1Complete(),
    },
    {
      id: 2,
      label: 'Initial Review & Impact',
      description: 'Assess risk and impact',
      completed: isStep2Complete(),
    },
    {
      id: 3,
      label: 'Impact Analysis & Risk Analysis',
      description: 'Conduct root cause analysis',
      completed: isStep3Complete(),
    },
    {
      id: 4,
      label: 'CAPA & Conclusion',
      description: 'Define corrective actions',
      completed: isStep4Complete(),
    },
  ];

  // Define the assistant tips
  const assistantTips: AssistantTip[] = [
    {
      id: 'getting-started',
      icon: '💡',
      title: 'Getting Started',
      description:
        'Fill out the basic information to begin. The AI will help classify the deviation and suggest investigation steps.',
      color: 'blue',
    },
    {
      id: 'ai-analysis',
      icon: '🤖',
      title: 'AI Analysis',
      description:
        "Once created, I'll analyze the deviation and provide risk classification recommendations.",
      color: 'green',
    },
    {
      id: 'next-steps',
      icon: '📋',
      title: 'Next Steps',
      description: "After creation, you'll be able to start the guided investigation process.",
      color: 'purple',
    },
  ];

  // Define stage options
  const stageOptions = [
    { value: 'Intake', label: 'Intake' },
    { value: 'Initial Review & Impact', label: 'Initial Review & Impact' },
    { value: 'Impact Analysis & Risk Analysis', label: 'Impact Analysis & Risk Analysis' },
    { value: 'CAPA & Conclusion', label: 'CAPA & Conclusion' },
    { value: 'Verification', label: 'Verification' },
  ];

  // Update RPN when severity, detection, or occurrence changes
  useEffect(() => {
    if (formData.severityLevel && formData.detectionLevel && formData.occurrenceLevel) {
      calculateRPN(formData.severityLevel, formData.detectionLevel, formData.occurrenceLevel);
    }
  }, [formData.severityLevel, formData.detectionLevel, formData.occurrenceLevel]);

  return (
    <div>
      <div className="flex flex-col bg-gray-100 dark:bg-gray-900">
        {/* Main Layout with Progress Pane */}
        <div className="flex flex-1 overflow-hidden">
          {/* Vertical Progress Pane */}
          <VerticalProgressPane
            steps={progressSteps}
            currentStep={currentStep}
            visitedStep={visitedStep}
            canAccessStep={canAccessStep}
            getLegitimateCurrentStep={getLegitimateCurrentStep}
            onStepClick={handleStepNavigation}
            className="flex-shrink-0"
          />

          {/* Scrollable content area with bottom padding for sticky footer */}
          <div className="flex-1 overflow-auto pb-32">
            <MainContent>
              {/* Breadcrumb */}
              <div className="mb-6">
                <button
                  onClick={handleBackToDashboard}
                  className="text-sm font-medium text-blue-600 hover:text-blue-800"
                >
                  ← Back to dashboard
                </button>
              </div>

              <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
                {/* Main Content */}
                <div className="lg:col-span-4">
                  {/* Header Section - Outside white container */}
                  <div className="mb-6">
                    <div className="mb-2 flex items-start justify-between">
                      {currentStep === 1 ? (
                        <h1 className="text-2xl font-bold italic text-gray-900 dark:text-gray-100">
                          New Record
                        </h1>
                      ) : (
                        <div className="mr-4 flex-1">
                          <label className="mb-1 block text-xs font-medium text-gray-700 dark:text-gray-300">
                            Deviation Name
                          </label>
                          <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 dark:border-blue-700 dark:bg-blue-900/20">
                            <div className="flex items-center">
                              <h1 className="text-lg font-bold italic text-gray-900 dark:text-gray-100">
                                {formData.deviationName || 'Untitled Deviation'}
                              </h1>
                              <span className="ml-1 font-bold text-blue-600 dark:text-blue-400">
                                *
                              </span>
                            </div>
                            <div className="mt-1 text-xs italic text-gray-600 dark:text-gray-400">
                              * new record
                            </div>
                          </div>
                        </div>
                      )}
                      <div className="flex items-center space-x-4">
                        <div className="w-40">
                          <Filter
                            id="header-site"
                            label="Site"
                            options={SITE_FILTER_OPTIONS}
                            value={formData.site}
                            onChange={(value) => handleInputChange('site', value)}
                          />
                        </div>
                        <div className="w-44">
                          <Filter
                            id="header-department"
                            label="Department"
                            options={DEPARTMENT_FILTER_OPTIONS}
                            value={formData.department}
                            onChange={(value) => handleInputChange('department', value)}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="text-sm italic text-gray-600 dark:text-gray-400">
                      Complete all required information to complete a new record
                    </div>
                  </div>

                  {/* Record Info Box */}
                  <FormCard>
                    <div className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <label className="mb-2 block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {currentStep === 1 ? 'Trackwise Record' : 'Deviation Record'}
                          </label>
                          {currentStep === 1 ? (
                            // Step 1: Show selected Trackwise record or [none selected]
                            <div className="relative inline-block min-w-80 max-w-md rounded-md border border-gray-200 bg-gray-50 p-3 dark:border-gray-600 dark:bg-gray-700">
                              <div className="pr-8">
                                {formData.selectedTrackwiseRecord ? (
                                  <>
                                    <div className="mb-1 text-sm font-medium text-gray-900 dark:text-gray-100">
                                      {formData.selectedTrackwiseRecord.id}
                                    </div>
                                    <div className="mb-2 text-xs text-gray-600 dark:text-gray-400">
                                      {formData.selectedTrackwiseRecord.name}
                                    </div>
                                    <div className="space-y-1">
                                      <div className="text-xs text-gray-500 dark:text-gray-500">
                                        <span className="font-medium">Classification:</span>{' '}
                                        {formData.selectedTrackwiseRecord.classification}
                                      </div>
                                      <div className="text-xs text-gray-500 dark:text-gray-500">
                                        <span className="font-medium">Created:</span>{' '}
                                        {new Date(
                                          formData.selectedTrackwiseRecord.createdOn,
                                        ).toLocaleDateString('en-US', {
                                          year: 'numeric',
                                          month: 'short',
                                          day: 'numeric',
                                        })}
                                      </div>
                                    </div>
                                  </>
                                ) : (
                                  <div className="text-sm text-gray-500 dark:text-gray-400">
                                    [none selected]
                                  </div>
                                )}
                              </div>
                            </div>
                          ) : (
                            // Step 2+: Show generated Deviation ID
                            <div className="relative inline-block min-w-80 max-w-md rounded-md border border-gray-200 bg-gray-50 p-3 dark:border-gray-600 dark:bg-gray-700">
                              <div className="pr-8">
                                <div className="mb-2 text-sm font-medium text-gray-900 dark:text-gray-100">
                                  #DEV-2025-042
                                </div>
                                <div className="space-y-1">
                                  <div className="text-xs text-gray-500 dark:text-gray-500">
                                    <span className="font-medium">Status:</span> {formData.stage}
                                  </div>
                                  <div className="text-xs text-gray-500 dark:text-gray-500">
                                    <span className="font-medium">Created:</span>{' '}
                                    {new Date(formData.createdOn).toLocaleDateString('en-US', {
                                      year: 'numeric',
                                      month: 'short',
                                      day: 'numeric',
                                    })}
                                  </div>
                                  {(formData.deviationClassification ||
                                    (formData.severityLevel &&
                                      formData.detectionLevel &&
                                      formData.occurrenceLevel)) && (
                                    <div className="flex items-center text-xs text-gray-500 dark:text-gray-500">
                                      <span className="font-medium">Classification:</span>
                                      <span
                                        className={`ml-2 rounded px-2 py-1 text-xs font-medium capitalize ${getRPNClassificationInfo().bgColor} ${getRPNClassificationInfo().color} ${getRPNClassificationInfo().borderColor} border`}
                                      >
                                        {formData.deviationClassification ||
                                          getRPNClassificationInfo().classification}
                                      </span>
                                      {currentStep === 3 && (
                                        <button
                                          type="button"
                                          onClick={() => {
                                            setCurrentStep(2);
                                            // Scroll to RPN calculation section after a short delay to allow step change
                                            setTimeout(() => {
                                              const rpnSection = document
                                                .querySelector('h4')
                                                ?.closest('div')
                                                ?.parentElement?.querySelector(
                                                  'div:has(h4:contains("RPN calculation"))',
                                                );
                                              if (rpnSection) {
                                                rpnSection.scrollIntoView({
                                                  behavior: 'smooth',
                                                  block: 'start',
                                                });
                                              } else {
                                                // Fallback: scroll to any element containing "RPN calculation" text
                                                const rpnElement = Array.from(
                                                  document.querySelectorAll('h4'),
                                                ).find((el) =>
                                                  el.textContent?.includes('RPN calculation'),
                                                )?.parentElement;
                                                if (rpnElement) {
                                                  rpnElement.scrollIntoView({
                                                    behavior: 'smooth',
                                                    block: 'start',
                                                  });
                                                }
                                              }
                                            }, 100);
                                          }}
                                          className="ml-2 flex items-center text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                                        >
                                          Recalculate classification
                                          <svg
                                            className="ml-1 h-3 w-3"
                                            fill="currentColor"
                                            viewBox="0 0 20 20"
                                          >
                                            <path
                                              fillRule="evenodd"
                                              d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V4a2 2 0 00-2-2H6zm1 2a1 1 0 000 2h6a1 1 0 100-2H7zm6 7a1 1 0 011 1v3a1 1 0 11-2 0v-3a1 1 0 011-1zM7 8a1 1 0 000 2h6a1 1 0 100-2H7zm0 4a1 1 0 100 2h3a1 1 0 100-2H7z"
                                              clipRule="evenodd"
                                            />
                                          </svg>
                                        </button>
                                      )}
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-start space-x-6">
                          <div>
                            <label className="mb-1 block text-xs font-medium text-gray-700 dark:text-gray-300">
                              Assignee
                            </label>
                            <ADProfileCell
                              user={{ name: formData.assignee || '', status: 'online' }}
                            />
                          </div>

                          <div>
                            <label className="mb-1 block text-xs font-medium text-gray-700 dark:text-gray-300">
                              Created On
                            </label>
                            <span className="text-xs text-gray-900 dark:text-gray-100">
                              {new Date(formData.createdOn).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                              })}
                            </span>
                          </div>

                          <div>
                            <label className="mb-1 block text-xs font-medium text-gray-700 dark:text-gray-300">
                              Stage
                            </label>
                            <span className="inline-flex items-center rounded-full border border-blue-200 bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-800">
                              {formData.stage}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </FormCard>

                  {/* Stepper - On light gray background */}
                  <div className="my-6">
                    <Stepper
                      steps={deviationSteps}
                      currentStep={currentStep}
                      visitedStep={visitedStep}
                      canAccessStep={canAccessStep}
                      getLegitimateCurrentStep={getLegitimateCurrentStep}
                      onStepClick={handleStepNavigation}
                    />
                  </div>

                  {/* Step Information Header */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                        {currentStep === 1
                          ? 'Intake'
                          : currentStep === 2
                            ? 'Initial Review & Impact'
                            : currentStep === 3
                              ? 'Impact Analysis & Risk Analysis'
                              : currentStep === 4
                                ? 'CAPA & Conclusion'
                                : 'CAPA & Conclusion'}
                      </h3>
                      {!isCurrentStepAccessible() && (
                        <div className="inline-flex items-center rounded-full border border-yellow-200 bg-yellow-100 px-3 py-1 text-xs font-medium text-yellow-800 dark:border-yellow-700 dark:bg-yellow-900/20 dark:text-yellow-400">
                          <svg className="mr-1 h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                            <path
                              fillRule="evenodd"
                              d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                              clipRule="evenodd"
                            />
                          </svg>
                          Complete previous required steps before continuing
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Instruction Text */}
                  <div className="mb-6">
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {currentStep === 1
                        ? 'Select an existing opened deviation from Trackwise using the Trackwise record search field or continue manually by filling out the details below.'
                        : currentStep === 2
                          ? 'Complete all required information to complete a new record'
                          : currentStep === 3
                            ? 'Conduct investigation and root cause analysis.'
                            : 'Define corrective and preventive actions and conclude the deviation.'}
                    </p>
                  </div>

                  <IntakeStepOne handleCancel={() => handleCancel()} />
                  <DeviationFormStepTwo />
                  <DeviationFormStepThree />
                  <DeviationFormStepFour />
                </div>

                {/* Sidebar */}
                <div className="lg:col-span-1">
                  <InvestigationAssistant />
                </div>
              </div>
            </MainContent>
          </div>
        </div>

        <Footer />
      </div>
    </div>
  );
};

export default DeviationForm;
