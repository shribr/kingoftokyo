import React, { createContext, useContext } from 'react';
import { useDeviationForm } from './useDeviationForm'; // Your custom hook

type DeviationFormContextValue = ReturnType<typeof useDeviationForm>;
const DeviationFormContext = createContext<DeviationFormContextValue | undefined>(undefined);

export const DeviationFormProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const deviationForm = useDeviationForm();
  return (
    <DeviationFormContext.Provider value={deviationForm}>
      {children}
    </DeviationFormContext.Provider>
  );
};

export const useDeviationFormContext = (): DeviationFormContextValue => {
  const context = useContext(DeviationFormContext);
  if (!context) {
    throw new Error('useDeviationFormContext must be used within a DeviationFormProvider');
  }
  return context;
};
