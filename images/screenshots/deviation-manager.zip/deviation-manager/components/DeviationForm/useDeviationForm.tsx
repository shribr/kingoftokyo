import React, { useCallback, useState } from 'react';
import {
  DEPARTMENT_FILTER_OPTIONS,
  SITE_FILTER_OPTIONS,
  TRACKWISE_RECORDS,
  TrackwiseRecord,
} from '~/features/deviation-manager/components/utils/data';
import {
  DEFAULT_FORM_DATA,
  FormData,
} from '~/features/deviation-manager/components/DeviationForm/defaultFormData';
import {
  Header,
  type ProgressStep,
  Step,
  VerticalProgressPane,
} from '~/features/deviation-manager/components';
import Filter from '../layout/MainHeader/FilterBar/Filter';
import {
  useGenerateDescriptionMutation, useProcessClassificationMutation,
  useProcessRiskImpactMutation,
} from '~/features/deviation-manager/queries/deviationManagerMutations';



export const useDeviationForm = () => {
  const [formData, setFormData] = useState<FormData>(DEFAULT_FORM_DATA);

  const [currentStep, setCurrentStep] = useState(1); // Start at step 1 for normal operation
  const [visitedStep, setVisitedStep] = useState(1); // Tracks the highest step the user can legitimately access
  const [filteredTrackwiseRecords, setFilteredTrackwiseRecords] = useState<TrackwiseRecord[]>([]);
  const [showTrackwiseDropdown, setShowTrackwiseDropdown] = useState(false);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = useCallback(
    (field: keyof FormData, value: string | TrackwiseRecord | null | string[]) => {
      setFormData((prev) => ({ ...prev, [field]: value }));
    },
    [],
  );

  // Function to get stage based on current step
  const getStageForStep = (step: number): string => {
    switch (step) {
      case 1:
        return 'Intake';
      case 2:
        return 'Initial Review & Impact';
      case 3:
        return 'Impact Analysis & Risk Analysis';
      case 4:
        return 'CAPA & Conclusion';
      default:
        return 'Intake';
    }
  };

  // Step validation functions - each checks only its own requirements
  const isStep1RequirementsMet = (): boolean => {
    return !!(
      formData.deviationName.trim() &&
      formData.whatDefectObserved.trim() &&
      formData.objectDefectObserved.trim() &&
      formData.wantSpecifications.trim() &&
      formData.issueOccurred.trim() &&
      formData.dateOccurrence &&
      formData.timeOccurrence &&
      formData.dateDetection &&
      formData.impactOfIssue.trim() &&
      formData.processStepDefect.trim() &&
      formData.whoInvolvedProcess.trim() &&
      formData.whoObservedIssue.trim() &&
      formData.processDescription.trim() &&
      formData.immediateActions.trim() &&
      formData.materialsToolsEquipment.trim()
    );
  };

  const isStep2RequirementsMet = (): boolean => {
    return !!(
      formData.riskQuestion1 &&
      formData.riskQuestion2 &&
      formData.riskQuestion3 &&
      formData.riskQuestion4 &&
      formData.severityLevel &&
      formData.detectionLevel &&
      formData.occurrenceLevel &&
      formData.localClassification &&
      formData.teamCommitteeAgreement
    );
  };

  const isStep3RequirementsMet = (): boolean => {
    return !!(
      formData.shortDescription &&
      formData.generalDescription &&
      formData.riskAnalysis &&
      formData.impactAnalysis
    );
  };

  const isStep4RequirementsMet = (): boolean => {
    return !!formData.finalAnalysis;
  };

  // Step completion functions - check if step is complete (own requirements + all previous steps)
  const isStep1Complete = (): boolean => {
    return isStep1RequirementsMet() && formData.deviationId.trim() !== '';
  };

  const isStep2Complete = (): boolean => {
    return isStep1RequirementsMet() && isStep2RequirementsMet();
  };

  const isStep3Complete = (): boolean => {
    return isStep1RequirementsMet() && isStep2RequirementsMet() && isStep3RequirementsMet();
  };

  const isStep4Complete = (): boolean => {
    return (
      isStep1RequirementsMet() &&
      isStep2RequirementsMet() &&
      isStep3RequirementsMet() &&
      isStep4RequirementsMet()
    );
  };

  // Function to check if a step can be accessed
  const canAccessStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return true;
      case 2:
        return isStep1RequirementsMet();
      case 3:
        return isStep1RequirementsMet() && isStep2RequirementsMet();
      case 4:
        return isStep1RequirementsMet() && isStep2RequirementsMet() && isStep3RequirementsMet();
      default:
        return false;
    }
  };

  // Function to get the highest accessible step
  const getHighestAccessibleStep = (): number => {
    if (canAccessStep(4)) {
      return 4;
    }
    if (canAccessStep(3)) {
      return 3;
    }
    if (canAccessStep(2)) {
      return 2;
    }
    return 1;
  };

  // Function to get the legitimate current step (where user should be working)
  const getLegitimateCurrentStep = (): number => {
    return getHighestAccessibleStep();
  };

  // Function to handle step navigation
  const handleStepNavigation = (targetStep: number) => {
    // Always allow navigation to the target step (for preview purposes)
    setCurrentStep(targetStep);

    // Update visitedStep only if this step is legitimately accessible
    if (canAccessStep(targetStep)) {
      setVisitedStep(Math.max(visitedStep, targetStep));
    }
  };

  // Function to determine if current step is properly accessible (not just previewed)
  const isCurrentStepAccessible = (): boolean => {
    return canAccessStep(currentStep);
  };

  // Function to determine if form elements should be disabled
  const shouldDisableFormElements = (): boolean => {
    return !isCurrentStepAccessible();
  };

  const handleTrackwiseSearch = (query: string) => {
    setFormData((prev) => ({ ...prev, trackwiseSearchQuery: query }));

    if (query.trim() === '') {
      setFilteredTrackwiseRecords([]);
      setShowTrackwiseDropdown(false);
      return;
    }

    const filtered = TRACKWISE_RECORDS.filter(
      (record) =>
        record.id.toLowerCase().includes(query.toLowerCase()) ||
        record.name.toLowerCase().includes(query.toLowerCase()) ||
        record.description.toLowerCase().includes(query.toLowerCase()),
    );

    setFilteredTrackwiseRecords(filtered);
    setShowTrackwiseDropdown(true);
  };

  // Handle Trackwise record selection
  const handleTrackwiseSelect = (record: TrackwiseRecord) => {
    setFormData((prev) => ({
      ...prev,
      selectedTrackwiseRecord: record,
      trackwiseSearchQuery: '',
      department: record.department,
      // Populate all form fields from the selected record
      deviationName: record.deviationName,
      whatDefectObserved: record.whatDefectObserved,
      objectDefectObserved: record.objectDefectObserved,
      wantSpecifications: record.specifications,
      issueOccurred: record.issueOccurred,
      timeOccurrence: record.timeOfOccurrence,
      dateOccurrence: record.actualDefectOccurrence,
      dateDetection: record.dateDefectDiscovered,
      impactOfIssue: record.potentialImpact,
      processStepDefect: record.detectionMethods,
      whoInvolvedProcess: record.personWhoReported,
      whoObservedIssue: record.personWhoObserved,
      processDescription: record.backgroundInformation,
      immediateActions: record.immediateAction,
      materialsToolsEquipment: record.attachmentsDescription,
      generalDescription: record.description,
      finalAnalysis: record.finalAnalysis,
      shortDescription: record.additionalComments,
    }));
    setShowTrackwiseDropdown(false);
  };

  // Function to get the next step's label
  const getNextStepLabel = (currentStep: number): string => {
    const nextStep = deviationSteps.find((step) => step.id === currentStep + 1);
    return nextStep ? nextStep.label : 'Next Step';
  };

  // Function to get the previous step's label
  const getPreviousStepLabel = (currentStep: number): string => {
    const previousStep = deviationSteps.find((step) => step.id === currentStep - 1);
    return previousStep ? `Step ${previousStep.id}` : 'Previous Step';
  };

  // RPN Calculation
  const calculateRPN = (severity: string, detection: string, occurrence: string) => {
    // Updated scoring system based on screenshot requirements
    const severityScore =
      severity === 'high' ? 6 : severity === 'medium' ? 2 : severity === 'low' ? 1 : 0;
    const detectionScore =
      detection === 'high' ? 1 : detection === 'medium' ? 3 : detection === 'low' ? 10 : 0;
    const occurrenceScore =
      occurrence === 'high' ? 5 : occurrence === 'medium' ? 2 : occurrence === 'low' ? 1 : 0;

    const rpn = severityScore * detectionScore * occurrenceScore;

    // Determine classification based on new RPN score thresholds
    let classification: 'critical' | 'major' | 'minor' | '' = '';
    if (rpn > 59) {
      classification = 'critical';
    } else if (rpn >= 15) {
      classification = 'major';
    } else if (rpn > 0) {
      classification = 'minor';
    }

    setFormData((prev) => ({
      ...prev,
      rpnScore: rpn.toString(),
      deviationClassification: classification,
    }));
  };

  // Get RPN classification display info
  const getRPNClassificationInfo = () => {
    const score = parseInt(formData.rpnScore) || 0;
    const severityScore =
      formData.severityLevel === 'high'
        ? 6
        : formData.severityLevel === 'medium'
          ? 2
          : formData.severityLevel === 'low'
            ? 1
            : 0;
    const detectionScore =
      formData.detectionLevel === 'high'
        ? 1
        : formData.detectionLevel === 'medium'
          ? 3
          : formData.detectionLevel === 'low'
            ? 10
            : 0;
    const occurrenceScore =
      formData.occurrenceLevel === 'high'
        ? 5
        : formData.occurrenceLevel === 'medium'
          ? 2
          : formData.occurrenceLevel === 'low'
            ? 1
            : 0;

    if (score > 59) {
      return {
        classification: 'critical',
        color: 'text-red-600',
        bgColor: 'bg-red-100',
        borderColor: 'border-red-200',
      };
    } else if (score >= 15) {
      return {
        classification: 'major',
        color: 'text-yellow-600',
        bgColor: 'bg-yellow-100',
        borderColor: 'border-yellow-200',
      };
    } else {
      return {
        classification: 'minor',
        color: 'text-green-600',
        bgColor: 'bg-green-100',
        borderColor: 'border-green-200',
      };
    }
  };

  // Check if any of the first 4 risk questions is answered "yes"
  const hasYesAnswerInRiskQuestions = () => {
    return (
      formData.riskQuestion1 === 'yes' ||
      formData.riskQuestion2 === 'yes' ||
      formData.riskQuestion3 === 'yes' ||
      formData.riskQuestion4 === 'yes'
    );
  };

  // Handle removing selected Trackwise record
  const handleTrackwiseRemove = () => {
    setFormData((prev) => ({
      ...prev,
      selectedTrackwiseRecord: null,
      // Clear all form fields that were populated from the record
      deviationName: '',
      whatDefectObserved: '',
      objectDefectObserved: '',
      wantSpecifications: '',
      issueOccurred: '',
      timeOccurrence: '',
      dateOccurrence: '',
      dateDetection: '',
      impactOfIssue: '',
      processStepDefect: '',
      whoInvolvedProcess: '',
      whoObservedIssue: '',
      processDescription: '',
      immediateActions: '',
      materialsToolsEquipment: '',
      generalDescription: '',
      finalAnalysis: '',
      shortDescription: '',
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
  };

  const generateDescriptions = useGenerateDescriptionMutation();

  const handleSubmitStep1 = async (e: React.FormEvent) => {
    console.log('Submitting step 1 form...');
    e.preventDefault();
    setIsSubmitting(true);

    if (!formData.deviationId) {
      const intake_data = {
        deviation_name: formData.deviationName,
        what_defect_observed: formData.whatDefectObserved,
        what_deviation_for: formData.objectDefectObserved,
        which_object_defect_observed: formData.objectDefectObserved,
        what_specifications_requirements: formData.wantSpecifications,
        where_issue_occur: formData.issueOccurred,
        date_of_occurrence: formData.dateOccurrence,
        time_of_occurrence: formData.timeOccurrence,
        date_of_detection: formData.dateDetection,
        what_process_step: formData.processStepDefect,
        who_involved_process: formData.whoInvolvedProcess,
        who_observed_issue: formData.whoObservedIssue,
        immediate_actions_taken: formData.immediateActions,
        materials_tools_equipment: formData.materialsToolsEquipment,
        reporter_email: '',
        site: formData.site,
        created_from_trackwise: formData.selectedTrackwiseRecord ? true : false,
        trackwise_record_id: formData.selectedTrackwiseRecord
          ? formData.selectedTrackwiseRecord.id
          : null,
        has_supporting_documents: formData.supportingDocuments.length > 0 ? true : false,
      };
      const files = [];

      const response = await generateDescriptions.mutateAsync(
        { intakeData: intake_data, files },
        {
          onSuccess: (data) => {
            setFormData((prev) => ({
              ...prev,
              deviationId: data.draft_deviation_id,
            }));
            handleStepNavigation(2);
            setIsSubmitting(false);
          },
        },
      );
    } else {
      handleStepNavigation(2);
    }
  };

  const handleSubmitStep3 = (e: React.FormEvent) => {
    console.log('Submitting step 3 form...');
    e.preventDefault();
  };


  const handleClassificationSubmit = async (e: React.FormEvent) => {
    console.log('Submitting step 2 form...');
    e.preventDefault();

    if (!formData.severityLevel || !formData.detectionLevel || !formData.occurrenceLevel) {
      console.error('RPN values are required for classification');
      return;
    }

    setIsSubmitting(true);
    const severityScore =
      formData.severityLevel === 'high' ? 7 : formData.severityLevel === 'medium' ? 4 : 1;
    const detectionScore =
      formData.detectionLevel === 'high' ? 6 : formData.detectionLevel === 'medium' ? 4 : 2;
    const occurrenceScore =
      formData.occurrenceLevel === 'high' ? 6 : formData.occurrenceLevel === 'medium' ? 4 : 2;

    const deviationId =
      formData.selectedTrackwiseRecord?.id || '0babd19d-dd2a-4f7c-81b9-f08b1ab9062c';

    const response = await useProcessClassificationMutation().mutateAsync(
      {
        deviationId,
        data: {
          request_type: 'classification_only',
          rpn_inputs: {
            severity: severityScore,
            occurrence: occurrenceScore,
            detection: detectionScore,
          },
        },
      },
      {
        onSuccess: (result) => {
          useProcessRiskImpactMutation().mutateAsync(deviationId, {
            onSuccess: (result) => {
              setFormData((prev) => ({
                ...prev,
                shortDescription: result.generated_descriptions,
                generalDescription: result.generated_descriptions,
                riskAnalysis: result.risk_impact_analysis.risk_analysis,
                impactAnalysis: result.risk_impact_analysis.impact_analysis,
              }));

              setIsSubmitting(false);
              handleStepNavigation(3);
            },
            onError: (error) => {
              setIsSubmitting(false);
            },
          });
        },
        onError: (error) => {
          setIsSubmitting(false);
        },
      },
    );
  };

  // Define the deviation process steps
  const deviationSteps: Step[] = [
    { id: 1, label: 'Intake' },
    { id: 2, label: 'Initial Review & Impact' },
    { id: 3, label: 'Impact Analysis & Risk Analysis' },
    { id: 4, label: 'CAPA & Conclusion' },
  ];

  return {
    // State
    formData,
    setFormData,
    currentStep,
    setCurrentStep,
    visitedStep,
    setVisitedStep,
    filteredTrackwiseRecords,
    setFilteredTrackwiseRecords,
    showTrackwiseDropdown,
    setShowTrackwiseDropdown,
    isSubmitting,
    setIsSubmitting,

    // Validations
    isStep1RequirementsMet,
    isStep2RequirementsMet,
    isStep3RequirementsMet,
    isStep4RequirementsMet,
    isStep1Complete,
    isStep2Complete,
    isStep3Complete,
    isStep4Complete,
    canAccessStep,
    getHighestAccessibleStep,
    getLegitimateCurrentStep,
    getStageForStep,

    // Navigation
    handleStepNavigation,
    isCurrentStepAccessible,
    shouldDisableFormElements,

    // Handlers
    handleInputChange,
    handleTrackwiseSearch,
    handleTrackwiseSelect,
    handleTrackwiseRemove,
    handleSubmit,
    handleSubmitStep1,
    handleSubmitStep3,
    handleClassificationSubmit,

    // Methods
    getNextStepLabel,
    getPreviousStepLabel,
    calculateRPN,
    getRPNClassificationInfo,
    hasYesAnswerInRiskQuestions,
    deviationSteps,
  };
};