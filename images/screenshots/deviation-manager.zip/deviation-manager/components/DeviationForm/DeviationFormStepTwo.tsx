import { FormCard } from '~/features/deviation-manager/components';
import React from 'react';
import {
  DeviationFormProvider,
  useDeviationFormContext,
} from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';

const DeviationFormStepTwo = () => {
  const {
    // State
    formData,
    currentStep,
    isSubmitting,

    // Validations
    canAccessStep,

    // Navigation
    handleStepNavigation,
    shouldDisableFormElements,

    // Handlers
    handleInputChange,
    handleClassificationSubmit,

    // Methods
    getNextStepLabel,
    getPreviousStepLabel,
    getRPNClassificationInfo,
    hasYesAnswerInRiskQuestions,
  } = useDeviationFormContext();

  return (
    <div>
      {currentStep === 2 && (
        /* Step 2: Initial Review & Impact */
        <FormCard>
          <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
            {shouldDisableFormElements() && (
              <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
            )}
            <form onSubmit={handleClassificationSubmit}>
              <div className="space-y-6">
                {/* Impact analysis questions */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Risk assessment questions
                    </h4>
                  </div>

                  <div className="p-8 space-y-6">
                    {/* Instructional text */}
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      Fill out the impact analysis questions below to get the most accurate deviation classification calculation.
                    </div>

                    {/* Critical Warning Message */}
                    {hasYesAnswerInRiskQuestions() && (
                      <div className="mx-4">
                        <div className="border border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20 rounded-lg">
                          <div className="flex items-start p-4">
                            <div className="flex-shrink-0">
                              <div className="h-6 w-6 bg-red-500 rounded-full flex items-center justify-center">
                                <svg className="h-4 w-4 text-white" fill="currentColor" viewBox="0 0 20 20"></svg>
                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                              </div>
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium text-red-800 dark:text-red-200">
                                Because you answered yes to one of the below questions, this classification is considered critical,
                                therefore you will have to escalate this deviation after confirmation.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    {/* Question 1 */}
                    <div>
                      <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        Does this deviation arise from a defined critical process or incident that could or does result in product that does not meet its regulatory filed specification and/or required quality standard in each case when that would impact patient treatment? <span className="text-red-500">*</span>
                      </div>
                      <div className="flex gap-6">
                        {['yes', 'no'].map((option) => (
                          <label key={option} className="flex items-center">
                            <input
                              type="radio"
                              name="riskQuestion1"
                              value={option}
                              checked={formData.riskQuestion1 === option}
                              onChange={(e) => handleInputChange('riskQuestion1', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                          {option}
                                        </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Question 2 */}
                    <div>
                      <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        Is this deviation a quality incident that could result in a failure to supply product which could impact patient treatment? <span className="text-red-500">*</span>
                      </div>
                      <div className="flex gap-6">
                        {['yes', 'no'].map((option) => (
                          <label key={option} className="flex items-center">
                            <input
                              type="radio"
                              name="riskQuestion2"
                              value={option}
                              checked={formData.riskQuestion2 === option}
                              onChange={(e) => handleInputChange('riskQuestion2', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                          {option}
                                        </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Question 3 */}
                    <div>
                      <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        Is this deviation a significant quality system failure that could go undetected and/or a significant potential withholding of information that may constitute fraud, misrepresentation or falsification or products or data give rise to the potential to harm the end user? <span className="text-red-500">*</span>
                      </div>
                      <div className="flex gap-6">
                        {['yes', 'no'].map((option) => (
                          <label key={option} className="flex items-center">
                            <input
                              type="radio"
                              name="riskQuestion3"
                              value={option}
                              checked={formData.riskQuestion3 === option}
                              onChange={(e) => handleInputChange('riskQuestion3', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                          {option}
                                        </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Question 4 */}
                    <div>
                      <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        Is this deviation comprised of several related deviations, none of which on their own would be classified "critical" but when considered in totality are a critical deficiency or system(s) failure that presents a risk of harm to patients? <span className="text-red-500">*</span>
                      </div>
                      <div className="flex gap-6">
                        {['yes', 'no'].map((option) => (
                          <label key={option} className="flex items-center">
                            <input
                              type="radio"
                              name="riskQuestion4"
                              value={option}
                              checked={formData.riskQuestion4 === option}
                              onChange={(e) => handleInputChange('riskQuestion4', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                          {option}
                                        </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Local auto classification */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Local auto classification
                    </h4>
                  </div>

                  <div className="p-8">
                    <div>
                      <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Is this classified as "auto minor" based on the local SOP? <span className="text-red-500">*</span>
                      </label>
                      <div className="flex gap-6">
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="localClassification"
                            value="yes"
                            checked={formData.localClassification === 'yes'}
                            onChange={(e) => handleInputChange('localClassification', e.target.value)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                          />
                          <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  Yes
                                      </span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="localClassification"
                            value="no"
                            checked={formData.localClassification === 'no'}
                            onChange={(e) => handleInputChange('localClassification', e.target.value)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                          />
                          <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  No
                                      </span>
                        </label>
                        <label className="flex items-center">
                          <input
                            type="radio"
                            name="localClassification"
                            value="not-applicable"
                            checked={formData.localClassification === 'not-applicable'}
                            onChange={(e) => handleInputChange('localClassification', e.target.value)}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                          />
                          <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                  Not applicable
                                      </span>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* RPN calculation */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      RPN calculation
                    </h4>
                  </div>

                  <div className="p-8 space-y-8">
                    <div className="text-sm text-gray-600 dark:text-gray-400 mb-6">
                      Once this RPN form has been completed, support as a PDF and attach as a supporting document in response to a PDF or review as a PDF in the applicable deviation record in Trackwise when ready.
                    </div>

                    {/* Severity level */}
                    <div>
                      <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Severity level - what are the consequences of the deviation? <span className="text-red-500">*</span>
                      </label>
                      <div className="space-y-3">
                        {[
                          { value: 'high', label: 'High (6)' },
                          { value: 'medium', label: 'Medium (2)' },
                          { value: 'low', label: 'Low (1)' },
                        ].map((option) => (
                          <label key={option.value} className="flex items-center">
                            <input
                              type="radio"
                              name="severityLevel"
                              value={option.value}
                              checked={formData.severityLevel === option.value}
                              onChange={(e) => handleInputChange('severityLevel', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                          {option.label}
                                        </span>
                          </label>
                        ))}
                      </div>

                      {/* Additional details */}
                      <div className="mt-4">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Additional details
                        </label>
                        <textarea
                          value={formData.severityAdditionalDetails}
                          onChange={(e) => handleInputChange('severityAdditionalDetails', e.target.value)}
                          className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                          rows={3}
                          placeholder="Please provide any additional detail on the severity level"
                        />
                      </div>
                    </div>

                    {/* Detection */}
                    <div>
                      <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Detection - what is the likelihood that the deviation is detected? <span className="text-red-500">*</span>
                      </label>
                      <div className="space-y-3">
                        {[
                          { value: 'high', label: 'High (1)' },
                          { value: 'medium', label: 'Medium (3)' },
                          { value: 'low', label: 'Low (10)' },
                        ].map((option) => (
                          <label key={option.value} className="flex items-center">
                            <input
                              type="radio"
                              name="detectionLevel"
                              value={option.value}
                              checked={formData.detectionLevel === option.value}
                              onChange={(e) => handleInputChange('detectionLevel', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                          {option.label}
                                        </span>
                          </label>
                        ))}
                      </div>

                      {/* Additional details */}
                      <div className="mt-4">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Additional details
                        </label>
                        <textarea
                          value={formData.detectionAdditionalDetails}
                          onChange={(e) => handleInputChange('detectionAdditionalDetails', e.target.value)}
                          className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                          rows={3}
                          placeholder="Please provide any additional detail on the severity level"
                        />
                      </div>
                    </div>

                    {/* Occurrence */}
                    <div>
                      <label className="block text-sm font-medium text-gray-900 dark:text-gray-100 mb-3">
                        Occurrence - how often does this deviation occur? (Note: occurrence limits below are guidance and if the judgement of the site/quality representative considers the occurrence rate to be different, justification MUST be provided in the record) <span className="text-red-500">*</span>
                      </label>
                      <div className="space-y-3">
                        {[
                          { value: 'high', label: 'High (5)' },
                          { value: 'medium', label: 'Medium (2)' },
                          { value: 'low', label: 'Low (1)' },
                        ].map((option) => (
                          <label key={option.value} className="flex items-center">
                            <input
                              type="radio"
                              name="occurrenceLevel"
                              value={option.value}
                              checked={formData.occurrenceLevel === option.value}
                              onChange={(e) => handleInputChange('occurrenceLevel', e.target.value)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                            />
                            <span className="ml-2 text-sm text-gray-700 dark:text-gray-300">
                                          {option.label}
                                        </span>
                          </label>
                        ))}
                      </div>

                      {/* Additional details */}
                      <div className="mt-4">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                          Additional details
                        </label>
                        <textarea
                          value={formData.occurrenceAdditionalDetails}
                          onChange={(e) => handleInputChange('occurrenceAdditionalDetails', e.target.value)}
                          className="w-full rounded-md border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                          rows={3}
                          placeholder="Please provide any additional detail on the severity level"
                        />
                      </div>
                    </div>

                    {/* Calculation and Leveling */}
                    <div>
                      <div className="flex items-center gap-2 mb-4">
                        <svg className="h-4 w-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                        </svg>
                        <span className="text-xs font-medium text-gray-900 dark:text-gray-100">
                                Calculation and leveling
                                    </span>
                      </div>

                      <div className="overflow-hidden border border-gray-200 dark:border-gray-600 rounded-lg">
                        {/* Table Header */}
                        <div className="bg-gray-50 dark:bg-gray-700 px-4 py-2 border-b border-gray-200 dark:border-gray-700">
                          <div className="grid grid-cols-4 gap-4 text-xs font-medium text-gray-700 dark:text-gray-300">
                            <div>RPN Score = (Severity x Detection x Occurrence)</div>
                            <div>If RPN score is &gt; 59 = <span className="text-red-600 font-bold">critical</span></div>
                            <div>If RPN score is 15-59 = <span className="text-yellow-600 font-bold">major</span></div>
                            <div>If RPN score is &lt; 15 = <span className="text-green-600 font-bold">minor</span></div>
                          </div>
                        </div>

                        {/* Table Content */}
                        <div className="p-4 bg-white dark:bg-gray-900">
                          <div className="grid grid-cols-4 gap-4 text-xs">
                            <div>
                              <div className="text-gray-600 dark:text-gray-400 mb-1">
                                {(() => {
                                  const severityScore = formData.severityLevel === 'high' ? 6 : formData.severityLevel === 'medium' ? 2 : formData.severityLevel === 'low' ? 1 : 0;
                                  const detectionScore = formData.detectionLevel === 'high' ? 1 : formData.detectionLevel === 'medium' ? 3 : formData.detectionLevel === 'low' ? 10 : 0;
                                  const occurrenceScore = formData.occurrenceLevel === 'high' ? 5 : formData.occurrenceLevel === 'medium' ? 2 : formData.occurrenceLevel === 'low' ? 1 : 0;
                                  return `${severityScore} x ${detectionScore} x ${occurrenceScore} = ${severityScore * detectionScore * occurrenceScore}`;
                                })()}
                              </div>
                            </div>
                            <div className="text-center">
                              {/* Empty - no content */}
                            </div>
                            <div className="text-center">
                              {/* Empty - no content */}
                            </div>
                            <div className="text-center">
                              {/* Your score section */}
                              <div className="flex items-center justify-center gap-2">
                                            <span className="text-xs text-gray-900 dark:text-gray-100">
                                        Your score:
                                            </span>
                                <div className={`inline-flex items-center ${getRPNClassificationInfo().bgColor} border ${getRPNClassificationInfo().borderColor} rounded px-2 py-1`}>
                                  {(() => {
                                    const info = getRPNClassificationInfo();
                                    if (info.classification === 'minor') {
                                      return <span className="text-green-600">✓</span>;
                                    } else if (info.classification === 'major') {
                                      return (
                                        <svg className="w-3 h-3 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
                                          <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                        </svg>
                                      );
                                    } else if (info.classification === 'critical') {
                                      return (
                                        <svg className="w-3 h-3 text-red-600" fill="currentColor" viewBox="0 20">
                                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                        </svg>
                                      );
                                    } else {
                                      return <span className="text-green-600">✓</span>;
                                    }
                                  })()}
                                  <span className={`ml-1 text-xs ${getRPNClassificationInfo().color} capitalize font-medium`}>
                                                {getRPNClassificationInfo().classification || 'Minor'}
                                              </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Confirm RPN classification */}
                    <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-lg p-6">
                      <h5 className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-4">
                        Confirm RPN classification
                      </h5>

                      <div className="mb-4">
                        <div className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                          Based on the information provided, the deviation classification is <strong className={getRPNClassificationInfo().color}>{getRPNClassificationInfo().classification || 'not calculated'}</strong>. Does the team/committee agreed on this classification? <span className="text-red-500">*</span>
                        </div>
                        <div className="flex gap-6">
                          {['yes', 'no'].map((option) => (
                            <label key={option} className="flex items-center">
                              <input
                                type="radio"
                                name="teamCommitteeAgreement"
                                value={option}
                                checked={formData.teamCommitteeAgreement === option}
                                onChange={(e) => handleInputChange('teamCommitteeAgreement', e.target.value)}
                                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 dark:border-gray-600"
                              />
                              <span className="ml-2 text-sm text-gray-700 dark:text-gray-300 capitalize">
                                            {option}
                                          </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons for Step 2 */}
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-between">
                  <button
                    type="button"
                    disabled={false} //{shouldDisableFormElements()}
                    className={`px-4 py-2 text-sm font-medium border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                      shouldDisableFormElements()
                        ? 'text-gray-400 bg-gray-100 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                        : 'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600'
                    }`}
                  >
                    Save
                  </button>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => handleStepNavigation(1)}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                    >
                      Back to {getPreviousStepLabel(currentStep)}
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting || !canAccessStep(3)}
                      className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                        isSubmitting || !canAccessStep(3)
                          ? 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                          : 'text-white bg-blue-600 hover:bg-blue-700'
                      }`}
                    >
                      {isSubmitting ? (
                        <>
                          <span className="inline-block animate-spin mr-2">⌛</span>
                          Submitting...
                        </>
                      ) : (
                        `Continue to ${getNextStepLabel(currentStep)}`
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </FormCard>
      )}
    </div>
  )
}

export default DeviationFormStepTwo;