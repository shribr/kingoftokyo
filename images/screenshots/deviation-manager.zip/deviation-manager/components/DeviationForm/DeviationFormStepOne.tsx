import React from 'react';
import {
  useDeviationFormContext,
} from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';
import {
  FormField,
  TextAreaField,
} from '~/features/deviation-manager/components';
import FormCard from '~/features/deviation-manager/components/FormCard';
import RelevantDeviationSearchBox from '~/features/deviation-manager/components/RelevantDeviationSearchBox';

type IntakeStepProps = {
  handleCancel: () => void;
}

const IntakeStep: React.FC<IntakeStepProps> = ({ handleCancel }) => {
  const {
    // State
    formData,
    currentStep,
    filteredTrackwiseRecords,
    showTrackwiseDropdown,
    isSubmitting,
    setFormData,

    // Validations
    canAccessStep,

    // Navigation
    shouldDisableFormElements,

    // Handlers
    handleInputChange,
    handleTrackwiseSearch,
    handleTrackwiseSelect,
    handleSubmit,
    handleSubmitStep1,

    // Methods
    getNextStepLabel,
  } = useDeviationFormContext();

  return (
    <div>
      {/* Step Content */}
      {currentStep === 1 && (
        /* Step 1: Intake - Existing content */
        <FormCard>
          <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
            {shouldDisableFormElements() && (
              <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
            )}
            <form onSubmit={handleSubmitStep1}>
              <div className="space-y-6">
                {/* Select existing record section */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Select existing record from Trackwise
                    </h4>
                  </div>

                  {/* Content area with nested container */}
                  <div className="p-6">
                    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-600">
                      <div className="flex items-center space-x-2 mb-3">
                        <svg className="h-5 w-5 text-gray-600 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Select existing record
                                  </span>
                      </div>

                      <div className="text-xs text-gray-500 mb-4">
                        Select an existing Trackwise record that was already opened in Trackwise to populate the intake form below.
                      </div>

                      <div className="space-y-3 relative">
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300">
                          Trackwise record
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500 pr-8"
                            placeholder="Search for existing Trackwise record..."
                            onChange={(e) => handleTrackwiseSearch(e.target.value)}
                          />
                          <div className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none">
                            <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                            </svg>
                          </div>
                        </div>

                        {/* Trackwise Search Results Dropdown */}
                        {showTrackwiseDropdown && filteredTrackwiseRecords.length > 0 && (
                          <div className="absolute top-full left-0 z-10 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600 rounded-md shadow-lg max-h-60 overflow-y-auto mt-1 min-w-80 w-auto max-w-md">
                            {filteredTrackwiseRecords.map((record) => (
                              <button
                                key={record.id}
                                type="button"
                                onClick={() => handleTrackwiseSelect(record)}
                                className="w-full text-left px-4 py-3 hover:bg-gray-50 dark:hover:bg-gray-700 border-b border-gray-100 dark:border-gray-700 last:border-b-0 whitespace-nowrap"
                              >
                                <div className="font-medium text-sm text-gray-900 dark:text-gray-100">
                                  {record.id}
                                </div>
                                <div className="text-sm text-gray-600 dark:text-gray-400 truncate">
                                  {record.name}
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-500 truncate">
                                  {record.department} • Created by {record.createdBy}
                                </div>
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Manually Enter Section */}
                <div>
                  {/* Manually Enter Header with light gray background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Manually enter
                    </h4>
                  </div>

                  <div className="p-8 space-y-8">
                    {/* Row 1: Deviation Name and What defect was observed */}
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                      <FormField
                        id="deviationName"
                        label="Deviation Name"
                        value={formData.deviationName}
                        onChange={(value) => handleInputChange('deviationName', value)}
                        placeholder="Auto populated from Trackwise or manually enter a name of your choice"
                        required
                      />

                      <FormField
                        id="whatDefectObserved"
                        label="What defect was observed?"
                        value={formData.whatDefectObserved}
                        onChange={(value) => handleInputChange('whatDefectObserved', value)}
                        placeholder="What was the deviation for? What is out of specification?"
                        required
                      />
                    </div>

                    {/* Row 2: Object and Specifications */}
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                      <FormField
                        id="objectDefectObserved"
                        label="In which object was the defect observed?"
                        value={formData.objectDefectObserved}
                        onChange={(value) => handleInputChange('objectDefectObserved', value)}
                        placeholder="For example, what product, material, equipment, etc. is impacted?"
                        required
                      />

                      <FormField
                        id="wantSpecifications"
                        label="What were the specifications or requirements?"
                        value={formData.wantSpecifications}
                        onChange={(value) => handleInputChange('wantSpecifications', value)}
                        placeholder="What were the specifications or requirements?"
                        required
                      />
                    </div>

                    {/* Row 3: Location, Date, Time of Occurrence (3 columns) */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      <FormField
                        id="issueOccurred"
                        label="Where did the issue occur?"
                        value={formData.issueOccurred}
                        onChange={(value) => handleInputChange('issueOccurred', value)}
                        placeholder="Physical location or area where the issue occurred"
                        required
                      />

                      <FormField
                        id="dateOccurrence"
                        label="Date of occurrence"
                        type="date"
                        value={formData.dateOccurrence}
                        onChange={(value) => handleInputChange('dateOccurrence', value)}
                        required
                      />

                      <div>
                        <label className="block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Time of occurrence
                        </label>
                        <input
                          id="timeOccurrence"
                          type="time"
                          value={formData.timeOccurrence}
                          onChange={(e) => handleInputChange('timeOccurrence', e.target.value)}
                          className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
                          aria-label="Time of occurrence"
                          required
                        />
                      </div>
                    </div>

                    {/* Row 4: Process Step, Date Detection, Impact (3 columns) */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      <FormField
                        id="processStepDefect"
                        label="What process step did this occur at?"
                        value={formData.processStepDefect}
                        onChange={(value) => handleInputChange('processStepDefect', value)}
                        placeholder="What step in the batch record or SOP?"
                        required
                      />

                      <FormField
                        id="dateDetection"
                        label="Date of detection"
                        type="date"
                        value={formData.dateDetection}
                        onChange={(value) => handleInputChange('dateDetection', value)}
                        required
                      />

                      <FormField
                        id="impactOfIssue"
                        label="What is the impact of the issue?"
                        value={formData.impactOfIssue}
                        onChange={(value) => handleInputChange('impactOfIssue', value)}
                        placeholder="E.g. batch over limit"
                        required
                      />
                    </div>

                    {/* Row 5: Who was involved and Who observed (2 columns) */}
                    <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                      <FormField
                        id="whoInvolvedProcess"
                        label="Who was involved in the process?"
                        value={formData.whoInvolvedProcess}
                        onChange={(value) => handleInputChange('whoInvolvedProcess', value)}
                        placeholder="People who performed the process"
                        required
                      />

                      <FormField
                        id="whoObservedIssue"
                        label="Who observed the issue?"
                        value={formData.whoObservedIssue}
                        onChange={(value) => handleInputChange('whoObservedIssue', value)}
                        placeholder="People who witnessed the process"
                        required
                      />
                    </div>

                    {/* Row 6: Process Description (1 column) */}
                    <div className="space-y-6">
                      <TextAreaField
                        id="processDescription"
                        label="Provide a brief description of the process involved"
                        value={formData.processDescription}
                        onChange={(value) => handleInputChange('processDescription', value)}
                        placeholder="What happened?"
                        required
                      />
                    </div>

                    {/* Row 7: Immediate Actions (1 column) */}
                    <div className="space-y-6">
                      <TextAreaField
                        id="immediateActions"
                        label="What immediate actions were taken?"
                        value={formData.immediateActions}
                        onChange={(value) => handleInputChange('immediateActions', value)}
                        placeholder="What has been done to adopt Has anything been put on hold?"
                        required
                      />
                    </div>

                    {/* Row 8: Materials and Equipment (1 column) */}
                    <div className="space-y-6">
                      <TextAreaField
                        id="materialsToolsEquipment"
                        label="List the materials, tools and equipment used in the process"
                        value={formData.materialsToolsEquipment}
                        onChange={(value) => handleInputChange('materialsToolsEquipment', value)}
                        placeholder="List the materials, tools and equipment used in the process"
                        required
                      />
                    </div>

                    {/* Upload supporting documents */}
                    <div className="space-y-4">
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Upload supporting documents
                      </label>
                      <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                        <div className="space-y-2">
                          <div className="mx-auto h-12 w-12 text-gray-400">
                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                            </svg>
                          </div>
                          <div className="text-sm text-gray-600 dark:text-gray-400">
                                      <span className="font-medium text-blue-600 hover:text-blue-500 cursor-pointer">
                                    Drag & drop or browse files
                                      </span>
                          </div>
                          <div className="text-xs text-gray-500">
                            Supported file types: pdf • docx • xlsx • csv • Max file size: 25 MB
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Similar occurrence deviations */}
                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                          Similar occurrence deviations
                        </label>
                        <div className="text-gray-400">
                          <svg className="h-4 w-4" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                          </svg>
                        </div>
                      </div>
                      <div className="border border-gray-300 dark:border-gray-600 rounded-lg p-4">
                        <div className="flex items-center space-x-2 mb-3">
                          <svg className="h-5 w-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                          </svg>
                          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Similar deviations assistant</span>
                        </div>
                        <div className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                          Search for similar deviations that may have occurred in the past to help identify patterns and reference existing investigations.
                        </div>
                        <div className="w-full">
                          <RelevantDeviationSearchBox
                            placeholder="Search similar deviations"
                            startDate="2024-01-01"
                            limit={10}
                            onSelect={(deviation) => {
                              // Handle selection - you can populate form fields or show details
                              console.log('Selected similar deviation:', deviation);
                              // Example: optionally populate deviation name if user confirms
                              if (confirm(`Use "${deviation.title || deviation.description}" as reference for this deviation?`)) {
                                setFormData(prev => ({
                                  ...prev,
                                  deviationName: deviation.title || deviation.description || prev.deviationName,
                                }));
                              }
                            }}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons for Step 1 */}
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-between">
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting || !canAccessStep(2)}
                    className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                      isSubmitting || !canAccessStep(2)
                        ? 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                        : 'text-white bg-blue-600 hover:bg-blue-700'
                    }`}
                  >
                    {isSubmitting ? (
                      <>
                        <span className="inline-block animate-spin mr-2">⌛</span>
                        Submitting...
                      </>
                    ) : (
                      `Continue to ${getNextStepLabel(currentStep)}`
                    )}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </FormCard>
      )}
    </div>
  );
};

export default IntakeStep;
