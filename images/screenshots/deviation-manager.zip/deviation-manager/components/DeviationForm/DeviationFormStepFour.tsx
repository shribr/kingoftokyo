import {
  DeviationFormProvider,
  useDeviationFormContext,
} from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';
import { FormCard } from '~/features/deviation-manager/components';

const DeviationFormStepFour = () => {
  const {
    // State
    currentStep,

    // Navigation
    handleStepNavigation,
    shouldDisableFormElements,

    // Handlers

    // Methods
    getPreviousStepLabel,
  } = useDeviationFormContext();

  return (
    <div>
      {currentStep === 4 && (
        /* Step 4: CAPA & conclusion - Placeholder */
        <FormCard>
          <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
            {shouldDisableFormElements() && (
              <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
            )}
            <div className="p-8 text-center">
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                CAPA & Conclusion
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                This step will be implemented in the future.
              </p>
              <div className="mt-6 flex justify-center gap-4">
                <button
                  type="button"
                  onClick={() => handleStepNavigation(3)}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Back to {getPreviousStepLabel(currentStep)}
                </button>
                <button
                  type="submit"
                  disabled={shouldDisableFormElements()}
                  className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md ${
                    shouldDisableFormElements()
                      ? 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                      : 'text-white bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  Complete Deviation Record
                </button>
              </div>
            </div>
          </div>
        </FormCard>
      )}
    </div>
  );
};

export default DeviationFormStepFour;