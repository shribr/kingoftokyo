import { TrackwiseRecord } from '~/features/deviation-manager/components/utils/data';

export type FormData = {
  deviationId: string

  // Header fields
  deviationName: string
  site: string
  department: string
  assignee: string
  createdOn: string
  stage: string

  // Selected Trackwise record
  selectedTrackwiseRecord: TrackwiseRecord | null

  // Intake step fields
  trackwiseSearchQuery: string
  whatDefectObserved: string
  objectDefectObserved: string
  wantSpecifications: string
  issueOccurred: string
  dateOccurrence: string
  timeOccurrence: string
  dateDetection: string
  impactOfIssue: string
  processStepDefect: string
  whoInvolvedProcess: string
  whoObservedIssue: string
  processDescription: string
  immediateActions: string
  materialsToolsEquipment: string
  supportingDocuments: string[]

  // Step 2: Initial Review & Impact fields
  riskQuestion1: 'yes' | 'no' | ''
  riskQuestion2: 'yes' | 'no' | ''
  riskQuestion3: 'yes' | 'no' | ''
  riskQuestion4: 'yes' | 'no' | ''
  severityLevel: 'high' | 'medium' | 'low' | ''
  severityAdditionalDetails: string
  detectionLevel: 'high' | 'medium' | 'low' | ''
  detectionAdditionalDetails: string
  occurrenceLevel: 'high' | 'medium' | 'low' | ''
  occurrenceAdditionalDetails: string
  rpnScore: string
  localClassification: 'yes' | 'no' | 'not-applicable' | ''
  deviationClassification: 'critical' | 'major' | 'minor' | ''
  teamCommitteeAgreement: 'yes' | 'no' | ''

  // Other step fields
  shortDescription: string
  generalDescription: string
  riskAnalysis: string
  impactAnalysis: string
  finalAnalysis: string
}

export const DEFAULT_FORM_DATA: FormData = {
  deviationId: '',

  // Header fields
  deviationName: '',
  site: '',
  department: '',
  assignee: '',
  createdOn: new Date().toISOString(), // Use full ISO string for consistency with string type
  stage: 'Intake',

  // Selected Trackwise record
  selectedTrackwiseRecord: null,

  // Intake step fields
  trackwiseSearchQuery: '',
  whatDefectObserved: '',
  objectDefectObserved: '',
  wantSpecifications: '',
  issueOccurred: '',
  dateOccurrence: '',
  timeOccurrence: '',
  dateDetection: '',
  impactOfIssue: '',
  processStepDefect: '',
  whoInvolvedProcess: '',
  whoObservedIssue: '',
  processDescription: '',
  immediateActions: '',
  materialsToolsEquipment: '',
  supportingDocuments: [],

  // Step 2: Initial Review & Impact fields
  riskQuestion1: '',
  riskQuestion2: '',
  riskQuestion3: '',
  riskQuestion4: '',
  severityLevel: '',
  severityAdditionalDetails: '',
  detectionLevel: '',
  detectionAdditionalDetails: '',
  occurrenceLevel: '',
  occurrenceAdditionalDetails: '',
  rpnScore: '',
  localClassification: '',
  deviationClassification: '',
  teamCommitteeAgreement: '',

  // Other step fields
  shortDescription: '',
  generalDescription: '',
  riskAnalysis: '',
  impactAnalysis: '',
  finalAnalysis: '',
}