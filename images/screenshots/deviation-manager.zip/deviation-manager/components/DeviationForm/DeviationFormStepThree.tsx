import { FormCard, TextAreaField } from '~/features/deviation-manager/components';
import {
  DeviationFormProvider,
  useDeviationFormContext,
} from '~/features/deviation-manager/components/DeviationForm/DeviationFormContext';

const DeviationFormStepThree = () => {
  const {
    // State
    formData,
    currentStep,
    isSubmitting,

    // Validations
    canAccessStep,

    // Navigation
    handleStepNavigation,
    shouldDisableFormElements,

    // Handlers
    handleInputChange,
    handleSubmitStep3,

    // Methods
    getNextStepLabel,
    getPreviousStepLabel,
  } = useDeviationFormContext();

  return (
    <div>
      {currentStep === 3 && (
        /* Step 3: Impact Analysis and Risk Analysis */
        <FormCard>
          <div className={`relative ${shouldDisableFormElements() ? 'pointer-events-none opacity-75' : ''}`}>
            {shouldDisableFormElements() && (
              <div className="absolute inset-0 bg-gray-50/50 dark:bg-gray-800/50 z-10 rounded-lg" />
            )}
            <form onSubmit={handleSubmitStep3}>
              <div className="space-y-6">
                {/* Short Description section */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Short Description
                    </h4>
                  </div>

                  <div className="p-8">
                    <TextAreaField
                      id="shortDescription"
                      label=""
                      value={formData.shortDescription}
                      onChange={(value) => handleInputChange('shortDescription', value)}
                      placeholder="This is a brief summary of the deviation, typically one or two sentences."
                      rows={4}
                    />
                  </div>
                </div>

                {/* Description section */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Description
                    </h4>
                  </div>

                  <div className="p-8">
                    <TextAreaField
                      id="generalDescription"
                      label=""
                      value={formData.generalDescription}
                      onChange={(value) => handleInputChange('generalDescription', value)}
                      placeholder="This is a detailed account of the deviation, including what happened, when it happened, where it happened, and any other relevant details."
                      rows={6}
                    />
                  </div>
                </div>

                {/* Investigation & Root Cause Analysis section */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Investigation & Root Cause Analysis
                    </h4>
                  </div>

                  <div className="p-8">
                    <TextAreaField
                      id="riskAnalysis"
                      label=""
                      value={formData.riskAnalysis}
                      onChange={(value) => handleInputChange('riskAnalysis', value)}
                      placeholder="This section should detail the investigation process, findings, and the root cause of the deviation."
                      rows={6}
                    />
                  </div>
                </div>

                {/* Impact Analysis section */}
                <div>
                  {/* Gray header background */}
                  <div className="bg-gray-50 dark:bg-gray-800 px-6 py-3 border-b border-gray-200 dark:border-gray-700">
                    <h4 className="text-md font-medium text-gray-900 dark:text-gray-100">
                      Impact Analysis
                    </h4>
                  </div>

                  <div className="p-8">
                    <TextAreaField
                      id="impactAnalysis"
                      label=""
                      value={formData.impactAnalysis}
                      onChange={(value) => handleInputChange('impactAnalysis', value)}
                      placeholder="This section should analyze the impact of the deviation on product quality, patient safety, regulatory compliance, and business operations."
                      rows={6}
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons for Step 3 */}
              <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800 rounded-b-lg border-t border-gray-200 dark:border-gray-700">
                <div className="flex justify-between">
                  <button
                    type="button"
                    disabled={shouldDisableFormElements()}
                    className={`px-4 py-2 text-sm font-medium border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                      shouldDisableFormElements()
                        ? 'text-gray-400 bg-gray-100 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                        : 'text-gray-700 bg-white hover:bg-gray-50 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600'
                    }`}
                  >
                    Save
                  </button>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => handleStepNavigation(2)}
                      className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-600"
                    >
                      Back to {getPreviousStepLabel(currentStep)}
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting || !canAccessStep(4)}
                      className={`px-4 py-2 text-sm font-medium border border-transparent rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
                        isSubmitting || !canAccessStep(4)
                          ? 'text-gray-400 bg-gray-300 cursor-not-allowed dark:bg-gray-600 dark:text-gray-500'
                          : 'text-white bg-blue-600 hover:bg-blue-700'
                      }`}
                    >
                      {isSubmitting ? (
                        <>
                          <span className="inline-block animate-spin mr-2">⌛</span>
                          Submitting...
                        </>
                      ) : (
                        `Continue to ${getNextStepLabel(currentStep)}`
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </FormCard>
      )}
    </div>
  )
}

export default DeviationFormStepThree;