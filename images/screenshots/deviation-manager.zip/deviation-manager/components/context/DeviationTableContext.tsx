import React, { createContext, useContext, ReactNode } from 'react'
import { useDeviationTable } from '../utils/hooks';
import { DeviationTableData } from '~/features/deviation-manager/components/utils/data';

interface DeviationTableContextType {
  deviations: DeviationTableData[]
  pagination: {
    page: number
    totalPages: number
    pageSize: number // Add pageSize to context
  }
  filters: {
    search: string
    site: string
    department: string
    classification: string
    stage: string
  }
  loading: boolean
  handlePageChange: (page: number) => void
  handlePageSizeChange: (pageSize: number) => void // Add page size handler
  handleSearch: (search: string) => void
  handleFilter: (key: string, value: string) => void
  handleCreateRecord?: () => void
}

const DeviationTableContext = createContext<DeviationTableContextType | undefined>(undefined)

export const useTableContext = () => {
  const context = useContext(DeviationTableContext)
  if (!context) {
    throw new Error('useTableContext must be used within a TableProvider')
  }
  return context
}

interface TableProviderProps {
  children: ReactNode
  onCreateRecord?: () => void
}

export const TableProvider: React.FC<TableProviderProps> = ({ children, onCreateRecord }) => {
  const tableData = useDeviationTable()

  // Deviations and loading state now come from useDeviationTable
  const contextValue: DeviationTableContextType = {
    deviations: tableData.deviations,
    pagination: tableData.pagination,
    filters: tableData.filters,
    loading: tableData.loading,
    handlePageChange: tableData.handlePageChange,
    handlePageSizeChange: tableData.handlePageSizeChange,
    handleSearch: tableData.handleSearch,
    handleFilter: tableData.handleFilter,
    handleCreateRecord: onCreateRecord
  }

  return (
    <DeviationTableContext.Provider value={contextValue}>
      {children}
    </DeviationTableContext.Provider>
  )
}

export default TableProvider
