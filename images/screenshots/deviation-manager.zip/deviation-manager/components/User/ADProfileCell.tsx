// ADProfileCell component (extracted from Table)
interface ADProfileCellProps {
  user: {
    name: string
    avatar?: string
    status?: 'online' | 'away' | 'busy' | 'offline'
  }
}

const ADProfileCell: React.FC<ADProfileCellProps> = ({ user }) => {
  const getStatusColor = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'bg-green-500';
      case 'away': return 'bg-yellow-500';
      case 'busy': return 'bg-red-500';
      case 'offline': return 'bg-gray-400';
      default: return 'bg-gray-400';
    }
  };

  const getStatusTitle = (status: string = 'offline') => {
    switch (status) {
      case 'online': return 'Online';
      case 'away': return 'Away';
      case 'busy': return 'Busy';
      case 'offline': return 'Offline';
      default: return 'Unknown';
    }
  };

  return (
    <div className="flex items-center gap-2 min-w-0">
      <div className="relative flex-shrink-0">
        <div className="h-8 w-8 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center dark:bg-gray-600 dark:border-gray-500">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" className="text-gray-600 dark:text-gray-300">
            <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm0 2c-4.418 0-8 2.239-8 5v1h16v-1c0-2.761-3.582-5-8-5z"/>
          </svg>
        </div>
        <div
          className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white dark:border-gray-800 ${getStatusColor(user.status)}`}
          title={getStatusTitle(user.status)}
        />
      </div>
      <span className="text-xs text-gray-900 truncate dark:text-gray-100">{user.name}</span>
    </div>
  );
};

export default ADProfileCell;