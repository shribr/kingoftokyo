import React from 'react'

export interface FormFieldProps {
  label: string
  id: string
  type?: 'text' | 'date' | 'email' | 'tel' | 'url' | 'password'
  value: string
  onChange: (value: string) => void
  required?: boolean
  placeholder?: string
  className?: string
  disabled?: boolean
}

export interface TextAreaFieldProps {
  label: string
  id: string
  value: string
  onChange: (value: string) => void
  required?: boolean
  placeholder?: string
  rows?: number
  className?: string
  disabled?: boolean
}

export interface SelectFieldProps {
  label: string
  id: string
  value: string
  onChange: (value: string) => void
  options: Array<{ value: string; label: string }>
  required?: boolean
  className?: string
  disabled?: boolean
}

const baseInputClasses = "w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500"
const baseLabelClasses = "block text-xs font-medium text-gray-700 dark:text-gray-300 mb-1"

export const FormField: React.FC<FormFieldProps> = ({
  label,
  id,
  type = 'text',
  value,
  onChange,
  required = false,
  placeholder,
  className = '',
  disabled = false
}) => {
  return (
    <div className={className}>
      <label htmlFor={id} className={baseLabelClasses}>
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        className={`${baseInputClasses} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      />
    </div>
  )
}

export const TextAreaField: React.FC<TextAreaFieldProps> = ({
  label,
  id,
  value,
  onChange,
  required = false,
  placeholder,
  rows = 4,
  className = '',
  disabled = false
}) => {
  return (
    <div className={className}>
      <label htmlFor={id} className={baseLabelClasses}>
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <textarea
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        rows={rows}
        className={`${baseInputClasses} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      />
    </div>
  )
}

export const SelectField: React.FC<SelectFieldProps> = ({
  label,
  id,
  value,
  onChange,
  options,
  required = false,
  className = '',
  disabled = false
}) => {
  return (
    <div className={className}>
      <label htmlFor={id} className={baseLabelClasses}>
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        required={required}
        disabled={disabled}
        className={`${baseInputClasses} ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  )
}
