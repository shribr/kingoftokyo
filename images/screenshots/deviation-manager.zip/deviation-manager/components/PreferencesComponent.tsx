import React, { useState, useEffect } from 'react';

interface PreferencesState {
  theme: 'light' | 'dark' | 'auto';
  language: string;
  timezone: string;
  dateFormat: string;
  timeFormat: '12h' | '24h';
  notifications: boolean;
  autoSave: boolean;
  pageSize: number;
  refreshInterval: number;
}

const PreferencesComponent: React.FC = () => {
  const [preferences, setPreferences] = useState<PreferencesState>({
    theme: 'auto',
    language: 'en-US',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    dateFormat: 'MM/DD/YYYY',
    timeFormat: '12h',
    notifications: true,
    autoSave: true,
    pageSize: 25,
    refreshInterval: 30
  });

  // Load preferences from localStorage on mount and initialize theme
  useEffect(() => {
    const savedPreferences = localStorage.getItem('deviationManager_preferences');
    const savedColorTheme = localStorage.getItem('color-theme');
    
    if (savedPreferences) {
      try {
        const parsed = JSON.parse(savedPreferences);
        setPreferences(prev => ({ ...prev, ...parsed }));
      } catch (error) {
        console.warn('Failed to parse saved preferences:', error);
      }
    } else if (savedColorTheme) {
      // If no preferences saved but color-theme exists, sync it
      const themeFromStorage = savedColorTheme === 'dark' ? 'dark' : 'light';
      setPreferences(prev => ({ ...prev, theme: themeFromStorage }));
    }
  }, []);

  // Apply theme to DOM when theme preference changes
  useEffect(() => {
    const applyTheme = (theme: 'light' | 'dark' | 'auto') => {
      if (theme === 'auto') {
        const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (systemPrefersDark) {
          document.documentElement.classList.add('dark');
          localStorage.setItem('color-theme', 'dark');
        } else {
          document.documentElement.classList.remove('dark');
          localStorage.setItem('color-theme', 'light');
        }
      } else if (theme === 'dark') {
        document.documentElement.classList.add('dark');
        localStorage.setItem('color-theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('color-theme', 'light');
      }
    };

    applyTheme(preferences.theme);
  }, [preferences.theme]);

  // Save preferences to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('deviationManager_preferences', JSON.stringify(preferences));
  }, [preferences]);

  const updatePreference = <K extends keyof PreferencesState>(
    key: K,
    value: PreferencesState[K]
  ) => {
    setPreferences(prev => ({ ...prev, [key]: value }));
  };

  const resetToDefaults = () => {
    if (confirm('Reset all preferences to default values?')) {
      const defaults: PreferencesState = {
        theme: 'auto',
        language: 'en-US',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        dateFormat: 'MM/DD/YYYY',
        timeFormat: '12h',
        notifications: true,
        autoSave: true,
        pageSize: 25,
        refreshInterval: 30
      };
      setPreferences(defaults);
    }
  };

  return (
    <div className="space-y-6">
      {/* Appearance */}
      <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">
          🎨 Appearance
        </h4>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Theme
            </label>
            <select
              value={preferences.theme}
              onChange={(e) => updatePreference('theme', e.target.value as 'light' | 'dark' | 'auto')}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              aria-label="Theme selection"
            >
              <option value="light">Light</option>
              <option value="dark">Dark</option>
              <option value="auto">Auto (System)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Localization */}
      <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">
          🌍 Localization
        </h4>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Language
            </label>
            <select
              value={preferences.language}
              onChange={(e) => updatePreference('language', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              aria-label="Language selection"
            >
              <option value="en-US">English (US)</option>
              <option value="en-GB">English (UK)</option>
              <option value="es-ES">Español</option>
              <option value="fr-FR">Français</option>
              <option value="de-DE">Deutsch</option>
              <option value="ja-JP">日本語</option>
              <option value="zh-CN">中文</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Timezone
            </label>
            <select
              value={preferences.timezone}
              onChange={(e) => updatePreference('timezone', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
              aria-label="Timezone selection"
            >
              <option value="America/New_York">Eastern Time</option>
              <option value="America/Chicago">Central Time</option>
              <option value="America/Denver">Mountain Time</option>
              <option value="America/Los_Angeles">Pacific Time</option>
              <option value="Europe/London">London</option>
              <option value="Europe/Paris">Paris</option>
              <option value="Asia/Tokyo">Tokyo</option>
              <option value="Asia/Shanghai">Shanghai</option>
              <option value={Intl.DateTimeFormat().resolvedOptions().timeZone}>
                System Default ({Intl.DateTimeFormat().resolvedOptions().timeZone})
              </option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Date Format
              </label>
              <select
                value={preferences.dateFormat}
                onChange={(e) => updatePreference('dateFormat', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                aria-label="Date format selection"
              >
                <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                <option value="DD MMM YYYY">DD MMM YYYY</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Time Format
              </label>
              <select
                value={preferences.timeFormat}
                onChange={(e) => updatePreference('timeFormat', e.target.value as '12h' | '24h')}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                aria-label="Time format selection"
              >
                <option value="12h">12 Hour (AM/PM)</option>
                <option value="24h">24 Hour</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Behavior */}
      <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">
          ⚙️ Behavior
        </h4>
        
        <div className="space-y-4">
          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={preferences.notifications}
              onChange={(e) => updatePreference('notifications', e.target.checked)}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <div>
              <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                Enable notifications
              </span>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Show browser notifications for important updates
              </p>
            </div>
          </label>

          <label className="flex items-center space-x-3">
            <input
              type="checkbox"
              checked={preferences.autoSave}
              onChange={(e) => updatePreference('autoSave', e.target.checked)}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <div>
              <span className="text-sm text-gray-700 dark:text-gray-300 font-medium">
                Auto-save forms
              </span>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Automatically save form data as you type
              </p>
            </div>
          </label>
        </div>
      </div>

      {/* Data & Performance */}
      <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">
          📊 Data & Performance
        </h4>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Items per page: {preferences.pageSize}
            </label>
            <input
              type="range"
              min="10"
              max="100"
              step="5"
              value={preferences.pageSize}
              onChange={(e) => updatePreference('pageSize', parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
              aria-label="Items per page"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>10</span>
              <span>50</span>
              <span>100</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Auto-refresh interval: {preferences.refreshInterval}s
            </label>
            <input
              type="range"
              min="10"
              max="300"
              step="10"
              value={preferences.refreshInterval}
              onChange={(e) => updatePreference('refreshInterval', parseInt(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
              aria-label="Auto-refresh interval"
            />
            <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span>10s</span>
              <span>60s</span>
              <span>300s</span>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4">
        <h4 className="text-md font-medium text-gray-900 dark:text-white mb-3">
          🔧 Actions
        </h4>
        
        <div className="flex gap-3">
          <button
            onClick={resetToDefaults}
            className="px-4 py-2 bg-gray-500 hover:bg-gray-600 text-white rounded-md text-sm transition-colors"
          >
            Reset to Defaults
          </button>
          
          <button
            onClick={() => {
              const blob = new Blob([JSON.stringify(preferences, null, 2)], { type: 'application/json' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'deviation-manager-preferences.json';
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-md text-sm transition-colors"
          >
            Export Settings
          </button>
        </div>
      </div>
    </div>
  );
};

export default PreferencesComponent;
