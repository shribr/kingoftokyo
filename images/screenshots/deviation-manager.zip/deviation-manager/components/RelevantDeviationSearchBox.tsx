import React, { useState, useEffect, useRef } from 'react'
import type { Deviation } from '../services/DeviationManagerService'
import { useSearchRelevantDeviations } from '~/features/deviation-manager/queries/deviationManagerQueries';

interface RelevantDeviationSearchBoxProps {
  onSelect?: (deviation: Deviation) => void
  placeholder?: string
  startDate?: string // Default start date for search
  limit?: number
}

export const RelevantDeviationSearchBox: React.FC<RelevantDeviationSearchBoxProps> = ({ 
  onSelect,
  placeholder = "Search similar deviations",
  startDate = "2024-01-01", // Default to beginning of current year
  limit = 10
}) => {
  const [searchValue, setSearchValue] = useState('')
  const [isOpen, setIsOpen] = useState(false)
  const [debouncedSearch, setDebouncedSearch] = useState('')
  const dropdownRef = useRef<HTMLDivElement>(null)

  // Debounce search input
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchValue)
    }, 500)

    return () => clearTimeout(timer)
  }, [searchValue])

  // Query for relevant deviations
  const { data, isLoading, isError } = useSearchRelevantDeviations(
    {
      text: debouncedSearch,
      start_date: startDate,
      limit
    },
  )

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value
    setSearchValue(value)
    setIsOpen(value.length >= 3) // Show dropdown when we have enough characters
  }

  const handleClear = () => {
    setSearchValue('')
    setDebouncedSearch('')
    setIsOpen(false)
  }

  const handleSelect = (deviation: Deviation) => {
    setSearchValue(deviation.title || deviation.description || '')
    setIsOpen(false)
    onSelect?.(deviation)
  }

  const deviations = data || []

  return (
    <div className="relative" ref={dropdownRef}>
      <div className="input-root relative">
        <label className="input-label" htmlFor="relevant-deviation-search">
          Search Similar Deviations
        </label>
        <div className="relative">
          <input
            type="text"
            id="relevant-deviation-search"
            className="w-full rounded-md border border-gray-300 bg-white px-2.5 py-1.5 text-xs text-gray-900 placeholder:text-gray-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-600 dark:border-gray-600 dark:bg-gray-700 dark:text-gray-100 dark:placeholder:text-gray-500 pr-8"
            placeholder={placeholder}
            value={searchValue}
            onChange={handleChange}
          />
          {isLoading && debouncedSearch.length >= 3 && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <svg className="h-4 w-4 animate-spin text-brand-600" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
            </div>
          )}
          {searchValue && !isLoading && (
            <button
              type="button"
              className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 dark:text-gray-500 dark:hover:text-gray-300"
              onClick={handleClear}
              aria-label="Clear search"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Dropdown Results */}
      {isOpen && (
        <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto dark:bg-gray-700 dark:border-gray-600">
          {isLoading && (
            <div className="px-3 py-2 text-xs text-gray-500 dark:text-gray-400">
              Searching for similar deviations...
            </div>
          )}
          
          {isError && (
            <div className="px-3 py-2 text-xs text-red-600 dark:text-red-400">
              Error searching for deviations. Please try again.
            </div>
          )}
          
          {!isLoading && !isError && deviations.length === 0 && debouncedSearch.length >= 3 && (
            <div className="px-3 py-2 text-xs text-gray-500 dark:text-gray-400">
              No similar deviations found.
            </div>
          )}
          
          {deviations.map((deviation, index) => (
            <button
              key={deviation.id || index}
              type="button"
              className="w-full px-3 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-600 border-b border-gray-100 dark:border-gray-600 last:border-b-0"
              onClick={() => handleSelect(deviation)}
            >
              <div className="text-xs font-medium text-gray-900 dark:text-gray-100 truncate">
                {deviation.title || deviation.description || 'Untitled'}
              </div>
              <div className="text-xs text-gray-500 dark:text-gray-400 truncate">
                {deviation.category || 'N/A'}
              </div>
              {deviation.createdAt && (
                <div className="text-xs text-gray-400 dark:text-gray-500">
                  {new Date(deviation.createdAt).toLocaleDateString()}
                </div>
              )}
            </button>
          ))}
          
          {deviations.length > 0 && (
            <div className="px-3 py-1 text-xs text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-gray-600">
              {deviations.length} similar deviation{deviations.length !== 1 ? 's' : ''} found
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default RelevantDeviationSearchBox