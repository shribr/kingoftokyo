import { SendHorizontal } from 'lucide-react';
import { cn, defaultTextProps } from '~/utils';
import { useLocalize } from '~/hooks';
import { useState } from 'react';
import { Spinner } from '~/components';
export const Assistant = ({
  id,
  onSend,
  isProcessing,
}: {
  id: string;
  onSend: (text: string) => void;
  isProcessing?: boolean;
}) => {
  const localize = useLocalize();
  const [text, setText] = useState('');

  const handleSend = async () => {
    await onSend(text);
    setText('');
  };

  const handleChange = (e) => {
    const { value } = e.target;
    setText(value);
  };

  return (
    <div>
      <label htmlFor={`composer-input-${id}`} className="block text-xs font-medium text-text-primary">
        {localize('assistant_label')}
      </label>
      <div className="flex h-full w-full items-center justify-between gap-2">
        <input
          type="text"
          name={`assistant`}
          value={text}
          className={cn(defaultTextProps, 'w-full resize-none px-3 py-2')}
          placeholder={localize('assistant_input_placeholder')}
          onChange={handleChange}
          disabled={isProcessing}
          id={`composer-input-${id}`}
          autoComplete="off"
        />
        <div className="btn btn-primary h-10">
          <button
            type="button"
            className="relative cursor-pointer px-2"
            onClick={handleSend}
            disabled={!text || isProcessing}
          >
            {isProcessing ? (
              <Spinner
                className={`h-8 w-8 ${isProcessing ? 'cursor-not-allowed opacity-[0.5]' : ''}`}
              />
            ) : (
              <SendHorizontal
                size={24}
                strokeWidth={1.2}
                className={`${isProcessing ? 'cursor-not-allowed opacity-[0.5]' : ''}`}
              />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Assistant;
