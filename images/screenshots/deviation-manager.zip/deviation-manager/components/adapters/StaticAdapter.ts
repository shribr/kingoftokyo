// Static data source adapter - uses the existing test data generators
import { BaseDataSourceAdapter } from './BaseAdapter';
import type { 
  StaticDataSourceConfig, 
  DataSourceResponse, 
  DeviationResponse, 
  KpiResponse, 
  ChartResponse 
} from '../config/types';

import { 
  generateKpiData, 
  filterDeviationData,
  generateStatusDistributionData,
  generateSiteDistributionData,
  generateTrendData,
} from '../../services/DeviationManagerService';

import { generateDeviationData } from '../utils/dataHelper';
import type { DeviationTableData } from '../utils/data';
export class StaticDataSourceAdapter extends BaseDataSourceAdapter {
  private data: DeviationTableData[] = [];
  
  constructor(config: StaticDataSourceConfig) {
    super(config);
  }

  async connect(): Promise<boolean> {
    try {
      // Initialize static data
      const count = (this.config as StaticDataSourceConfig).data?.generateCount || 30;
      const customData = (this.config as StaticDataSourceConfig).data?.customData;
      
      if (customData && Array.isArray(customData)) {
        this.data = customData;
      } else {
        this.data = generateDeviationData(count);
      }
      
      return true;
    } catch (error) {
      console.error('Failed to initialize static data:', error);
      return false;
    }
  }

  async disconnect(): Promise<void> {
    this.data = [];
    this.clearCache();
  }

  async fetchDeviations(filters?: any, pagination?: any): Promise<DataSourceResponse<DeviationResponse>> {
    try {
      const cacheKey = `deviations-${JSON.stringify({ filters, pagination })}`;
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      // Apply filters if provided
      let filteredData = this.data;
      if (filters) {
        filteredData = filterDeviationData(this.data, {
          search: filters.search,
          site: filters.site,
          department: filters.department,
          classification: filters.classification,
          stage: filters.stage
        });
      }

      // Apply pagination
      let paginatedData = filteredData;
      if (pagination) {
        const { page = 1, pageSize = 5 } = pagination;
        const startIndex = (page - 1) * pageSize;
        const endIndex = startIndex + pageSize;
        paginatedData = filteredData.slice(startIndex, endIndex);
      }

      const response: DeviationResponse = {
        deviations: paginatedData,
        total: filteredData.length,
        page: pagination?.page || 1,
        pageSize: pagination?.pageSize || paginatedData.length
      };

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(false, { deviations: [], total: 0 }, `Failed to fetch deviations: ${error}`);
    }
  }

  async fetchKpis(): Promise<DataSourceResponse<KpiResponse>> {
    try {
      const cacheKey = 'kpis';
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      const kpiData = generateKpiData();
      const response: KpiResponse = {
        kpis: [
          { title: 'Total deviations', value: kpiData.total.value, delta: kpiData.total.delta },
          { title: 'Under investigation', value: kpiData.under.value, delta: kpiData.under.delta },
          { title: 'CAPA required', value: kpiData.capas.value, delta: kpiData.capas.delta },
          { title: 'Pending resolution', value: kpiData.avg.value, delta: kpiData.avg.delta }
        ],
        generated_at: new Date()
      };

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(false, { kpis: [], generated_at: new Date() }, `Failed to fetch KPIs: ${error}`);
    }
  }

  async fetchChartData(chartType: string): Promise<DataSourceResponse<ChartResponse>> {
    try {
      const cacheKey = `chart-${chartType}`;
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      let chartData;
      switch (chartType) {
        case 'status-distribution':
          chartData = generateStatusDistributionData(this.data);
          break;
        case 'site-distribution':
          chartData = generateSiteDistributionData(this.data);
          break;
        case 'trend':
          chartData = generateTrendData();
          break;
        default:
          throw new Error(`Unknown chart type: ${chartType}`);
      }

      const response: ChartResponse = {
        charts: [chartData],
        type: chartType
      };

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(false, { charts: [], type: chartType }, `Failed to fetch chart data: ${error}`);
    }
  }

  async healthCheck(): Promise<boolean> {
    return this.data.length > 0;
  }
}
