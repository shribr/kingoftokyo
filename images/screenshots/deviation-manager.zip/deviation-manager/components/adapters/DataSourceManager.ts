// Data source factory and manager
import { BaseDataSourceAdapter } from './BaseAdapter';
import { StaticDataSourceAdapter } from './StaticAdapter';
import { RestApiAdapter } from './RestApiAdapter';
import type { 
  DataSourceConfig, 
  DashboardConfig,
  DataSourceResponse,
  DeviationResponse,
  KpiResponse,
  ChartResponse
} from '../config/types';

export class DataSourceFactory {
  static createAdapter(config: DataSourceConfig): BaseDataSourceAdapter {
    switch (config.type) {
      case 'static':
        return new StaticDataSourceAdapter(config);
      case 'rest':
        return new RestApiAdapter(config);
      case 'postgresql':
      case 'mysql':
      case 'sqlite':
        // For now, database adapters would be similar to MongoDB
        // but with different connection and query implementations
        throw new Error(`Database adapter for ${config.type} not implemented yet`);
      default:
        throw new Error(`Unknown data source type: ${(config as any).type}`);
    }
  }
}

export class DataSourceManager {
  private primaryAdapter: BaseDataSourceAdapter;
  private fallbackAdapter?: BaseDataSourceAdapter;
  private config: DashboardConfig;
  private connected: boolean = false;

  constructor(config: DashboardConfig) {
    this.config = config;
    this.primaryAdapter = DataSourceFactory.createAdapter(config.dataSources.primary);
    
    if (config.dataSources.fallback) {
      this.fallbackAdapter = DataSourceFactory.createAdapter(config.dataSources.fallback);
    }
  }

  async initialize(): Promise<boolean> {
    try {
      // Try to connect to primary data source
      const primaryConnected = await this.primaryAdapter.connect();
      
      if (!primaryConnected && this.fallbackAdapter) {
        console.warn('Primary data source failed, attempting fallback...');
        const fallbackConnected = await this.fallbackAdapter.connect();
        
        if (!fallbackConnected) {
          throw new Error('Both primary and fallback data sources failed to connect');
        }
        
        console.info('Connected to fallback data source');
        this.connected = true;
        return true;
      }
      
      if (primaryConnected) {
        console.info('Connected to primary data source');
        this.connected = true;
        return true;
      }
      
      throw new Error('Failed to connect to any data source');
    } catch (error) {
      console.error('DataSourceManager initialization failed:', error);
      return false;
    }
  }

  async disconnect(): Promise<void> {
    try {
      await this.primaryAdapter.disconnect();
      if (this.fallbackAdapter) {
        await this.fallbackAdapter.disconnect();
      }
      this.connected = false;
    } catch (error) {
      console.error('Error during disconnect:', error);
    }
  }

  private async executeWithFallback<T>(
    operation: (adapter: BaseDataSourceAdapter) => Promise<DataSourceResponse<T>>
  ): Promise<DataSourceResponse<T>> {
    try {
      // Try primary adapter first
      const result = await operation(this.primaryAdapter);
      
      if (result.success) {
        return result;
      }
      
      // If primary fails and we have a fallback, try it
      if (this.fallbackAdapter) {
        console.warn('Primary adapter failed, trying fallback...');
        return await operation(this.fallbackAdapter);
      }
      
      return result;
    } catch (error) {
      // If primary throws and we have a fallback, try it
      if (this.fallbackAdapter) {
        console.warn('Primary adapter error, trying fallback:', error);
        try {
          return await operation(this.fallbackAdapter);
        } catch (fallbackError) {
          console.error('Fallback adapter also failed:', fallbackError);
          throw fallbackError;
        }
      }
      throw error;
    }
  }

  async fetchDeviations(filters?: any, pagination?: any): Promise<DataSourceResponse<DeviationResponse>> {
    if (!this.connected) {
      throw new Error('DataSourceManager not initialized');
    }

    return this.executeWithFallback(
      (adapter) => adapter.fetchDeviations(filters, pagination)
    );
  }

  async fetchKpis(): Promise<DataSourceResponse<KpiResponse>> {
    if (!this.connected) {
      throw new Error('DataSourceManager not initialized');
    }

    return this.executeWithFallback(
      (adapter) => adapter.fetchKpis()
    );
  }

  async fetchChartData(chartType: string): Promise<DataSourceResponse<ChartResponse>> {
    if (!this.connected) {
      throw new Error('DataSourceManager not initialized');
    }

    return this.executeWithFallback(
      (adapter) => adapter.fetchChartData(chartType)
    );
  }

  async healthCheck(): Promise<{ primary: boolean; fallback?: boolean }> {
    const primary = await this.primaryAdapter.healthCheck();
    const fallback = this.fallbackAdapter ? await this.fallbackAdapter.healthCheck() : undefined;
    
    return { primary, fallback };
  }

  getConfig(): DashboardConfig {
    return this.config;
  }

  isConnected(): boolean {
    return this.connected;
  }

  // Configuration update method
  async updateConfig(newConfig: DashboardConfig): Promise<boolean> {
    try {
      await this.disconnect();
      
      this.config = newConfig;
      this.primaryAdapter = DataSourceFactory.createAdapter(newConfig.dataSources.primary);
      
      if (newConfig.dataSources.fallback) {
        this.fallbackAdapter = DataSourceFactory.createAdapter(newConfig.dataSources.fallback);
      } else {
        this.fallbackAdapter = undefined;
      }
      
      return await this.initialize();
    } catch (error) {
      console.error('Failed to update configuration:', error);
      return false;
    }
  }
}
