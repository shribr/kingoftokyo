// REST API data source adapter
import { BaseDataSourceAdapter } from './BaseAdapter';
import type { 
  RestApiConfig, 
  DataSourceResponse, 
  DeviationResponse, 
  KpiResponse, 
  ChartResponse 
} from '../config/types';

export class RestApiAdapter extends BaseDataSourceAdapter {
  private baseUrl: string;
  private endpoints: RestApiConfig['endpoints'];
  private authHeaders: Record<string, string> = {};
  private timeout: number;
  private retryAttempts: number;

  constructor(config: RestApiConfig) {
    super(config);
    this.baseUrl = config.baseUrl;
    this.endpoints = config.endpoints || {};
    this.timeout = config.timeout || 30000;
    this.retryAttempts = config.retryAttempts || 3;
    this.setupAuth(config.auth);
  }

  private setupAuth(auth?: RestApiConfig['auth']): void {
    if (!auth || auth.type === 'none') return;

    switch (auth.type) {
      case 'bearer':
        if (auth.token) {
          this.authHeaders['Authorization'] = `Bearer ${auth.token}`;
        }
        break;
      case 'apikey':
        if (auth.apiKey) {
          this.authHeaders['X-API-Key'] = auth.apiKey;
        }
        break;
      case 'basic':
        if (auth.username && auth.password) {
          const credentials = btoa(`${auth.username}:${auth.password}`);
          this.authHeaders['Authorization'] = `Basic ${credentials}`;
        }
        break;
    }

    // Add custom headers
    if (auth.headers) {
      Object.assign(this.authHeaders, auth.headers);
    }
  }

  async connect(): Promise<boolean> {
    try {
      return await this.healthCheck();
    } catch (error) {
      console.error('Failed to connect to REST API:', error);
      return false;
    }
  }

  async disconnect(): Promise<void> {
    this.clearCache();
  }

  private async makeRequest<T>(
    endpoint: string, 
    options: RequestInit = {},
    attempt: number = 1
  ): Promise<T> {
    const url = `${this.baseUrl}${endpoint}`;
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...this.authHeaders,
          ...options.headers
        },
        signal: controller.signal
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return await response.json();
    } catch (error) {
      clearTimeout(timeoutId);
      
      if (attempt < this.retryAttempts) {
        console.warn(`Request failed, retrying (${attempt}/${this.retryAttempts}):`, error);
        await new Promise(resolve => setTimeout(resolve, 1000 * attempt)); // exponential backoff
        return this.makeRequest<T>(endpoint, options, attempt + 1);
      }
      
      throw error;
    }
  }

  async fetchDeviations(filters?: any, pagination?: any): Promise<DataSourceResponse<DeviationResponse>> {
    try {
      if (!this.endpoints.deviations) {
        throw new Error('Deviations endpoint not configured');
      }

      const cacheKey = `deviations-${JSON.stringify({ filters, pagination })}`;
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      // Build query parameters
      const params = new URLSearchParams();
      if (pagination) {
        if (pagination.page) params.append('page', pagination.page.toString());
        if (pagination.pageSize) params.append('pageSize', pagination.pageSize.toString());
      }
      if (filters) {
        Object.entries(filters).forEach(([key, value]) => {
          if (value && value !== '' && value !== 'All') {
            params.append(key, String(value));
          }
        });
      }

      const endpoint = `${this.endpoints.deviations}${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await this.makeRequest<DeviationResponse>(endpoint);

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(
        false, 
        { deviations: [], total: 0 }, 
        `Failed to fetch deviations: ${error}`
      );
    }
  }

  async fetchKpis(): Promise<DataSourceResponse<KpiResponse>> {
    try {
      if (!this.endpoints.kpis) {
        throw new Error('KPIs endpoint not configured');
      }

      const cacheKey = 'kpis';
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      const response = await this.makeRequest<KpiResponse>(this.endpoints.kpis);

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(
        false, 
        { kpis: [], generated_at: new Date() }, 
        `Failed to fetch KPIs: ${error}`
      );
    }
  }

  async fetchChartData(chartType: string): Promise<DataSourceResponse<ChartResponse>> {
    try {
      if (!this.endpoints.charts) {
        throw new Error('Charts endpoint not configured');
      }

      const cacheKey = `chart-${chartType}`;
      const cached = this.getCacheItem(cacheKey);
      
      if (cached) {
        return this.createResponse(true, cached);
      }

      const endpoint = `${this.endpoints.charts}/${chartType}`;
      const response = await this.makeRequest<ChartResponse>(endpoint);

      this.setCacheItem(cacheKey, response, this.config.cache?.ttl || 300);
      return this.createResponse(true, response);
      
    } catch (error) {
      return this.createResponse(
        false, 
        { charts: [], type: chartType }, 
        `Failed to fetch chart data: ${error}`
      );
    }
  }

  async healthCheck(): Promise<boolean> {
    try {
      // Try to ping a health endpoint or any configured endpoint
      const healthEndpoint = '/health';
      const testEndpoint = this.endpoints.kpis || this.endpoints.deviations || healthEndpoint;
      
      await this.makeRequest<any>(testEndpoint, { method: 'HEAD' });
      return true;
    } catch (error) {
      console.warn('REST API health check failed:', error);
      return false;
    }
  }
}
