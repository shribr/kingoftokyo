// Default configuration for the dashboard
import type { DashboardConfig } from './types';

export const defaultDashboardConfig: DashboardConfig = {
  dataSources: {
    primary: {
      type: 'static',
      name: 'Static Test Data',
      data: {
        generateCount: 50
      },
      cache: {
        enabled: false
      }
    },
    fallback: {
      type: 'static',
      name: 'Fallback Static Data',
      data: {
        generateCount: 10
      }
    }
  },
  features: {
    realTimeUpdates: false,
    offlineMode: true,
    refreshInterval: 300 // 5 minutes
  },
  ui: {
    itemsPerPage: 5,
    defaultFilters: {},
    chartTypes: ['pie', 'line', 'bar']
  }
};

// Example configurations for different data sources

export const restApiConfig: DashboardConfig = {
  dataSources: {
    primary: {
      type: 'rest',
      name: 'Production API',
      baseUrl: 'https://api.example.com/v1',
      endpoints: {
        deviations: '/deviations',
        kpis: '/kpis',
        charts: '/charts'
      },
      auth: {
        type: 'bearer',
        token: process.env.REACT_APP_API_TOKEN
      },
      timeout: 30000,
      retryAttempts: 3,
      cache: {
        enabled: true,
        ttl: 300
      }
    },
    fallback: {
      type: 'static',
      name: 'Static Fallback',
      data: {
        generateCount: 10
      }
    }
  },
  features: {
    realTimeUpdates: true,
    offlineMode: true,
    refreshInterval: 60
  },
  ui: {
    itemsPerPage: 10,
    defaultFilters: {
      site: 'All',
      department: 'All'
    }
  }
};

export const mongoDbConfig: DashboardConfig = {
  dataSources: {
    primary: {
      type: 'mongodb',
      name: 'MongoDB Production',
      connectionString: process.env.REACT_APP_MONGODB_URI || 'mongodb://localhost:27017/dashboard',
      database: 'dashboard',
      queries: {
        deviations: JSON.stringify({
          collection: 'deviations',
          filter: {},
          options: { sort: { createdDate: -1 } }
        }),
        kpis: JSON.stringify({
          collection: 'kpis',
          aggregation: [
            { $group: { _id: null, total: { $sum: 1 } } }
          ]
        })
      },
      cache: {
        enabled: true,
        ttl: 600
      }
    }
  },
  features: {
    realTimeUpdates: false,
    offlineMode: false,
    refreshInterval: 300
  },
  ui: {
    itemsPerPage: 15
  }
};

export const postgresConfig: DashboardConfig = {
  dataSources: {
    primary: {
      type: 'postgresql',
      name: 'PostgreSQL Production',
      connectionString: process.env.REACT_APP_POSTGRES_URI || 'postgresql://user:pass@localhost:5432/dashboard',
      queries: {
        deviations: `
          SELECT id, title, site, dept, classification, stage, assignee, created_date 
          FROM deviations 
          ORDER BY created_date DESC 
          LIMIT $1 OFFSET $2
        `,
        kpis: `
          SELECT 
            COUNT(*) as total_deviations,
            COUNT(*) FILTER (WHERE stage = 'Investigation in progress') as under_investigation,
            COUNT(*) FILTER (WHERE stage = 'CAPA development') as capa_required,
            AVG(EXTRACT(DAY FROM NOW() - created_date)) as avg_days_pending
          FROM deviations
        `
      },
      cache: {
        enabled: true,
        ttl: 300
      }
    }
  },
  features: {
    realTimeUpdates: false,
    offlineMode: false,
    refreshInterval: 180
  },
  ui: {
    itemsPerPage: 20
  }
};
