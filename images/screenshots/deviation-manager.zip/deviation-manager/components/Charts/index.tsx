import React from 'react'
import BaseChart, { BaseChartProps } from './BaseChart'
import { ChartData } from 'chart.js/auto'

// KPI Bar Chart Component
interface KpiBarChartProps {
  /** order: total, investigation, capa required, pending resolution */
  data: [number, number, number, number]
  className?: string
  height?: string | number
}

export const KpiBarChart: React.FC<KpiBarChartProps> = ({ data, className, height = '300px' }) => {
  const LABELS = [
    'Total deviations',
    'Under investigation',
    'CAPA required',
    'Pending resolution'
  ]

  const BAR_COLORS = ['#60a5fa', '#fbbf24', '#34d399', '#fb923c']

  const chartData: ChartData<'bar'> = {
    labels: LABELS,
    datasets: [{
      data: data,
      backgroundColor: BAR_COLORS,
      borderWidth: 0,
      borderRadius: 4,
    }]
  }

  const options = {
    plugins: {
      legend: {
        display: false
      }
    }
  }

  return (
    <BaseChart
      type="bar"
      data={chartData}
      options={options}
      height={height}
      className={className}
    />
  )
}

// Pie Chart Component
interface PieChartProps {
  data: number[]
  labels: string[]
  colors?: string[]
  className?: string
  height?: string | number
}

export const PieChart: React.FC<PieChartProps> = ({ 
  data, 
  labels, 
  colors = ['#60a5fa', '#fbbf24', '#34d399', '#fb923c', '#f87171'],
  className,
  height = '300px'
}) => {
  const chartData: ChartData<'pie'> = {
    labels,
    datasets: [{
      data,
      backgroundColor: colors.slice(0, data.length),
      borderWidth: 2,
      borderColor: '#ffffff'
    }]
  }

  return (
    <BaseChart
      type="pie"
      data={chartData}
      height={height}
      className={className}
    />
  )
}

// Line Chart Component
interface LineChartProps {
  data: number[]
  labels: string[]
  label?: string
  color?: string
  className?: string
  height?: string | number
}

export const LineChart: React.FC<LineChartProps> = ({ 
  data, 
  labels, 
  label = 'Data',
  color = '#60a5fa',
  className,
  height = '300px'
}) => {
  const chartData: ChartData<'line'> = {
    labels,
    datasets: [{
      label,
      data,
      borderColor: color,
      backgroundColor: color + '20', // Add transparency
      borderWidth: 2,
      fill: false,
      tension: 0.1
    }]
  }

  return (
    <BaseChart
      type="line"
      data={chartData}
      height={height}
      className={className}
    />
  )
}

// Doughnut Chart Component
interface DoughnutChartProps {
  data: number[]
  labels: string[]
  colors?: string[]
  className?: string
  height?: string | number
}

export const DoughnutChart: React.FC<DoughnutChartProps> = ({ 
  data, 
  labels, 
  colors = ['#60a5fa', '#fbbf24', '#34d399', '#fb923c', '#f87171'],
  className,
  height = '300px'
}) => {
  const chartData: ChartData<'doughnut'> = {
    labels,
    datasets: [{
      data,
      backgroundColor: colors.slice(0, data.length),
      borderWidth: 2,
      borderColor: '#ffffff'
    }]
  }

  return (
    <BaseChart
      type="doughnut"
      data={chartData}
      height={height}
      className={className}
    />
  )
}

// Main Charts component (default export)
export const Charts: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Charts</h3>
      <div className="text-gray-500">Chart components available: KpiBarChart, PieChart, LineChart, DoughnutChart</div>
    </div>
  )
}

// Export BaseChart for advanced usage
export { default as BaseChart } from './BaseChart'
export type { BaseChartProps } from './BaseChart'

export default Charts
