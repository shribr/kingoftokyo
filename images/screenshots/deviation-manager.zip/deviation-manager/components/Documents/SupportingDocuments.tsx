import useLocalize from '~/hooks/useLocalize';
import { useState } from 'react';
import ManageDocuments from './ManageDocuments';
import { useDeviationEvidence } from '~/features/deviation-manager/queries/deviationManagerQueries';

function SupportingDocsSkeleton() {
  return (
    <div className="w-full animate-pulse space-y-2 py-2">
      <div className="flex items-center justify-between">
        <div className="h-4 w-40 rounded bg-gray-300" />
        <div className="h-8 w-24 rounded bg-gray-300" />
      </div>

      <div className="overflow-hidden rounded-lg border border-gray-200">
        <div className="bg-gray-100 px-2 py-2">
          <div className="h-4 w-20 rounded bg-gray-300" />
        </div>
        <div className="divide-y divide-gray-200">
          {[...Array(2)].map((_, i) => (
            <div key={i} className="px-2 py-2">
              <div className="h-4 w-full rounded bg-gray-200" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const SupportingDocuments = ({ deviationId, onFileChanged }) => {
  const localize = useLocalize();
  const [isOpen, setIsOpen] = useState(false);

  const { data: documents, isLoading, refetch, isRefetching } = useDeviationEvidence(deviationId);

  const handleManageFilesClick = () => {
    setIsOpen(true);
  };

  const handleSuccess = () => {
    setIsOpen(false);
    onFileChanged?.(documents);
    refetch();
  };

  if (isLoading || isRefetching) {
    return <SupportingDocsSkeleton />;
  }

  return (
    <>
      <div className="mx-full rounded-lg">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-text-primary">
            {localize('supporting_documents_heading')}
          </h2>
          <button
            type="button"
            onClick={handleManageFilesClick}
            className="btn btn-secondary relative mt-2 cursor-pointer"
            disabled={isLoading}
          >
            {localize('supporting_documents_button_text')}
          </button>
        </div>
        <div className="mt-2 rounded-md border border-gray-200 dark:border-gray-500">
          <div className="flex items-center justify-between bg-gray-50 p-2 text-sm font-semibold text-text-primary dark:bg-gray-600">
            <span>{localize('supporting_documents_name_column')}</span>
          </div>
          <div
            className={`flex ${(documents?.length ?? 0 > 0) ? 'max-h-[150px]' : ''} flex-col overflow-y-auto`}
          >
            {!documents || documents?.length === 0 ? (
              <div className="flex h-full items-center justify-center p-2 text-center text-gray-500">
                <span>{localize('supporting_documents_no_documents_found')}</span>
              </div>
            ) : (
              documents?.slice().sort((a, b) => a.file_name.localeCompare(b.file_name)).map((doc, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between border-b p-2 dark:border-gray-500"
                >
                  <span className="text-sm text-text-primary">{doc.file_name}</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
      <ManageDocuments
        open={isOpen}
        onOpenChange={setIsOpen}
        draftDeviationId={deviationId}
        evidences={
          (documents?.map((file) => ({
            ...file,
          })) as FileEvidence[]) || []
        }
        onSuccess={handleSuccess}
      />
    </>
  );
};

export default SupportingDocuments;