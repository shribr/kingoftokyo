import React from 'react'

export interface AssistantTip {
  id: string
  icon: string
  title: string
  description: string
  color: 'blue' | 'green' | 'purple' | 'yellow' | 'red'
}

export interface InvestigationAssistantProps {
  title?: string
  description?: string
  tips?: AssistantTip[]
  actionButtonText?: string
  actionButtonDisabled?: boolean
  onActionClick?: () => void
  className?: string
}

const colorClasses = {
  blue: 'bg-blue-50 dark:bg-blue-900/20 text-blue-900 dark:text-blue-100 text-blue-800 dark:text-blue-200',
  green: 'bg-green-50 dark:bg-green-900/20 text-green-900 dark:text-green-100 text-green-800 dark:text-green-200',
  purple: 'bg-purple-50 dark:bg-purple-900/20 text-purple-900 dark:text-purple-100 text-purple-800 dark:text-purple-200',
  yellow: 'bg-yellow-50 dark:bg-yellow-900/20 text-yellow-900 dark:text-yellow-100 text-yellow-800 dark:text-yellow-200',
  red: 'bg-red-50 dark:bg-red-900/20 text-red-900 dark:text-red-100 text-red-800 dark:text-red-200'
}

export const InvestigationAssistant: React.FC<InvestigationAssistantProps> = ({
  title = 'Investigation Assistant',
  description = "I'll analyze your deviation and guide you through evidence collection to determine the root cause once you create the initial record.",
  tips = [],
  actionButtonText = 'Start Investigation',
  actionButtonDisabled = false,
  onActionClick,
  className = ''
}) => {
  const getColorClasses = (color: AssistantTip['color']) => {
    const classes = colorClasses[color].split(' ')
    return {
      bg: classes.slice(0, 2).join(' '),
      titleText: classes.slice(2, 4).join(' '),
      descText: classes.slice(4, 6).join(' ')
    }
  }

  return (
    <div className={`bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 sticky top-20 ${className}`}>
      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
        {title}
      </h3>
      
      <div className="text-sm text-gray-600 dark:text-gray-400 mb-6">
        {description}
      </div>
      
      {tips.length > 0 && (
        <div className="space-y-4 mb-6">
          {tips.map((tip) => {
            const colors = getColorClasses(tip.color)
            return (
              <div key={tip.id} className={`p-3 rounded-lg ${colors.bg}`}>
                <div className={`text-sm font-medium mb-1 ${colors.titleText}`}>
                  {tip.icon} {tip.title}
                </div>
                <div className={`text-xs ${colors.descText}`}>
                  {tip.description}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <button
        type="button"
        onClick={onActionClick}
        disabled={actionButtonDisabled}
        className={`w-full px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 ${
          actionButtonDisabled
            ? 'text-gray-700 bg-gray-100 border border-gray-300 cursor-not-allowed dark:bg-gray-700 dark:text-gray-300 dark:border-gray-600'
            : 'text-white bg-blue-600 border border-transparent hover:bg-blue-700'
        }`}
      >
        {actionButtonDisabled && actionButtonText.includes('(') 
          ? actionButtonText 
          : actionButtonText
        }
      </button>
    </div>
  )
}

export default InvestigationAssistant
