import React, { useState, useRef } from 'react';
import UserProfileMenu from '../../UserProfileMenu';
import { UserProfileDialog, SettingsDialog } from '../../dialogs';
import {
  DASHBOARD_VIEW,
  DEVIATION_FORM_VIEW,
  DEVIATIONS_VIEW,
  DeviationManagerContext,
  DeviationManagerViewMode,
  TREND_REPORTS_VIEW,
  useDeviationManagerContext,
} from '~/features/deviation-manager/components/DeviationManager';

// SVG Icon component that matches the screenshot
const DeviationManagerIcon: React.FC<{ className?: string }> = ({ className = 'h-6 w-6' }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2">
    <rect height="16" rx="3" width="18" x="3" y="4"></rect>
    <path d="M3 9h18"></path>
    <path d="M8 13h8"></path>
  </svg>
);

export const TopNav: React.FC = () => {
  const { setCurrentView, currentView } = useDeviationManagerContext();

  const navItems = [
    { id: DASHBOARD_VIEW, label: 'Dashboard' },
    { id: DEVIATIONS_VIEW, label: 'Deviations' },
    { id: TREND_REPORTS_VIEW, label: 'Trend reports' },
  ] as const;

  return (
    <nav className="flex space-x-8" role="navigation" aria-label="Main navigation">
      {navItems.map((item) => {
        const isActive = currentView === item.id;
        return (
          <button
            key={item.id}
            type="button"
            className={`px-3 py-2 text-sm font-medium transition-colors bg-transparent border-none p-0 ${
              isActive
                ? 'text-brand-600 border-b-2 border-brand-600'
                : 'text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100'
            }`}
            aria-current={isActive ? 'page' : undefined}
            {...(isActive && { 'aria-disabled': 'true', tabIndex: -1 })}
            onClick={() => {
              setCurrentView(item.id);
            }}
          >
            {item.label}
          </button>
        );
      })}
    </nav>
  );
};

export const Header: React.FC = () => {
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);
  const profileButtonRef = useRef<HTMLButtonElement>(null);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50 dark:bg-gray-800 dark:border-gray-700">
      <div className="max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Main Title and Navigation */}
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2">
              <div className="bg-brand-600 rounded-lg p-1">
                <DeviationManagerIcon className="h-4 w-4 text-white" />
              </div>
              <h1 className="text-xl font-bold text-brand-600">
                Deviation Manager
              </h1>
            </div>
            <TopNav />
          </div>

          {/* Profile and Notifications */}
          <div className="flex items-center space-x-4">
            {/* Notification Bell */}
            <div className="relative">
              <button
                type="button"
                className="p-2 text-gray-400 hover:text-gray-500 dark:text-gray-300 dark:hover:text-gray-200 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 rounded-md"
                title="Notifications"
                aria-label="View notifications (3 unread)"
              >
                <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
                </svg>
              </button>
              {/* Red notification dot */}
              <div
                className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full flex items-center justify-center"
                aria-hidden="true"
              >
                <span className="text-xs text-white font-medium">3</span>
              </div>
            </div>

            {/* Profile Picture */}
            <button
              ref={profileButtonRef}
              type="button"
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="h-8 w-8 rounded-full bg-gray-200 border border-gray-300 flex items-center justify-center dark:bg-gray-600 dark:border-gray-500 focus:outline-none focus:ring-2 focus:ring-brand-500 focus:ring-offset-2 hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
              aria-label="User menu"
              title="User menu"
            >
              <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" className="text-gray-600 dark:text-gray-300">
                <path d="M12 12c2.761 0 5-2.239 5-5s-2.239-5-5-5-5 2.239-5 5 2.239 5 5 5zm0 2c-4.418 0-8 2.239-8 5v1h16v-1c0-2.761-3.582-5-8-5z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* User Profile Menu */}
      <UserProfileMenu
        isOpen={isProfileMenuOpen}
        onClose={() => setIsProfileMenuOpen(false)}
        anchorRef={profileButtonRef}
        onShowProfile={() => setShowProfileDialog(true)}
        onShowSettings={() => setShowSettingsDialog(true)}
      />

      {/* Profile Dialog */}
      {showProfileDialog && (
        <UserProfileDialog
          isOpen={showProfileDialog}
          onClose={() => setShowProfileDialog(false)}
        />
      )}

      {/* Settings Dialog */}
      {showSettingsDialog && (
        <SettingsDialog
          isOpen={showSettingsDialog}
          onClose={() => setShowSettingsDialog(false)}
        />
      )}
    </header>
  );
};

export default Header;
