import React from 'react'
import FilterBar from './FilterBar'

interface MainHeaderProps {
  welcomeMessage?: string
  userName?: string
  description?: string
}

export const MainHeader: React.FC<MainHeaderProps> = ({ 
  welcomeMessage = 'Welcome', 
  userName = 'User',
  description = 'Create deviation records, track your tasks and collaborate with investigation teams.'
}) => {
  return (
    <section className="mt-6 mb-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-4">
        {/* Welcome message spanning first 2 KPI positions */}
        <div className="lg:col-span-2">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
            {welcomeMessage}, {userName}
          </h1>
          <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
            {description}
          </p>
        </div>

        {/* FilterBar spanning last 2 KPI positions */}
        <div className="lg:col-span-2">
          <FilterBar />
        </div>
      </div>
    </section>
  )
}

export default MainHeader
