import React from 'react'
import Filter, { FilterOption } from './Filter'
import TableSearchBox from './TableSearchBox'
import { useTableContext } from '../../../context/DeviationTableContext'

// Define filter data sources
const siteOptions: FilterOption[] = [
  { value: '', label: 'All Sites' },
  { value: 'Kansas City', label: 'Kansas City' },
  { value: 'San Diego', label: 'San Diego' },
  { value: 'Basel', label: 'Basel' }
]

const departmentOptions: FilterOption[] = [
  { value: '', label: 'All Departments' },
  { value: 'Manufacturing', label: 'Manufacturing' },
  { value: 'Warehouse', label: 'Warehouse' },
  { value: 'Production', label: 'Production' },
  { value: 'Quality Control', label: 'Quality Control' },
  { value: 'Packaging', label: 'Packaging' },
  { value: 'Logistics', label: 'Logistics' }
]

interface FilterBarProps {
  onSiteChange?: (value: string) => void
  onDepartmentChange?: (value: string) => void
  onSearch?: (value: string) => void
}

export const FilterBar: React.FC<FilterBarProps> = ({
  onSiteChange,
  onDepartmentChange,
  onSearch
}) => {
  // Try to use context if available, fallback to props
  let contextHandlers: { handleFilter?: any, handleSearch?: any } = {}
  try {
    contextHandlers = useTableContext()
  } catch {
    // Context not available, use props
  }

  const handleSiteChange = (value: string) => {
    if (contextHandlers.handleFilter) {
      contextHandlers.handleFilter('site', value)
    } else {
      onSiteChange?.(value)
    }
  }

  const handleDepartmentChange = (value: string) => {
    if (contextHandlers.handleFilter) {
      contextHandlers.handleFilter('department', value)
    } else {
      onDepartmentChange?.(value)
    }
  }

  const handleSearchChange = (value: string) => {
    if (contextHandlers.handleSearch) {
      contextHandlers.handleSearch(value)
    } else {
      onSearch?.(value)
    }
  }

  return (
    <div className="flex gap-3 items-end">
      <div className="w-40">
        <Filter
          id="site"
          label="Site"
          options={siteOptions}
          onChange={handleSiteChange}
        />
      </div>
      <div className="w-44">
        <Filter
          id="department"
          label="Department"
          options={departmentOptions}
          onChange={handleDepartmentChange}
        />
      </div>
      <div className="w-48">
        <TableSearchBox 
          onSearch={handleSearchChange} 
          placeholder="Search deviations..."
        />
      </div>
    </div>
  )
}

export default FilterBar
