# Dashboard Data Source Configuration Examples

This document provides examples of how to configure different data sources for the Dashboard component.

## Configuration Types

### 1. Static Test Data (Default)

```json
{
  "dataSources": {
    "primary": {
      "type": "static",
      "name": "Static Test Data",
      "data": {
        "generateCount": 50
      },
      "cache": {
        "enabled": false
      }
    }
  },
  "features": {
    "realTimeUpdates": false,
    "offlineMode": true,
    "refreshInterval": 300
  },
  "ui": {
    "itemsPerPage": 5,
    "defaultFilters": {},
    "chartTypes": ["pie", "line", "bar"]
  }
}
```

### 2. REST API Configuration

```json
{
  "dataSources": {
    "primary": {
      "type": "rest",
      "name": "Production API",
      "baseUrl": "https://api.example.com/v1",
      "endpoints": {
        "deviations": "/deviations",
        "kpis": "/kpis",
        "charts": "/charts"
      },
      "auth": {
        "type": "bearer",
        "token": "your-api-token-here"
      },
      "timeout": 30000,
      "retryAttempts": 3,
      "cache": {
        "enabled": true,
        "ttl": 300
      }
    },
    "fallback": {
      "type": "static",
      "name": "Static Fallback",
      "data": {
        "generateCount": 10
      }
    }
  },
  "features": {
    "realTimeUpdates": true,
    "offlineMode": true,
    "refreshInterval": 60
  },
  "ui": {
    "itemsPerPage": 10,
    "defaultFilters": {
      "site": "All",
      "department": "All"
    }
  }
}
```

### 3. MongoDB Configuration

```json
{
  "dataSources": {
    "primary": {
      "type": "mongodb",
      "name": "MongoDB Production",
      "connectionString": "mongodb://localhost:27017/dashboard",
      "database": "dashboard",
      "queries": {
        "deviations": "{\"collection\": \"deviations\", \"filter\": {}, \"options\": {\"sort\": {\"createdDate\": -1}}}",
        "kpis": "{\"collection\": \"kpis\", \"aggregation\": [{\"$group\": {\"_id\": null, \"total\": {\"$sum\": 1}}}]}"
      },
      "cache": {
        "enabled": true,
        "ttl": 600
      }
    }
  },
  "features": {
    "realTimeUpdates": false,
    "offlineMode": false,
    "refreshInterval": 300
  },
  "ui": {
    "itemsPerPage": 15
  }
}
```

### 4. PostgreSQL Configuration

```json
{
  "dataSources": {
    "primary": {
      "type": "postgresql",
      "name": "PostgreSQL Production",
      "connectionString": "postgresql://user:pass@localhost:5432/dashboard",
      "queries": {
        "deviations": "SELECT id, title, site, dept, classification, stage, assignee, created_date FROM deviations ORDER BY created_date DESC LIMIT $1 OFFSET $2",
        "kpis": "SELECT COUNT(*) as total_deviations, COUNT(*) FILTER (WHERE stage = 'Investigation in progress') as under_investigation, COUNT(*) FILTER (WHERE stage = 'CAPA development') as capa_required, AVG(EXTRACT(DAY FROM NOW() - created_date)) as avg_days_pending FROM deviations"
      },
      "cache": {
        "enabled": true,
        "ttl": 300
      }
    }
  },
  "features": {
    "realTimeUpdates": false,
    "offlineMode": false,
    "refreshInterval": 180
  },
  "ui": {
    "itemsPerPage": 20
  }
}
```

## Authentication Options

### Bearer Token
```json
{
  "auth": {
    "type": "bearer",
    "token": "your-bearer-token"
  }
}
```

### API Key
```json
{
  "auth": {
    "type": "apikey",
    "apiKey": "your-api-key"
  }
}
```

### Basic Authentication
```json
{
  "auth": {
    "type": "basic",
    "username": "your-username",
    "password": "your-password"
  }
}
```

### Custom Headers
```json
{
  "auth": {
    "type": "none",
    "headers": {
      "X-Custom-Header": "custom-value",
      "X-API-Version": "v1"
    }
  }
}
```

## Expected API Response Formats

### Deviations Endpoint
```json
{
  "deviations": [
    {
      "id": "TW-2024-0001",
      "title": "Temperature excursion",
      "site": "Kansas City",
      "dept": "Manufacturing",
      "classification": "Major",
      "stage": "Investigation in progress",
      "assignee": "Smith, John",
      "assigneeStatus": "online",
      "createdDate": "2024-01-15"
    }
  ],
  "total": 100,
  "page": 1,
  "pageSize": 10
}
```

### KPIs Endpoint
```json
{
  "kpis": [
    {
      "title": "Total deviations",
      "value": 45,
      "delta": {
        "dir": "up",
        "percent": 5.2
      }
    },
    {
      "title": "Under investigation",
      "value": 23,
      "delta": {
        "dir": "down",
        "percent": 2.1
      }
    }
  ],
  "generated_at": "2024-01-15T10:30:00Z"
}
```

### Charts Endpoint
```json
{
  "charts": [
    {
      "labels": ["Jan", "Feb", "Mar", "Apr", "May"],
      "datasets": [
        {
          "label": "Deviations",
          "data": [10, 15, 12, 18, 14],
          "borderColor": "#60a5fa",
          "backgroundColor": "rgba(96, 165, 250, 0.1)"
        }
      ]
    }
  ],
  "type": "trend"
}
```

## Environment Variables

For production deployments, use environment variables for sensitive data:

```bash
# API Configuration
REACT_APP_API_TOKEN=your-api-token
REACT_APP_API_BASE_URL=https://api.example.com/v1

# Database Configuration
REACT_APP_MONGODB_URI=mongodb://user:pass@host:port/database
REACT_APP_POSTGRES_URI=postgresql://user:pass@host:port/database
```

## Usage in Code

```typescript
import { configureDashboardData, switchDataSource } from './utils/data';
import { useFlexibleDeviationTable, useFlexibleKpis } from './utils/hooks';

// Configure data source
const config = {
  dataSources: {
    primary: {
      type: 'rest',
      baseUrl: 'https://api.example.com/v1',
      // ... rest of configuration
    }
  }
};

await configureDashboardData(config);

// Use in components
const { deviations, loading, error } = useFlexibleDeviationTable();
const { kpis } = useFlexibleKpis();
```
