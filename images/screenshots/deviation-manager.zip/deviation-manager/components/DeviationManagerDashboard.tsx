import React, { useState, useEffect } from 'react';
import './dashboard.css';
import Header from './layout/Header';
import Footer from './layout/Footer';
import MainContent from './layout/MainContent';
import MainHeader from './layout/MainHeader';
import KPIs from './KPIs';
import DeviationTable from './Table/DeviationTable';
import DataVisualization from './DataVisualization';
import MyTasks from './MyTasks';
import { TableProvider } from './context/DeviationTableContext';
import { ToastProvider } from './common/Toast';
import { useAuthContext } from '~/hooks/AuthContext';
import {
  DEVIATION_FORM_VIEW,
  useDeviationManagerContext,
} from '~/features/deviation-manager/components/DeviationManager';

interface DashboardContentProps {
  userName?: string
  onCreateRecord?: () => void
}

const DashboardContent: React.FC<DashboardContentProps> = ({
  userName,
  onCreateRecord,
}) => {
  
  const { user } = useAuthContext();
  const { setCurrentView } = useDeviationManagerContext();

  // Extract first name from user's full name, with fallbacks
  const getFirstName = () => {
    if (userName) {return userName;} // Use prop if provided

    const fullName = user?.name || user?.username;
    if (!fullName) {return 'User';}

    // Extract first name from full name (split by space and take first part)
    const firstName = fullName.split(' ')[0];
    return firstName || 'User';
  };

  const displayName = getFirstName();

  // Otherwise show the dashboard
  return (
    <div>

      {/* Scrollable content area with bottom padding for sticky footer */}
      <div className="flex-1 overflow-auto pb-32">
        <MainContent>
          <MainHeader
            welcomeMessage="Welcome"
            userName={displayName}
            description="Create deviation records, track your tasks and collaborate with investigation teams."
          />

          {/* KPIs Section */}
          <div className="mb-6">
            <KPIs />
          </div>

          {/* Main Content Layout */}
          <div className="space-y-6">
            {/* Table - Full Width */}
            <div>
              <DeviationTable />
            </div>

            {/* Bottom Panels - Horizontal Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <DataVisualization />
              <MyTasks />
            </div>
          </div>
        </MainContent>
      </div>

      <Footer />
    </div>
  );
};

interface DeviationManagerDashboardProps {
  userName?: string
}

export const DeviationManagerDashboard: React.FC<DeviationManagerDashboardProps> = ({
  userName = 'User',
}) => {
  const { setCurrentView } = useDeviationManagerContext();

  const handleCreateRecord = () => {
    setCurrentView(DEVIATION_FORM_VIEW);
  };

  return (
    <TableProvider onCreateRecord={handleCreateRecord}>
      <DashboardContent
        userName={userName}
        onCreateRecord={handleCreateRecord}
      />
    </TableProvider>
  );
};

export default DeviationManagerDashboard;
