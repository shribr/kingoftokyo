import React, { useState } from 'react';
import { checkApiConnection } from '../utils/data';

export const ApiDebugPanel: React.FC = () => {
  const [result, setResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  const testApi = async () => {
    setIsLoading(true);
    try {
      const result = await checkApiConnection();
      setResult(result);
    } catch (error) {
      setResult({ error: error instanceof Error ? error.message : 'Unknown error' });
    } finally {
      setIsLoading(false);
    }
  };

  const testDirectFetch = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/relevant-deviations/search', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: 'test',
          start_date: '2025-01-01',
          limit: 1
        }),
      });
      
      const contentType = response.headers.get('content-type');
      const responseText = await response.text();
      
      setResult({
        status: response.status,
        statusText: response.statusText,
        contentType,
        response: responseText.substring(0, 500),
        url: response.url
      });
    } catch (error) {
      setResult({ 
        error: error instanceof Error ? error.message : 'Unknown error',
        type: 'fetch_error'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg border">
      <h3 className="text-lg font-semibold mb-4">API Debug Panel</h3>
      
      <div className="space-x-2 mb-4">
        <button
          onClick={testApi}
          disabled={isLoading}
          className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 disabled:opacity-50"
        >
          Test API Connection
        </button>
        
        <button
          onClick={testDirectFetch}
          disabled={isLoading}
          className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:opacity-50"
        >
          Test Direct Fetch
        </button>
      </div>
      
      {isLoading && (
        <div className="text-center py-4">
          <div className="animate-spin h-6 w-6 border-2 border-blue-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2">Testing...</p>
        </div>
      )}
      
      {result && !isLoading && (
        <div className="bg-white dark:bg-gray-900 p-4 rounded border">
          <h4 className="font-semibold mb-2">Result:</h4>
          <pre className="text-sm overflow-auto max-h-64 bg-gray-50 dark:bg-gray-800 p-2 rounded">
            {JSON.stringify(result, null, 2)}
          </pre>
        </div>
      )}
      
      <div className="mt-4 text-sm text-gray-600 dark:text-gray-400">
        <p><strong>Expected API Endpoint:</strong> POST /api/relevant-deviations/search</p>
        <p><strong>Expected Content-Type:</strong> application/json</p>
        <p><strong>Request Body:</strong> {`{ "text": "string", "start_date": "string", "limit": number }`}</p>
      </div>
    </div>
  );
};

export default ApiDebugPanel;
