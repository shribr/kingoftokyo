import { memo, useEffect, useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { useLocalize } from '~/hooks';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@radix-ui/react-accordion';
import { ChevronDownIcon } from '@radix-ui/react-icons';
import { ChevronsDown } from 'lucide-react';
import { usePresentationContext } from '~/features/shared/providers/PresentationContext';

function DeviationListSkeleton() {
  return (
    <div className="w-full animate-pulse space-y-2 py-2">
      <div className="overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="border-b px-1 py-2">
            <div className="h-4 w-full rounded bg-gray-200" />
          </div>
        ))}
      </div>
    </div>
  );
}

const DeviationManagerLeftNav = ({toggleNav}:{toggleNav: () => void;}) => {
  const localize = useLocalize();
  const location = useLocation();
  const { isDeviationManagerView } = usePresentationContext();



  return (
    <div className="text-token-text-primary mt-2 flex flex-col gap-4 px-2 py-6 text-sm">
      <div>

      </div>
    </div>
  );
};

export default DeviationManagerLeftNav;