import { useState, useEffect } from 'react';
import useLocalize from '~/hooks/useLocalize';
import { usePresentationContext } from '../../../shared/providers/PresentationContext';
import { useParams } from 'react-router-dom';
import { Constants } from 'librechat-data-provider';
import { useLocation, useNavigate } from 'react-router-dom';
import Header from '~/components/Chat/Header';
import Footer from '~/components/Chat/Footer';
import DeviationManager from '~/features/deviation-manager/components/DeviationManager';

export default function DeviationManagerSidePanel() {
  const localize = useLocalize();
  const [page, setPage] = useState(1);
  const { setIsShowChat } = usePresentationContext();
  const [model, setModel] = useState<any>();
  const { conversationId } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const [isEdit, setIsEdit] = useState(false);

  const onGenerate = (response: any) => {
    setViewOptions(response);
    setIsEdit(false);
    navigate(`/c/${response.generated.id}`);
  };

  const setViewOptions = (options: any) => {
    setPage(2);
    setIsShowChat(true);
    setModel(options);
  };

  const handleNavigateBack = () => {
    setIsEdit(true);
    setPage(1);
    setIsShowChat(false);
  };

  const handleNavigateDetails = () => {
    setIsEdit(false);
    setPage(2);
    setIsShowChat(true);
  };

  const pages = [
    <DeviationManager
      key="deviationManager"
      deviationId={model?.generated?.id}
      isEditMode={isEdit}
      onGenerate={onGenerate}
      onNavigateDetails={handleNavigateDetails}
    />
  ];

  useEffect(() => {
    if (conversationId && conversationId != Constants.NEW_CONVO) {
      setViewOptions({ generated: { id: conversationId } });
    }
    if (conversationId == Constants.NEW_CONVO) {
      setPage(1);
      setIsShowChat(false);
      setIsEdit(false);
    }
  }, [location]);

  return (
    <section className="flex h-screen w-full flex-col">
      <header className="sticky top-0 z-10 border-b">
        <Header />
      </header>
      <main className="mb-8 flex-1 overflow-y-auto md:mb-0">{pages[page - 1]}</main>
      <footer className="sticky bottom-0 z-10 mt-2">
        <Footer />
      </footer>
    </section>
  );
}
