export const QueryKeys = {
  draftDeviations: 'draftDeviations',
  draftDeviation: 'draftDeviation',
  deviationQuestions: 'deviationQuestions',
  deviationSearch: 'deviationSearch',
  deviationHealth: 'deviationHealth',  
  relevantDeviationSearch: 'relevantDeviationSearch',
  banner: 'banner',
  config: 'config',
} as const;

export type QueryKeysType = typeof QueryKeys;