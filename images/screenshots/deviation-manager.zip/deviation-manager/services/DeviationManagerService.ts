import { request } from 'librechat-data-provider';
import { AxiosResponse } from 'axios';
import * as data from '../components/utils/data';

// Import helper functions from dataHelper
import {
  pick,
  randomInt,
  randomPercent,
  generateKpiData,
  generateDeviationRecords,
  filterDeviationData,
  paginateData,
  getTotalPages,
  convertDeviationRecordToDeviationData,
  searchTrackwiseRecords as searchTrackwiseRecordsFromHelper,
  generateStatusChartData,
  generateSiteChartData,
  generateTrendChartData,
  DEVIATION_RECORDS_SAMPLE,
} from '../components/utils/dataHelper';

// Import configuration and adapters
import { defaultDashboardConfig } from '../components/config/defaultConfig';
import type { DashboardConfig } from '../components/config/types';
import { DataSourceManager } from '../components/adapters/DataSourceManager';

// Import types
import type {
  DeviationTableData,
  TrackwiseSearchRequest,
  DeviationRecord,
  TrackwiseRecord,
  TrackwiseSearchResponse,
} from '../components/utils/data';
import {
  CreateDeviationRequest,
  CreateDeviationResponse,
  DEVIATIONS_PATH,
  GetDeviationByIdResponse,
  GetDeviationsParams,
  GetDeviationsPaginatedResponse,
  HEALTHCHECK_PATH,
  HealthCheckResponse,
  UpdateDeviationResponse,
  UpdateDeviationRequest,
  GetDeviationEvidenceByIdResponse,
  GetDeviationEvidenceStatusResponse,
  RELEVANT_DEVIATIONS_SEARCH_PATH,
  GetRelevantDeviationsHybridSearchRequest,
  GetRelevantDeviationsHybridSearchResponse,
  RELEVANT_DEVIATIONS_HYBRID_SEARCH_PATH,
  GetRelevantDeviationsSearchResponse, GetRelevantDeviationsSearchRequest,
} from '../types/apiTypes';

// ====================================================================
// CONFIGURATION & CONSTANTS
// ====================================================================

const DEVIATION_MANAGER_API_BASE = '/api/deviation-manager';
const DEVIATIONS_API_PATH = `${DEVIATION_MANAGER_API_BASE}/api/deviations`;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

const USE_LIVE_DATA = true;
let lastFetchTime: number = 0;
let dataSourceManager: DataSourceManager | null = null;

// Simple logger implementation
const logger = {
  debug: (message: string, ...args: any[]) => console.log('[DEBUG]', message, ...args),
  error: (message: string, ...args: any[]) => console.error('[ERROR]', message, ...args),
  info: (message: string, ...args: any[]) => console.info('[INFO]', message, ...args),
  warn: (message: string, ...args: any[]) => console.warn('[WARN]', message, ...args),
};

export let cachedDeviationRecords: DeviationRecord[] | null = null;

// DEVIATION MANAGER SERVICE CLASS
// ====================================================================

class DeviationManagerService {
  public apiUrl?: string;

  constructor(apiUrl?: string) {
    this.apiUrl = apiUrl;
  }

  async healthCheck(): Promise<HealthCheckResponse> {
    try {
      return await request.get(`${this.apiUrl}${HEALTHCHECK_PATH}`) as HealthCheckResponse;
    } catch (error: any) {
      logger.error('Health check failed:', error);
      return {
        status: 'error',
        message: error.message || 'Health check failed',
        configured: false,
      };
    }
  }

  async getDeviations(params?: GetDeviationsParams): Promise<GetDeviationsPaginatedResponse> {
    return await request.get(`${this.apiUrl}${DEVIATIONS_PATH}`, { params });
  }

  async getDeviationById(id: string): Promise<GetDeviationByIdResponse> {
    return await request.get(`${this.apiUrl}${DEVIATIONS_PATH}/${id}`);
  }

  async createDeviation(data: CreateDeviationRequest): Promise<CreateDeviationResponse> {
    return await request.post(`${this.apiUrl}${DEVIATIONS_PATH}`, data);
  }

  async updateDeviation(id: string, data: UpdateDeviationRequest): Promise<UpdateDeviationResponse> {
    return await request.patch(`${this.apiUrl}${DEVIATIONS_PATH}/${id}`, data);
  }

  async getDeviationEvidence(deviationId: string): Promise<GetDeviationEvidenceByIdResponse> {
    return await request.get(`${this.apiUrl}${DEVIATIONS_PATH}/${deviationId}/evidence`);
  }

  async getDeviationEvidenceStatus(evidenceId: string): Promise<GetDeviationEvidenceStatusResponse> {
    return await request.get(`${this.apiUrl}${DEVIATIONS_API_PATH}/evidence/${evidenceId}/status`);
  }

  async getDeviationExport(deviationId: string, format: 'pdf' | 'docx' = 'pdf'): Promise<Blob> {
    const response = await request.get(`${this.apiUrl}${DEVIATIONS_PATH}/${deviationId}/export`, {
      responseType: 'blob',
      params: { format },
    });
    return response as Blob;
  }

  async searchRelevantDeviations(searchRequest: GetRelevantDeviationsSearchRequest):
    Promise<GetRelevantDeviationsSearchResponse> {
    return await request.post(`${this.apiUrl}${RELEVANT_DEVIATIONS_SEARCH_PATH}`, searchRequest);
  }

  async hybridSearchRelevantDeviations(searchRequest: GetRelevantDeviationsHybridSearchRequest):
    Promise<GetRelevantDeviationsHybridSearchResponse> {
    return await request.post(`${this.apiUrl}${RELEVANT_DEVIATIONS_HYBRID_SEARCH_PATH}`, searchRequest);
  }

  async getDeviationQuestions(): Promise<DeviationManagerQuestion[]> {
    try {
      const response = await request.get(`${DEVIATION_MANAGER_API_BASE}/api/questions`) as DeviationManagerQuestion[];
      return response;
    } catch (error: any) {
      logger.error('DeviationManagerService: Get deviation questions failed:', error);
      throw error;
    }
  }

  async generateDescriptions(intakeData, files = []): Promise<any> {
    return await request.post(`${this.apiUrl}/api/orchestrator/process`, {
      request_type: 'intake_to_descriptions',
      intake_data: intakeData,  // JSON object with intake form data
      uploaded_files: files,  // Optional: PDF/Word/text/png/jpg documents
    });
  }

  async processClassification(deviationId: string, data: {
    request_type: string;
    rpn_inputs: {
      severity: number;
      occurrence: number;
      detection: number;
    };
  }): Promise<any> {
    data.request_type = 'classification_only';

    return await request.post(`${this.apiUrl}/api/orchestrator/process/${deviationId}`, data);
  }

  async getDeviationByID(deviationID): Promise<any> {
    return await request.get(`${this.apiUrl}/api/deviations/${deviationID}`);
  }

  async processRiskImpactOnly(deviationId: string): Promise<any> {
      return await request.post(`${this.apiUrl}/api/orchestrator/process/${deviationId}`, {
        request_type: 'risk_impact_only'
      });
  }
}

// ====================================================================

// TYPES & INTERFACES
// ====================================================================

export interface Deviation {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, any>;
}

export interface DraftDeviation {
  id: string;
  title: string;
  description: string;
  category: string;
  severity: string;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt: string;
  content?: string;
  metadata?: Record<string, any>;
}

export interface FileEvidence {
  id?: string;
  filename: string;
  url?: string;
  size?: number;
  mimeType?: string;
  uploadedAt?: string;
  uploadedBy?: string;
  description?: string;
}

export interface GenerateDeviationRequest {
  prompt?: string;
  context?: string;
  template?: string;
  metadata?: Record<string, any>;
}

export interface SearchRequest {
  query: string;
  category?: string;
  severity?: string;
  status?: string;
  limit?: number;
  offset?: number;
}

export interface DebugCredentialsResponse {
  hasApiKey: boolean;
  apiKeyPreview?: string;
  apiKeyLength?: number;
  baseURL?: string;
  lastUpdated?: string;
}

export enum ControlType {
  TEXTBOX = 'textbox',
  DROPDOWN = 'dropdown',
  DATE = 'date',
  TIME = 'time',
  TEXTAREA = 'textarea'
}

export interface DeviationManagerQuestion {
  id: number;
  label: string;
  controlType: ControlType;
  options?: { label: string; value: string | number }[];
  cssClass?: string;
  placeHolder?: string;
  value?: string;
  isDirty?: boolean;
}

// ====================================================================
// DATA SOURCE MANAGEMENT
// ====================================================================

// MOVE TO DATA SOURCE MANAGER??>???????
export const ensureDataSourceInitialized = async (): Promise<DataSourceManager> => {
  if (!dataSourceManager) {
    await configureDashboardData(defaultDashboardConfig);
  }
  return dataSourceManager!;
};

export const configureDashboardData = (config: DashboardConfig): Promise<boolean> => {
  dataSourceManager = new DataSourceManager(config);
  return dataSourceManager.initialize();
};

export const checkDataSourceHealth = async () => {
  if (!dataSourceManager) {
    return { connected: false, health: null };
  }

  const health = await dataSourceManager.healthCheck();
  return {
    connected: dataSourceManager.isConnected(),
    health,
  };
};

export const switchDataSource = async (config: DashboardConfig): Promise<boolean> => {
  try {
    if (dataSourceManager) {
      await dataSourceManager.disconnect();
    }
    return await configureDashboardData(config);
  } catch (error) {
    console.error('Failed to switch data source:', error);
    return false;
  }
};

// ====================================================================
// DATA FETCHING FUNCTIONS
// ====================================================================

// TODO - WHAT ARE THESE?
export const fetchDeviationsData = async (filters?: any, pagination?: any) => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchDeviations(filters, pagination);
};

export const fetchKpisData = async () => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchKpis();
};

export const fetchChartData = async (chartType: string) => {
  const manager = await ensureDataSourceInitialized();
  return manager.fetchChartData(chartType);
};


// ====================================================================
// DATA CONVERSION FUNCTIONS
// ====================================================================
// TODO: THESE MAPPERS DONT BELONG HERE
export const convertRelevantDeviationsToTrackwiseRecords =
  (searchResults: GetRelevantDeviationsSearchResponse): TrackwiseRecord[] => {
    return searchResults.map((item, index) => ({
      id: item.id || `RD-${Date.now()}-${index}`,
      name: item.title || 'Unknown Record',
      description: item.description || 'No description available',
      classification: item.deviation_type || 'Unknown',
      createdOn: item.created_date || new Date().toISOString().split('T')[0],
      createdBy: 'System User',
      department: pick(data.DEPT_OPTIONS.filter(d => d !== 'All')),

      deviationName: item.title || 'Unknown Deviation',
      potentialImpact: 'To be determined based on investigation',
      whatDefectObserved: item.description || 'Description from search result',
      objectDefectObserved: 'Object to be determined',
      specifications: 'Specifications to be documented',
      issueOccurred: 'Location to be determined',
      timeOfOccurrence: '00:00',
      actualDefectOccurrence: item.created_date || new Date().toISOString().split('T')[0],
      dateDefectDiscovered: item.created_date || new Date().toISOString().split('T')[0],
      dateReported: item.created_date || new Date().toISOString().split('T')[0],
      detectionMethods: 'Detection methods to be documented',
      personWhoObserved: 'Observer to be identified',
      personWhoReported: 'Reporter to be identified',
      immediateAction: 'Immediate actions to be documented',
      backgroundInformation: item.description || 'Background information from search result',
      attachmentsDescription: 'Supporting documents to be attached',
      additionalComments: `Found via relevant deviations search with similarity score: ${item.similarity_score?.toFixed(2) || 'N/A'}`,
      finalAnalysis: 'Analysis to be completed during investigation',
    }));
  };

const convertApiResponseToDeviationRecord = (apiResponse: any): DeviationRecord[] => {
  if (!apiResponse) {
    console.warn('API response is null or undefined');
    return [];
  }

  if (typeof apiResponse === 'object' && !Array.isArray(apiResponse)) {
    if (Array.isArray(apiResponse.data)) {
      apiResponse = apiResponse.data;
    } else if (Array.isArray(apiResponse.results)) {
      apiResponse = apiResponse.results;
    } else if (Array.isArray(apiResponse.items)) {
      apiResponse = apiResponse.items;
    } else {
      console.warn('API response is not an array and does not contain expected array properties:', apiResponse);
      return [];
    }
  }

  if (!Array.isArray(apiResponse)) {
    console.warn('API response is not an array after processing:', typeof apiResponse, apiResponse);
    return [];
  }

  return apiResponse.map((item, index) => ({
    id: item.id || `API-${Date.now()}-${index}`,
    trackwiseId: `TW-${new Date().getFullYear()}-${String(index + 1).padStart(4, '0')}`,
    formData: {
      deviationName: item.title || 'Unknown Deviation',
      site: item.site || pick(data.SITE_OPTIONS),
      department: item.department || pick(data.DEPT_OPTIONS.filter(d => d !== 'All')),
      assignee: item.assignee || `${pick(data.LAST_NAMES)}, ${pick(data.FIRST_NAMES)}`,
      createdOn: item.created_date || new Date().toISOString().split('T')[0],
      stage: item.stage || item.deviation_type || pick(data.STAGES),
      selectedTrackwiseRecord: null,
      step1: {
        trackwiseSearchQuery: '',
        whatDefectObserved: item.description || 'Description from API',
        objectDefectObserved: 'Object to be determined',
        wantSpecifications: 'Specifications to be determined',
        issueOccurred: 'Location to be determined',
        dateOccurrence: item.created_date || new Date().toISOString().split('T')[0],
        timeOccurrence: '00:00',
        dateDetection: item.created_date || new Date().toISOString().split('T')[0],
        impactOfIssue: 'Impact to be assessed',
        processStepDefect: 'Process step to be identified',
        whoInvolvedProcess: 'Personnel to be identified',
        whoObservedIssue: 'Observer to be identified',
        processDescription: item.description || 'Process description from API',
        immediateActions: 'Immediate actions to be documented',
        materialsToolsEquipment: 'Materials/tools to be listed',
        supportingDocuments: [],
      },
      step2: {
        riskQuestion1: '',
        riskQuestion2: '',
        riskQuestion3: '',
        riskQuestion4: '',
        severityLevel: '',
        severityDetails: '',
        detectionLevel: '',
        detectionDetails: '',
        occurrenceLevel: '',
        occurrenceDetails: '',
        rpnScore: '',
        localClassification: '',
        teamCommitteeAgreement: '',
      },
      step3: {
        investigationPlan: '',
        rootCauseAnalysis: '',
        contributingFactors: [],
      },
      step4: {
        correctiveActions: '',
        preventiveActions: '',
        effectiveness: '',
        conclusion: '',
      },
    },
  }));
};

// export const searchDeviations = async (searchTerm: string = ''): Promise<DeviationRecord[]> => {
//   const records = await getDeviationRecords();
//
//   if (!searchTerm.trim()) {
//     return records;
//   }
//
//   const filteredRecords = records.filter(record => {
//     const searchableText = [
//       record.formData.deviationName,
//       record.formData.site,
//       record.formData.department,
//       record.formData.assignee,
//       record.formData.stage,
//       record.formData.step1.whatDefectObserved,
//       record.trackwiseId,
//     ].join(' ').toLowerCase();
//
//     return searchableText.includes(searchTerm.toLowerCase());
//   });
//
//   return filteredRecords;
// };

// ====================================================================
// EXPORTS FOR BACKWARD COMPATIBILITY
// ====================================================================

export {
  generateKpiData,
  generateDeviationRecords,
  filterDeviationData,
  paginateData,
  getTotalPages,
  convertDeviationRecordToDeviationData,
  generateStatusChartData as generateStatusDistributionData,
  generateSiteChartData as generateSiteDistributionData,
  generateTrendChartData as generateTrendData,
};

export { DeviationManagerService };