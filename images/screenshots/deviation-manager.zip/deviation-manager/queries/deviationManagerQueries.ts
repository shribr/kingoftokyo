import { GetDeviationsParams, GetDeviationsPaginatedResponse, GetRelevantDeviationsSearchRequest,
  GetRelevantDeviationsSearchResponse
} from '~/features/deviation-manager/types/apiTypes';
import { useDeviationManagerService } from '~/features/deviation-manager/hooks/useDeviationManagerService';
import { useQuery } from '@tanstack/react-query';

export const usePaginatedDeviations = (params?: GetDeviationsParams) => {
  const { service, isLoading: configLoading, hasValidConfig } = useDeviationManagerService();

  // Only enable query once config has loaded and we have a valid base URL
  const enabled = hasValidConfig && !configLoading;

  return useQuery({
    queryKey: ['deviations', params],
    queryFn: () => {
      if (!enabled) {
        // Should not run, but guard to satisfy types & avoid network errors
        return Promise.reject(new Error('Deviation service not ready')) as Promise<GetDeviationsPaginatedResponse>;
      }
      return service.getDeviations(params);
    },
    enabled,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useHealthCheck = () => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-health-check'],
    queryFn: () => service.healthCheck(),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationById = (id: string) => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviations', id],
    queryFn: () => service.getDeviationById(id),
    enabled: !!id,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationEvidence = (deviationId: string) => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-evidence', deviationId],
    queryFn: () => service.getDeviationEvidence(deviationId),
    enabled: !!deviationId,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationEvidenceStatus = (evidenceId: string) => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-evidence-status', evidenceId],
    queryFn: () => service.getDeviationEvidenceStatus(evidenceId),
    enabled: !!evidenceId,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationExport = (deviationId: string, format: 'pdf' | 'docx' = 'pdf') => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-export', deviationId, format],
    queryFn: () => service.getDeviationExport(deviationId, format),
    enabled: !!deviationId,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationQuestions = () => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-questions'],
    queryFn: () => service.getDeviationQuestions(),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useDeviationByID = (deviationID: string) => {
  const { service } = useDeviationManagerService();
  return useQuery({
    queryKey: ['deviation-by-ID', deviationID],
    queryFn: () => service.getDeviationByID(deviationID),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
};

export const useSearchRelevantDeviations = (searchRequest: GetRelevantDeviationsSearchRequest) => {
  const { service } = useDeviationManagerService();

  return useQuery({
    queryKey: [],
    queryFn: () => service.searchRelevantDeviations(searchRequest),
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
  });
}