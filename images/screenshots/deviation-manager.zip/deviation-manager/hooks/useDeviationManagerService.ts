import { useGetStartupConfig } from '~/data-provider';
import { DeviationManagerService } from '../services/DeviationManagerService';

// Lightweight fallback interface matching the needed subset of DeviationManagerService methods
interface DeviationManagerServiceLike {
  apiUrl?: string;
  getDeviations: (params?: any) => Promise<{ items: any[]; total: number; page?: number; pages?: number }>; // minimal shape
  healthCheck?: () => Promise<any>;
}

export function useDeviationManagerService() {
  const { data: startupConfig, isLoading, error } = useGetStartupConfig();

  const baseUrl = startupConfig?.cataliaConfig?.deviationManagerBaseUrl;

  let service: DeviationManagerServiceLike;
  let hasValidConfig = false;

  if (baseUrl) {
    service = new DeviationManagerService(baseUrl);
    hasValidConfig = true;
  } else {
    // Fallback shim service: returns empty data without throwing so UI can still render
    service = {
      apiUrl: undefined,
      async getDeviations() {
        return { items: [], total: 0, page: 1, pages: 1 };
      },
      async healthCheck() {
        return { status: 'unconfigured', configured: false };
      },
    };
  }


  // useEffect(() => {
  //   console.log("USE EFFECT START");
  //
  //   // Wait for config to load
  //   if (isLoading) {
  //     return;
  //   }
  //
  //   // Validate config and initialize service
  //   const apiUrl = startupConfig?.cataliaConfig?.deviationManagerBaseUrl;
  //
  //   console.log("USE DEVIATION MANAGER SERVICE RAN")
  //   console.log(startupConfig)
  //
  //   if (!apiUrl || error) {
  //     console.error('Deviation Manager API base URL is missing in the startup config.', {
  //       error,
  //       config: startupConfig?.cataliaConfig,
  //     });
  //     setIsInitialized(true); // Mark as initialized to avoid retrying
  //     return;
  //   }
  //
  //   console.log("SHOULDN'T SEE THIS")
  //
  //   const deviationManagerService = new DeviationManagerService(apiUrl);
  //   setService(deviationManagerService);
  //   console.log('DeviationManagerService initialized with URL:', apiUrl);
  //
  //   setIsInitialized(true);
  // }, [startupConfig, isLoading, error]);

  return {
    service: service as DeviationManagerService,
    isLoading,
    error,
    apiUrl: service.apiUrl,
    hasValidConfig,
    unconfigured: !hasValidConfig && !isLoading,
  };
}