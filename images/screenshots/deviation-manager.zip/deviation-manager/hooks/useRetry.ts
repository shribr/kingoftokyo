import { useCallback } from "react";

export function useRetry() {
  return useCallback(async <T>(fn: () => Promise<T>, retries = 1, delay = 0): Promise<T> => {
    let lastError: unknown;

    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        return await fn();
      } catch (err) {
        console.warn("Retrying after failure:", err);
        lastError = err;
        if (attempt < retries && delay > 0) {
          await new Promise((res) => setTimeout(res, delay));
        }
      }
    }

    throw lastError;
  }, []);
}

