import { components, paths } from '~/features/deviation-manager/types/schema';

// API PATH CONSTANTS
export const HEALTHCHECK_PATH = '/api/health';
export const DEVIATIONS_PATH = '/api/deviations/';

export const DEVIATIONS_BY_ID_PATH = '/api/deviations/{deviation_id}';
export const DEVIATIONS_EVIDENCE_BY_ID_PATH = '/api/deviations/{deviation_id}/evidence';
export const DEVIATIONS_EXPORT_BY_ID_PATH = '/api/deviations/{deviation_id}/export';
export const DEVIATIONS_EVIDENCE_STATUS_PATH = '/api/deviations/evidence/{evidence_id}/status';
export const RELEVANT_DEVIATIONS_SEARCH_PATH = '/api/relevant-deviations/search';
export const RELEVANT_DEVIATIONS_HYBRID_SEARCH_PATH = '/api/relevant-deviations/hybrid-search';
export const RELEVANT_DEVIATIONS_SEARCH_CAPABILITIES_PATH = '/api/relevant-deviations/search-capabilities';
export const USER_PROFILE_PATH = '/api/user/profile';
export const ORCHESTRATOR_PROCESS_PATH = '/api/orchestrator/process';
export const ORCHESTRATOR_PROCESS_BY_ID_PATH = '/api/orchestrator/process/{draft_deviation_id}';
export const ORCHESTRATOR_REQUEST_TYPES_PATH = '/api/orchestrator/request-types';

// HEALTHCHECK RESPONSE
export type HealthCheckResponse = paths[typeof HEALTHCHECK_PATH]['get']['responses']['200']['content']['application/json'];

// DEVIATION RESPONSES
export type CreateDeviationResponse = paths[typeof DEVIATIONS_PATH]['post']['responses']['201']['content']['application/json'];
export type GetDeviationsPaginatedResponse = paths[typeof DEVIATIONS_PATH]['get']['responses']['200']['content']['application/json'];
export type GetDeviation = components['schemas']['DeviationResponse']

export type GetDeviationByIdResponse = paths[typeof DEVIATIONS_BY_ID_PATH]['get']['responses']['200']['content']['application/json'];
export type GetDeviationEvidenceByIdResponse = paths[typeof DEVIATIONS_EVIDENCE_BY_ID_PATH]['get']['responses']['200']['content']['application/json'];
export type UpdateDeviationResponse = paths[typeof DEVIATIONS_BY_ID_PATH]['patch']['responses']['200']['content']['application/json'];
export type CreateDeviationEvidenceResponse = paths[typeof DEVIATIONS_EVIDENCE_BY_ID_PATH]['post']['responses']['201']['content']['application/json'];
// streaming response - no content for export
// export type GetDeviationExportResponse = paths[typeof DEVIATIONS_EXPORT_BY_ID_PATH]['get']['responses']['200']['content'];

//  RELEVANT DEVIATIONS RESPONSES
export type GetDeviationEvidenceStatusResponse = paths[typeof DEVIATIONS_EVIDENCE_STATUS_PATH]['get']['responses']['200']['content']['application/json'];
export type GetRelevantDeviationsSearchResponse = paths[typeof RELEVANT_DEVIATIONS_SEARCH_PATH]['post']['responses']['200']['content']['application/json'];
export type GetRelevantDeviationsHybridSearchResponse = paths[typeof RELEVANT_DEVIATIONS_HYBRID_SEARCH_PATH]['post']['responses']['200']['content']['application/json'];
export type GetRelevantDeviationsSearchCapabilitiesResponse = paths[typeof RELEVANT_DEVIATIONS_SEARCH_CAPABILITIES_PATH]['get']['responses']['200']['content']['application/json'];

// USER RESPONSES
export type GetUserProfileResponse = paths[typeof USER_PROFILE_PATH]['get']['responses']['200']['content']['application/json'];

// ORCHESTRATOR RESPONSES
export type OrchestratorProcessResponse = paths[typeof ORCHESTRATOR_PROCESS_PATH]['post']['responses']['200']['content']['application/json'];
export type OrchestratorProcessByDeviationIdResponse = paths[typeof ORCHESTRATOR_PROCESS_BY_ID_PATH]['post']['responses']['200']['content']['application/json'];
export type OrchestratorRequestTypesResponse = paths[typeof ORCHESTRATOR_REQUEST_TYPES_PATH]['get']['responses']['200']['content']['application/json'];

// DEVIATION REQUEST TYPES
export type CreateDeviationRequest = paths[typeof DEVIATIONS_PATH]['post']['requestBody']['content']['application/json'];
export type GetDeviationsParams = NonNullable<paths[typeof DEVIATIONS_PATH]['get']['parameters']['query']>;
export type GetDeviationByIdParams = NonNullable<paths[typeof DEVIATIONS_BY_ID_PATH]['get']['parameters']['path']>;
export type GetDeviationEvidenceByIdParams = NonNullable<paths[typeof DEVIATIONS_EVIDENCE_BY_ID_PATH]['get']['parameters']['path']>;
export type UpdateDeviationByIdParams = NonNullable<paths[typeof DEVIATIONS_BY_ID_PATH]['patch']['parameters']['path']>;
export type UpdateDeviationRequest = paths[typeof DEVIATIONS_BY_ID_PATH]['patch']['requestBody']['content']['application/json'];
export type CreateDeviationEvidenceParams = NonNullable<paths[typeof DEVIATIONS_EVIDENCE_BY_ID_PATH]['post']['parameters']['path']>;
export type CreateDeviationEvidenceRequest = paths[typeof DEVIATIONS_EVIDENCE_BY_ID_PATH]['post']['requestBody']['content']['multipart/form-data'];
export type GetDeviationExportParams = NonNullable<paths[typeof DEVIATIONS_EXPORT_BY_ID_PATH]['get']['parameters']['path']> &
  NonNullable<paths[typeof DEVIATIONS_EXPORT_BY_ID_PATH]['get']['parameters']['query']>;

// RELEVANT DEVIATIONS REQUEST TYPES
export type GetDeviationEvidenceProcessingStatusParams = NonNullable<paths[typeof DEVIATIONS_EVIDENCE_STATUS_PATH]['get']['parameters']['query']>;
export type GetRelevantDeviationsSearchRequest = paths[typeof RELEVANT_DEVIATIONS_SEARCH_PATH]['post']['requestBody']['content']['application/json'];
export type GetRelevantDeviationsHybridSearchRequest = paths[typeof RELEVANT_DEVIATIONS_HYBRID_SEARCH_PATH]['post']['requestBody']['content']['application/json'];
// No request type for GetRelevantDeviationsSearchCapabilitiesResponse (GET, no params/body)

// USER REQUEST TYPES
// No request type for GetUserProfileResponse (GET, no params/body)

// ORCHESTRATOR REQUEST TYPES
export type OrchestratorProcessRequest = paths[typeof ORCHESTRATOR_PROCESS_PATH]['post']['requestBody']['content']['application/json'];
export type OrchestratorProcessByDeviationIdParams = NonNullable<paths[typeof ORCHESTRATOR_PROCESS_BY_ID_PATH]['post']['parameters']['path']>;
export type OrchestratorProcessByDeviationIdRequest = paths[typeof ORCHESTRATOR_PROCESS_BY_ID_PATH]['post']['requestBody']['content']['application/json'];
// No request type for OrchestratorRequestTypesResponse (GET, no params/body)

// MANUAL TYPES
export type ProcessClassificationData = {
  request_type: string;
  rpn_inputs: {
    severity: number;
    occurrence: number;
    detection: number;
  }
}